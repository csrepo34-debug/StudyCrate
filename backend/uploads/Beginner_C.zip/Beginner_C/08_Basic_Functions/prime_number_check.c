/*
 * PRIME NUMBER CHECKER
 * Uses function to check if number is prime
 * 
 * CONCEPT:
 * Prime number: A number greater than 1 that has no divisors except 1 and itself
 * Examples: 2, 3, 5, 7, 11, 13, 17, 19, 23...
 * Non-prime: 4 (divisible by 2), 6 (divisible by 2,3), 9 (divisible by 3)
 */

#include <stdio.h>

// Function to check if number is prime
// Returns 1 (true) if prime, 0 (false) if not prime
int isPrime(int num) {
    // Numbers less than or equal to 1 are not prime
    if (num <= 1) {
        return 0;  // Not prime
    }
    
    // 2 is the only even prime number
    if (num == 2) {
        return 1;  // Prime
    }
    
    // Even numbers (except 2) are not prime
    if (num % 2 == 0) {
        return 0;  // Not prime
    }
    
    // Check odd divisors from 3 to sqrt(num)
    // If num = 36, we only need to check up to 6
    // because if 36 = a × b and a > 6, then b < 6
    for (int i = 3; i * i <= num; i += 2) {  // i += 2 skips even numbers
        if (num % i == 0) {
            return 0;  // Found a divisor, not prime
        }
    }
    
    return 1;  // No divisors found, it's prime
}

int main() {
    int number;
    
    printf("Enter a number: ");
    scanf("%d", &number);
    
    // Call isPrime function and check result
    if (isPrime(number)) {
        printf("%d is a PRIME number\n", number);
        
        // Show some context
        if (number == 2) {
            printf("(2 is the smallest and only even prime)\n");
        }
    } else {
        printf("%d is NOT a prime number\n", number);
        
        // Show why it's not prime (for small numbers)
        if (number > 1 && number <= 20) {
            printf("Divisors: ");
            for (int i = 1; i <= number; i++) {
                if (number % i == 0) {
                    printf("%d ", i);
                }
            }
            printf("\n");
        }
    }
    
    return 0;
}

/*
 * SAMPLE RUNS:
 * Input: 7   Output: 7 is a PRIME number
 * Input: 12  Output: 12 is NOT a prime number
 *                    Divisors: 1 2 3 4 6 12
 * Input: 1   Output: 1 is NOT a prime number
 * Input: 2   Output: 2 is a PRIME number (2 is the smallest and only even prime)
 * 
 * OPTIMIZATION:
 * We only check up to sqrt(num) because:
 * - If num has a divisor greater than sqrt(num)
 * - Then it must also have a divisor less than sqrt(num)
 * - This reduces checks from num to sqrt(num)
 * 
 * Example: For 100, we check only up to 10 (not all the way to 100)
 */
