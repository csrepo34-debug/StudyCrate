/*
 * HELLO WORLD PROGRAM
 * First C program - prints greeting message
 * 
 * This is a multi-line comment
 * Comments explain code but are ignored by compiler
 */

#include <stdio.h>  // Include standard input-output library

int main() {
    // This is a single-line comment
    
    // Print hello message
    printf("Hello, World!\n");
    printf("Welcome to C Programming!\n");
    
    // \n creates a new line
    printf("\nLearning C is fun!\n");
    
    return 0;  // Return 0 means program executed successfully
}

/*
 * COMPILATION:
 * gcc hello_world.c -o hello_world
 * 
 * RUN:
 * ./hello_world  (Linux/Mac)
 * hello_world.exe (Windows)
 * 
 * OUTPUT:
 * Hello, World!
 * Welcome to C Programming!
 * 
 * Learning C is fun!
 * 
 * EXPLANATION:
 * - #include <stdio.h> allows us to use printf()
 * - main() is where program execution begins
 * - printf() displays text on screen
 * - \n moves cursor to next line
 * - return 0 tells OS program finished successfully
 */
