/*
 * READ NAME AND AGE
 * Demonstrates string and integer input
 */

#include <stdio.h>

int main() {
    char name[50];
    int age;
    
    // Read name
    printf("Enter your name: ");
    scanf("%s", name);  // Note: no & for strings
    
    // Read age
    printf("Enter your age: ");
    scanf("%d", &age);
    
    // Display information
    printf("\n--- Your Information ---\n");
    printf("Name: %s\n", name);
    printf("Age: %d years\n", age);
    printf("After 10 years, you will be %d years old.\n", age + 10);
    
    return 0;
}
