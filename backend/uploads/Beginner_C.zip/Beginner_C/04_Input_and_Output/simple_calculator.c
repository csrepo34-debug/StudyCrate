/*
 * SIMPLE CALCULATOR
 * Takes two numbers and performs basic operations
 * Demonstrates: scanf() for input, printf() for output, arithmetic operators
 */

#include <stdio.h>

int main() {
    float num1, num2;
    float sum, diff, product, quotient;
    
    // Input first number
    printf("Enter first number: ");
    scanf("%f", &num1);  // & gives address where input will be stored
    
    // Input second number
    printf("Enter second number: ");
    scanf("%f", &num2);  // %f is for float type
    
    // Perform calculations
    sum = num1 + num2;        // Addition
    diff = num1 - num2;       // Subtraction
    product = num1 * num2;    // Multiplication
    quotient = num1 / num2;   // Division
    
    // Output results
    printf("\n--- Results ---\n");
    printf("%.2f + %.2f = %.2f\n", num1, num2, sum);
    printf("%.2f - %.2f = %.2f\n", num1, num2, diff);
    printf("%.2f * %.2f = %.2f\n", num1, num2, product);
    
    // Check for division by zero
    if (num2 != 0) {
        printf("%.2f / %.2f = %.2f\n", num1, num2, quotient);
    } else {
        printf("Cannot divide by zero!\n");
    }
    
    return 0;
}

/*
 * SAMPLE RUN:
 * Enter first number: 10
 * Enter second number: 5
 * 
 * --- Results ---
 * 10.00 + 5.00 = 15.00
 * 10.00 - 5.00 = 5.00
 * 10.00 * 5.00 = 50.00
 * 10.00 / 5.00 = 2.00
 * 
 * NOTE:
 * %.2f formats float to 2 decimal places
 * Always check for division by zero!
 */
