/*
 * PROGRAM: Temperature Converter (Celsius to Fahrenheit)
 * PURPOSE: Demonstrates float variables and mathematical formula implementation
 * TOPIC: Variables and Data Types - Float Type and Arithmetic
 * 
 * CONCEPTS COVERED:
 * - Float variable declaration and initialization
 * - Mathematical formula implementation
 * - Type conversion in arithmetic
 * - Format specifier %.1f (1 decimal place)
 * - Temperature conversion formula
 */

#include <stdio.h>  // Required for printf() function

int main() {
    /*
     * Variable Declarations:
     * - celsius: Stores temperature in Celsius (initialized)
     * - fahrenheit: Stores converted temperature (uninitialized)
     */
    float celsius = 25.5f;      // Input temperature in Celsius
    float fahrenheit;           // Will store converted value
    
    /*
     * Temperature Conversion Formula:
     * Fahrenheit = (Celsius × 9/5) + 32
     * 
     * IMPORTANT: Use 9.0 and 5.0 (not 9/5):
     * - 9/5 = 1 (integer division, wrong!)
     * - 9.0/5.0 = 1.8 (float division, correct!)
     * 
     * Order of operations:
     * 1. celsius * 9.0 = multiplication
     * 2. result / 5.0 = division
     * 3. result + 32 = addition
     */
    fahrenheit = (celsius * 9.0 / 5.0) + 32.0;
    
    /*
     * Display Results:
     * - %.1f: Shows 1 decimal place
     * - °C and °F symbols for clarity
     * - \n for new line after each output
     */
    printf("Temperature in Celsius: %.1f°C\n", celsius);
    printf("Temperature in Fahrenheit: %.1f°F\n", fahrenheit);
    
    /*
     * FORMULA VERIFICATION:
     * For celsius = 25.5:
     * fahrenheit = (25.5 * 9.0 / 5.0) + 32.0
     *            = (229.5 / 5.0) + 32.0
     *            = 45.9 + 32.0
     *            = 77.9°F ✓
     */
    
    return 0;  // Successful program termination
}

/*
 * EXPECTED OUTPUT:
 * Temperature in Celsius: 25.5°C
 * Temperature in Fahrenheit: 77.9°F
 * 
 * LEARNING POINTS:
 * 1. Mathematical formulas can be directly implemented in C
 * 2. Use float division (9.0/5.0) not integer division (9/5)
 * 3. Order of operations matters: use parentheses for clarity
 * 4. %.1f rounds and displays to 1 decimal place
 * 
 * COMMON CONVERSION VALUES:
 * 0°C = 32°F (freezing point of water)
 * 25°C = 77°F (room temperature)
 * 37°C = 98.6°F (human body temperature)
 * 100°C = 212°F (boiling point of water)
 * 
 * TRY MODIFYING:
 * - Reverse conversion: Fahrenheit to Celsius: C = (F - 32) * 5/9
 * - Try different temperatures: 0, 100, -40
 * - Add Kelvin conversion: K = C + 273.15
 * - Read temperature from user using scanf()
 * - Display all three scales (C, F, K) at once
 */
