/*
 * PROGRAM: Store and Display Grades
 * PURPOSE: Demonstrates char data type and ASCII values
 * TOPIC: Variables and Data Types - Character Type
 * 
 * CONCEPTS COVERED:
 * - char variable declaration and initialization
 * - Single quotes for character literals
 * - Format specifiers: %c (character) and %d (ASCII value)
 * - ASCII encoding concept
 * - Multiple variable declaration
 */

#include <stdio.h>  // Required for printf() function

int main() {
    /*
     * Character Variable:
     * - char: Data type for single characters
     * - grade: Variable name
     * - 'A': Character literal (must use single quotes)
     * 
     * IMPORTANT: 'A' is different from "A"
     * - 'A' is a character (1 byte)
     * - "A" is a string (2 bytes: 'A' + '\0')
     */
    char grade = 'A';  // Single quotes for char literals
    
    /*
     * Display character:
     * - %c: Format specifier to display as character
     * - Shows the letter 'A'
     */
    printf("Student Grade: %c\n", grade);
    
    /*
     * Display ASCII value:
     * - %d: Format specifier to display as decimal integer
     * - Characters are stored as numbers (ASCII encoding)
     * - 'A' = 65, 'B' = 66, 'C' = 67, etc.
     * - 'a' = 97, 'b' = 98, 'c' = 99, etc.
     */
    printf("Grade (ASCII value): %d\n", grade);
    
    /*
     * Multiple Character Variables:
     * - Can declare multiple char variables in one line
     * - Each initialized with its own character literal
     * - Demonstrates comma-separated declaration
     */
    char grade1 = 'A', grade2 = 'B', grade3 = 'C';
    printf("\nMultiple grades: %c %c %c\n", grade1, grade2, grade3);
    
    /*
     * ASCII REFERENCE:
     * Uppercase Letters: 'A'=65, 'B'=66, ..., 'Z'=90
     * Lowercase Letters: 'a'=97, 'b'=98, ..., 'z'=122
     * Digits: '0'=48, '1'=49, ..., '9'=57
     * 
     * Note: '0' (character) ≠ 0 (integer)
     * - Character '0' has ASCII value 48
     * - Integer 0 is just 0
     */
    
    return 0;  // Successful program completion
}

/*
 * EXPECTED OUTPUT:
 * Student Grade: A
 * Grade (ASCII value): 65
 * 
 * Multiple grades: A B C
 * 
 * LEARNING POINTS:
 * 1. char stores single characters using ASCII encoding
 * 2. Use single quotes 'A' for characters, double quotes "A" for strings
 * 3. %c displays as character, %d displays ASCII numeric value
 * 4. Characters are actually stored as small integers (ASCII codes)
 * 
 * USEFUL ASCII FACTS:
 * - Uppercase to lowercase: add 32 ('A' + 32 = 'a')
 * - Lowercase to uppercase: subtract 32 ('a' - 32 = 'A')
 * - Character digit to integer: '5' - '0' = 5
 * 
 * TRY MODIFYING:
 * - Display lowercase grades: 'a', 'b', 'c'
 * - Print special characters: '+', '-', '*', '/'
 * - Calculate: char diff = 'Z' - 'A'; (shows 25)
 * - Convert uppercase to lowercase: grade + 32
 * - Display characters and their ASCII values in a loop
 */
