/*
 * PROGRAM: Store and Display Product Price
 * PURPOSE: Demonstrates float variable usage and decimal calculations
 * TOPIC: Variables and Data Types - Floating-Point Type
 * 
 * CONCEPTS COVERED:
 * - Float data type declaration
 * - Decimal number initialization
 * - Format specifier %.2f (2 decimal places)
 * - Arithmetic operations with floats
 * - Percentage calculations
 */

#include <stdio.h>  // Required for printf() function

int main() {
    /*
     * Float Variable Declaration:
     * - float: Data type for decimal numbers
     * - price: Variable name
     * - 99.99: Decimal value (note: use 'f' suffix for float literals)
     */
    float price = 99.99f;  // 'f' suffix indicates float literal
    
    /*
     * Display price with formatting:
     * - %.2f: Format specifier for float with 2 decimal places
     * - $ symbol printed as regular text
     * - \n creates new line
     */
    printf("Product Price: $%.2f\n", price);
    
    /*
     * Calculate price with tax:
     * - price * 1.10 means price + 10% tax
     * - Multiplication performed before printf displays result
     * - %% prints a single % symbol (% is escape character)
     */
    printf("Price with tax (10%%): $%.2f\n", price * 1.10);
    
    /*
     * IMPORTANT NOTES:
     * - float provides ~6-7 decimal digits of precision
     * - For money calculations, consider using integers (cents)
     * - %.2f rounds to 2 decimal places for display
     * - Always use 'f' suffix for float literals (99.99f)
     */
    
    return 0;  // Successful program completion
}

/*
 * EXPECTED OUTPUT:
 * Product Price: $99.99
 * Price with tax (10%): $109.99
 * 
 * LEARNING POINTS:
 * 1. float is used for decimal numbers (prices, measurements)
 * 2. %.2f formats output to exactly 2 decimal places
 * 3. Can perform arithmetic directly in printf()
 * 4. %% is needed to print a single % character
 * 
 * TRY MODIFYING:
 * - Change tax percentage to 15% or 8%
 * - Calculate discount: price * 0.80 (20% off)
 * - Display multiple decimal places: %.4f
 * - Calculate total for multiple items
 * - Add shipping cost to final price
 */
