/*
 * PROGRAM: Store and Display Age
 * PURPOSE: Demonstrates integer variable declaration, initialization, and usage
 * TOPIC: Variables and Data Types - Integer Type
 * 
 * CONCEPTS COVERED:
 * - Variable declaration and initialization
 * - Integer data type (int)
 * - printf() for output
 * - Format specifier %d for integers
 * - Arithmetic operations with variables
 */

#include <stdio.h>  // Required for printf() function

int main() {
    /*
     * Variable Declaration and Initialization:
     * - int: Data type for whole numbers
     * - age: Variable name (identifier)
     * - 25: Initial value assigned to age
     */
    int age = 25;
    
    // Display the current age value
    printf("My age is: %d years\n", age);
    
    /*
     * Arithmetic with variables:
     * - age + 5 calculates a new value
     * - Result is displayed but original age variable unchanged
     * - Demonstrates expression evaluation in printf()
     */
    printf("After 5 years, I will be %d years old\n", age + 5);
    
    /*
     * IMPORTANT NOTES:
     * - Variables must be declared before use
     * - Good practice to initialize variables when declaring
     * - %d is the format specifier for int type
     * - \n creates a new line for better readability
     */
    
    return 0;  // Indicates successful program termination
}

/*
 * EXPECTED OUTPUT:
 * My age is: 25 years
 * After 5 years, I will be 30 years old
 * 
 * LEARNING POINTS:
 * 1. Variables store values that can be used throughout the program
 * 2. int type is used for whole numbers (no decimals)
 * 3. Variables can be used in expressions (age + 5)
 * 4. printf() can display both text and variable values
 * 
 * TRY MODIFYING:
 * - Change the initial age value
 * - Calculate age after 10 years or 20 years
 * - Display age in months (age * 12)
 * - Calculate birth year (current_year - age)
 */
```
