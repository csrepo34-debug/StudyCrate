/*
 * FIND MAXIMUM OF TWO NUMBERS
 * Uses relational operator to compare numbers
 */

#include <stdio.h>

int main() {
    int num1, num2;
    
    printf("Enter first number: ");
    scanf("%d", &num1);
    
    printf("Enter second number: ");
    scanf("%d", &num2);
    
    // Find and display maximum
    if (num1 > num2) {
        printf("Maximum is: %d\n", num1);
    } else if (num2 > num1) {
        printf("Maximum is: %d\n", num2);
    } else {
        printf("Both numbers are equal: %d\n", num1);
    }
    
    return 0;
}
