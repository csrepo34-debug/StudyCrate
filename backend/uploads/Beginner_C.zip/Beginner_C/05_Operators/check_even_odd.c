/*
 * CHECK EVEN OR ODD
 * Uses modulus operator to determine if number is even or odd
 * 
 * CONCEPT:
 * - Even numbers are divisible by 2 (remainder = 0)
 * - Odd numbers have remainder 1 when divided by 2
 * - Modulus operator (%) gives remainder of division
 */

#include <stdio.h>

int main() {
    int number;
    
    printf("Enter a number: ");
    scanf("%d", &number);
    
    // Check using modulus operator
    // If number % 2 equals 0, it's even
    if (number % 2 == 0) {
        printf("%d is EVEN\n", number);
    } else {
        printf("%d is ODD\n", number);
    }
    
    // Additional information
    printf("\nExplanation: %d %% 2 = %d\n", number, number % 2);
    
    return 0;
}

/*
 * EXAMPLES:
 * Input: 10  Output: 10 is EVEN  (10 % 2 = 0)
 * Input: 7   Output: 7 is ODD    (7 % 2 = 1)
 * Input: 0   Output: 0 is EVEN   (0 % 2 = 0)
 * Input: -4  Output: -4 is EVEN  (-4 % 2 = 0)
 * 
 * NOTE:
 * %% in printf prints a single % symbol
 * Modulus works with negative numbers too
 */
