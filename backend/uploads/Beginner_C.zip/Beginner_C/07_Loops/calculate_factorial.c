/*
 * CALCULATE FACTORIAL
 * Uses for loop to calculate factorial of a number
 * 
 * CONCEPT:
 * Factorial of n (written as n!) = n × (n-1) × (n-2) × ... × 1
 * Examples:
 *   5! = 5 × 4 × 3 × 2 × 1 = 120
 *   4! = 4 × 3 × 2 × 1 = 24
 *   0! = 1 (by definition)
 */

#include <stdio.h>

int main() {
    int n;
    long long factorial = 1;  // Use long long for large results
    
    printf("Enter a number: ");
    scanf("%d", &n);
    
    // Factorial not defined for negative numbers
    if (n < 0) {
        printf("Factorial is not defined for negative numbers\n");
    } 
    else if (n == 0 || n == 1) {
        printf("Factorial of %d = 1\n", n);
    }
    else {
        // Calculate factorial using loop
        for (int i = 1; i <= n; i++) {
            factorial *= i;  // Same as: factorial = factorial * i
            // Show calculation step by step (optional)
            // printf("Step %d: %lld\n", i, factorial);
        }
        printf("Factorial of %d = %lld\n", n, factorial);
    }
    
    return 0;
}

/*
 * SAMPLE RUNS:
 * Input: 5   Output: Factorial of 5 = 120
 * Input: 0   Output: Factorial of 0 = 1
 * Input: -3  Output: Factorial is not defined for negative numbers
 * 
 * NOTE:
 * - Factorial grows very quickly
 * - Use long long to handle larger values
 * - 20! is the largest factorial that fits in long long
 * - For bigger numbers, use arrays or special libraries
 */
