/*
 * PRINT PATTERNS
 * Uses nested loops to create patterns
 */

#include <stdio.h>

int main() {
    int n = 5;
    
    // Pattern 1: Right-angled triangle
    printf("Pattern 1: Right Triangle\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    
    // Pattern 2: Square
    printf("\nPattern 2: Square\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            printf("* ");
        }
        printf("\n");
    }
    
    // Pattern 3: Number pyramid
    printf("\nPattern 3: Number Pyramid\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
    
    return 0;
}
