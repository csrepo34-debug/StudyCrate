/*
 * FIBONACCI SERIES
 * Uses while loop to generate Fibonacci sequence
 */

#include <stdio.h>

int main() {
    int n, count = 0;
    long long first = 0, second = 1, next;
    
    printf("Enter number of terms: ");
    scanf("%d", &n);
    
    printf("Fibonacci Series: ");
    
    while (count < n) {
        if (count <= 1) {
            next = count;
        } else {
            next = first + second;
            first = second;
            second = next;
        }
        printf("%lld ", next);
        count++;
    }
    printf("\n");
    
    return 0;
}
