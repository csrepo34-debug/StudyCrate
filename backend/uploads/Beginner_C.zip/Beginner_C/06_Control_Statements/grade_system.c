/*
 * GRADE SYSTEM
 * Assigns grade based on marks using if-else ladder
 */

#include <stdio.h>

int main() {
    float marks;
    char grade;
    
    printf("Enter marks (0-100): ");
    scanf("%f", &marks);
    
    // Determine grade
    if (marks >= 90) {
        grade = 'A';
    } else if (marks >= 80) {
        grade = 'B';
    } else if (marks >= 70) {
        grade = 'C';
    } else if (marks >= 60) {
        grade = 'D';
    } else if (marks >= 50) {
        grade = 'E';
    } else {
        grade = 'F';
    }
    
    // Display result
    printf("\nMarks: %.2f\n", marks);
    printf("Grade: %c\n", grade);
    
    if (grade != 'F') {
        printf("Status: PASSED\n");
    } else {
        printf("Status: FAILED\n");
    }
    
    return 0;
}
