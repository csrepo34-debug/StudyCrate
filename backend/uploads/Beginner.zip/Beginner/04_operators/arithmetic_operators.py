# Arithmetic Operators
# Basic mathematical operations

print("ARITHMETIC OPERATORS")
print("=" * 50)

a = 15
b = 4

print(f"a = {a}")
print(f"b = {b}")
print()

# All arithmetic operations
print("Operations:")
print(f"a + b = {a + b}  (Addition)")
print(f"a - b = {a - b}  (Subtraction)")
print(f"a * b = {a * b}  (Multiplication)")
print(f"a / b = {a / b}  (Division)")
print(f"a // b = {a // b}  (Floor Division)")
print(f"a % b = {a % b}  (Modulus/Remainder)")
print(f"a ** b = {a ** b}  (Exponentiation)")

print("\n" + "=" * 50)

# Practical examples
print("\nPRACTICAL EXAMPLES:")
price_per_item = 25
quantity = 7

total = price_per_item * quantity
print(f"Price per item: ${price_per_item}")
print(f"Quantity: {quantity}")
print(f"Total cost: ${total}")

print()

total_students = 50
groups = 6
students_per_group = total_students // groups
remaining = total_students % groups

print(f"Total students: {total_students}")
print(f"Number of groups: {groups}")
print(f"Students per group: {students_per_group}")
print(f"Remaining students: {remaining}")
