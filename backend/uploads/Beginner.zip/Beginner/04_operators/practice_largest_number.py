# Practice: Largest of 3 Numbers
# Find the largest number among three numbers using comparison operators

print("FIND LARGEST OF THREE NUMBERS")
print("=" * 50)
print()

# Get three numbers from user
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))
num3 = float(input("Enter third number: "))

print("\n" + "=" * 50)
print("ANALYSIS")
print("=" * 50)

print(f"\nNumbers entered: {num1}, {num2}, {num3}")
print()

# Method 1: Using comparison operators
print("Comparisons:")
print(f"num1 > num2: {num1 > num2}")
print(f"num1 > num3: {num1 > num3}")
print(f"num2 > num3: {num2 > num3}")

print("\n" + "=" * 50)
print("RESULT")
print("=" * 50)

# Find largest using nested comparisons
if num1 >= num2 and num1 >= num3:
    largest = num1
elif num2 >= num1 and num2 >= num3:
    largest = num2
else:
    largest = num3

print(f"\nThe largest number is: {largest}")

print("\n" + "=" * 50)

# Alternative method using max() function
largest_alt = max(num1, num2, num3)
print(f"Verification using max(): {largest_alt}")

# Additional comparisons
smallest = min(num1, num2, num3)
middle = num1 + num2 + num3 - largest - smallest

print(f"\nSmallest: {smallest}")
print(f"Middle: {middle}")
print(f"Largest: {largest}")
