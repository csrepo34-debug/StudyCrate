# Practice: Even or Odd Checker
# Determine if a number is even or odd using modulus operator

print("EVEN OR ODD CHECKER")
print("=" * 50)
print()

# Get number from user
number = int(input("Enter a number: "))

# Check if even or odd using modulus operator
# Even numbers have remainder 0 when divided by 2
# Odd numbers have remainder 1 when divided by 2
remainder = number % 2

print("\n" + "=" * 50)
print("RESULT")
print("=" * 50)

print(f"\nNumber: {number}")
print(f"Remainder when divided by 2: {remainder}")

if remainder == 0:
    print(f"{number} is EVEN")
else:
    print(f"{number} is ODD")

print("\n" + "=" * 50)

# Alternative method using comparison
is_even = (number % 2 == 0)
print(f"\nUsing boolean: Is {number} even? {is_even}")
