# Assignment Operators
# Assigning and modifying variable values

print("ASSIGNMENT OPERATORS")
print("=" * 50)

# Simple assignment
x = 10
print(f"x = {x}")

print("\n" + "=" * 50)

# Add and assign
print("\nADD AND ASSIGN (+=):")
x = 10
print(f"Initial: x = {x}")
x += 5  # Same as: x = x + 5
print(f"After x += 5: x = {x}")

print("\n" + "=" * 50)

# Subtract and assign
print("\nSUBTRACT AND ASSIGN (-=):")
x = 20
print(f"Initial: x = {x}")
x -= 7  # Same as: x = x - 7
print(f"After x -= 7: x = {x}")

print("\n" + "=" * 50)

# Multiply and assign
print("\nMULTIPLY AND ASSIGN (*=):")
x = 5
print(f"Initial: x = {x}")
x *= 3  # Same as: x = x * 3
print(f"After x *= 3: x = {x}")

print("\n" + "=" * 50)

# Divide and assign
print("\nDIVIDE AND ASSIGN (/=):")
x = 20
print(f"Initial: x = {x}")
x /= 4  # Same as: x = x / 4
print(f"After x /= 4: x = {x}")

print("\n" + "=" * 50)

# Floor divide and assign
print("\nFLOOR DIVIDE AND ASSIGN (//=):")
x = 25
print(f"Initial: x = {x}")
x //= 4  # Same as: x = x // 4
print(f"After x //= 4: x = {x}")

print("\n" + "=" * 50)

# Modulus and assign
print("\nMODULUS AND ASSIGN (%=):")
x = 25
print(f"Initial: x = {x}")
x %= 4  # Same as: x = x % 4
print(f"After x %= 4: x = {x}")

print("\n" + "=" * 50)

# Exponent and assign
print("\nEXPONENT AND ASSIGN (**=):")
x = 3
print(f"Initial: x = {x}")
x **= 3  # Same as: x = x ** 3
print(f"After x **= 3: x = {x}")

print("\n" + "=" * 50)

# Practical example
print("\nPRACTICAL EXAMPLE - Shopping Cart:")
cart_total = 0
print(f"Initial cart: ${cart_total}")

cart_total += 29.99
print(f"Added item ($29.99): ${cart_total}")

cart_total += 15.50
print(f"Added item ($15.50): ${cart_total}")

cart_total *= 0.9  # 10% discount
print(f"After 10% discount: ${cart_total:.2f}")
