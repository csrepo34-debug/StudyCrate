# Lists Basics
# Understanding Python lists

print("PYTHON LISTS")
print("=" * 50)

# Creating lists
print("\nCreating lists:")
numbers = [1, 2, 3, 4, 5]
fruits = ["apple", "banana", "cherry"]
mixed = [1, "hello", 3.14, True]
empty = []

print(f"Numbers: {numbers}")
print(f"Fruits: {fruits}")
print(f"Mixed: {mixed}")
print(f"Empty: {empty}")

print("\n" + "=" * 50)

# Accessing elements
print("\nAccessing elements:")
print(f"First fruit: {fruits[0]}")
print(f"Last fruit: {fruits[-1]}")
print(f"Second fruit: {fruits[1]}")

print("\n" + "=" * 50)

# Slicing
print("\nList slicing:")
numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(f"Original: {numbers}")
print(f"First 5: {numbers[:5]}")
print(f"Last 5: {numbers[-5:]}")
print(f"Middle: {numbers[3:7]}")
print(f"Every 2nd: {numbers[::2]}")
print(f"Reverse: {numbers[::-1]}")

print("\n" + "=" * 50)

# Modifying lists
print("\nModifying lists:")
colors = ["red", "green", "blue"]
print(f"Original: {colors}")

colors[1] = "yellow"
print(f"After changing index 1: {colors}")

colors.append("purple")
print(f"After append: {colors}")

colors.insert(1, "orange")
print(f"After insert at 1: {colors}")

colors.remove("blue")
print(f"After removing blue: {colors}")

popped = colors.pop()
print(f"After pop: {colors}, Popped: {popped}")

print("\n" + "=" * 50)

# List operations
print("\nList operations:")
list1 = [1, 2, 3]
list2 = [4, 5, 6]

print(f"List1: {list1}")
print(f"List2: {list2}")
print(f"Concatenation: {list1 + list2}")
print(f"Repetition: {list1 * 3}")
print(f"Length: {len(list1)}")
print(f"3 in list1: {3 in list1}")
print(f"7 in list1: {7 in list1}")
