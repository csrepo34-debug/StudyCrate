# Lists Methods
# Exploring various list methods

print("LIST METHODS")
print("=" * 50)

# append() - Add to end
print("\nappend() - Add to end:")
fruits = ["apple", "banana"]
print(f"Original: {fruits}")
fruits.append("cherry")
print(f"After append('cherry'): {fruits}")

print("\n" + "=" * 50)

# insert() - Add at position
print("\ninsert() - Add at position:")
fruits.insert(1, "mango")
print(f"After insert(1, 'mango'): {fruits}")

print("\n" + "=" * 50)

# extend() - Add multiple items
print("\nextend() - Add multiple items:")
fruits.extend(["orange", "grape"])
print(f"After extend(['orange', 'grape']): {fruits}")

print("\n" + "=" * 50)

# remove() - Remove by value
print("\nremove() - Remove by value:")
fruits.remove("banana")
print(f"After remove('banana'): {fruits}")

print("\n" + "=" * 50)

# pop() - Remove by index
print("\npop() - Remove by index:")
removed = fruits.pop(2)
print(f"After pop(2): {fruits}")
print(f"Removed item: {removed}")

print("\n" + "=" * 50)

# clear() - Remove all
print("\nclear() - Remove all:")
temp_list = [1, 2, 3]
print(f"Before clear: {temp_list}")
temp_list.clear()
print(f"After clear: {temp_list}")

print("\n" + "=" * 50)

# index() - Find position
print("\nindex() - Find position:")
colors = ["red", "green", "blue", "red"]
print(f"List: {colors}")
print(f"Index of 'blue': {colors.index('blue')}")
print(f"Index of first 'red': {colors.index('red')}")

print("\n" + "=" * 50)

# count() - Count occurrences
print("\ncount() - Count occurrences:")
numbers = [1, 2, 3, 2, 4, 2, 5]
print(f"List: {numbers}")
print(f"Count of 2: {numbers.count(2)}")
print(f"Count of 5: {numbers.count(5)}")
print(f"Count of 9: {numbers.count(9)}")

print("\n" + "=" * 50)

# sort() - Sort in place
print("\nsort() - Sort in place:")
nums = [5, 2, 8, 1, 9]
print(f"Original: {nums}")
nums.sort()
print(f"After sort(): {nums}")
nums.sort(reverse=True)
print(f"After sort(reverse=True): {nums}")

print("\n" + "=" * 50)

# reverse() - Reverse in place
print("\nreverse() - Reverse in place:")
items = [1, 2, 3, 4, 5]
print(f"Original: {items}")
items.reverse()
print(f"After reverse(): {items}")

print("\n" + "=" * 50)

# copy() - Create a copy
print("\ncopy() - Create a copy:")
original = [1, 2, 3]
copied = original.copy()
copied.append(4)
print(f"Original: {original}")
print(f"Copy: {copied}")
