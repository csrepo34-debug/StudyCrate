# Sets
# Understanding unique unordered collections

print("PYTHON SETS")
print("=" * 50)

# Creating sets
print("\nCreating sets:")
numbers = {1, 2, 3, 4, 5}
fruits = {"apple", "banana", "cherry"}
mixed = {1, "hello", 3.14, True}
empty = set()  # Note: {} creates dict, not set

print(f"Numbers: {numbers}")
print(f"Fruits: {fruits}")
print(f"Mixed: {mixed}")
print(f"Empty: {empty}")

print("\n" + "=" * 50)

# Unique elements
print("\nSets contain only unique elements:")
duplicates = {1, 2, 2, 3, 3, 3, 4}
print(f"Set with duplicates {1, 2, 2, 3, 3, 3, 4}: {duplicates}")

from_list = set([1, 2, 2, 3, 4, 4, 5])
print(f"Set from list [1,2,2,3,4,4,5]: {from_list}")

print("\n" + "=" * 50)

# Adding elements
print("\nAdding elements:")
colors = {"red", "green"}
print(f"Original: {colors}")

colors.add("blue")
print(f"After add('blue'): {colors}")

colors.update(["yellow", "purple"])
print(f"After update(['yellow', 'purple']): {colors}")

print("\n" + "=" * 50)

# Removing elements
print("\nRemoving elements:")
items = {"a", "b", "c", "d"}
print(f"Original: {items}")

items.remove("b")
print(f"After remove('b'): {items}")

items.discard("c")
print(f"After discard('c'): {items}")

items.discard("z")  # No error if not found
print(f"After discard('z'): {items} (no error)")

print("\n" + "=" * 50)

# Set operations
print("\nSet operations:")
set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}

print(f"Set1: {set1}")
print(f"Set2: {set2}")
print()

print(f"Union (|): {set1 | set2}")
print(f"Intersection (&): {set1 & set2}")
print(f"Difference (-): {set1 - set2}")
print(f"Symmetric Difference (^): {set1 ^ set2}")

print("\n" + "=" * 50)

# Set methods for operations
print("\nSet methods for operations:")
a = {1, 2, 3}
b = {3, 4, 5}

print(f"Set A: {a}")
print(f"Set B: {b}")
print()

print(f"a.union(b): {a.union(b)}")
print(f"a.intersection(b): {a.intersection(b)}")
print(f"a.difference(b): {a.difference(b)}")
print(f"a.symmetric_difference(b): {a.symmetric_difference(b)}")

print("\n" + "=" * 50)

# Set membership
print("\nSet membership:")
vowels = {"a", "e", "i", "o", "u"}
print(f"Vowels: {vowels}")
print(f"'a' in vowels: {'a' in vowels}")
print(f"'b' in vowels: {'b' in vowels}")
print(f"Length: {len(vowels)}")

print("\n" + "=" * 50)

# Practical example
print("\nPractical example - Remove duplicates:")
numbers_list = [1, 2, 3, 2, 4, 3, 5, 1]
print(f"Original list: {numbers_list}")

unique_numbers = set(numbers_list)
print(f"As set: {unique_numbers}")

unique_list = list(unique_numbers)
print(f"Back to list: {unique_list}")
