# Tuples
# Understanding immutable sequences

print("PYTHON TUPLES")
print("=" * 50)

# Creating tuples
print("\nCreating tuples:")
coordinates = (10, 20)
colors = ("red", "green", "blue")
single = (42,)  # Note the comma
numbers = (1, 2, 3, 4, 5)
mixed = (1, "hello", 3.14, True)

print(f"Coordinates: {coordinates}")
print(f"Colors: {colors}")
print(f"Single element: {single}")
print(f"Numbers: {numbers}")
print(f"Mixed: {mixed}")

print("\n" + "=" * 50)

# Accessing elements
print("\nAccessing elements:")
print(f"First color: {colors[0]}")
print(f"Last color: {colors[-1]}")
print(f"Second color: {colors[1]}")

print("\n" + "=" * 50)

# Slicing
print("\nTuple slicing:")
print(f"Original: {numbers}")
print(f"First 3: {numbers[:3]}")
print(f"Last 2: {numbers[-2:]}")
print(f"Middle: {numbers[1:4]}")

print("\n" + "=" * 50)

# Tuple methods
print("\nTuple methods:")
items = (1, 2, 3, 2, 4, 2, 5)
print(f"Tuple: {items}")
print(f"Count of 2: {items.count(2)}")
print(f"Index of 4: {items.index(4)}")

print("\n" + "=" * 50)

# Tuple unpacking
print("\nTuple unpacking:")
point = (100, 200)
x, y = point
print(f"Point: {point}")
print(f"x = {x}, y = {y}")

person = ("Alice", 25, "Engineer")
name, age, job = person
print(f"\nPerson: {person}")
print(f"Name: {name}, Age: {age}, Job: {job}")

print("\n" + "=" * 50)

# Immutability
print("\nTuples are immutable:")
my_tuple = (1, 2, 3)
print(f"Original: {my_tuple}")
# my_tuple[0] = 10  # This would cause an error!
print("Cannot modify tuple elements")

# But can create new tuple
new_tuple = my_tuple + (4, 5)
print(f"New tuple (concatenation): {new_tuple}")

print("\n" + "=" * 50)

# Why use tuples
print("\nWhy use tuples:")
print("1. Faster than lists")
print("2. Protect data from modification")
print("3. Can be used as dictionary keys")
print("4. Return multiple values from functions")

print("\n" + "=" * 50)

# Tuple operations
print("\nTuple operations:")
tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)
print(f"Tuple1: {tuple1}")
print(f"Tuple2: {tuple2}")
print(f"Concatenation: {tuple1 + tuple2}")
print(f"Repetition: {tuple1 * 3}")
print(f"Length: {len(tuple1)}")
print(f"2 in tuple1: {2 in tuple1}")
