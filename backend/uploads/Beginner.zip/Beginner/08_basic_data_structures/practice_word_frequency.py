# Practice: Word Frequency Counter
# Count frequency of words using dictionaries

def count_word_frequency(text):
    """Count frequency of each word in text"""
    # Convert to lowercase and split into words
    words = text.lower().split()
    
    # Create frequency dictionary
    frequency = {}
    
    for word in words:
        # Remove punctuation
        word = word.strip('.,!?;:"\'')
        
        if word:  # Skip empty strings
            if word in frequency:
                frequency[word] += 1
            else:
                frequency[word] = 1
    
    return frequency


def display_frequency(frequency_dict, sort_by="word"):
    """Display word frequencies"""
    if sort_by == "word":
        # Sort alphabetically by word
        sorted_items = sorted(frequency_dict.items())
    else:
        # Sort by frequency (descending)
        sorted_items = sorted(frequency_dict.items(), key=lambda x: x[1], reverse=True)
    
    print(f"\n{'Word':<15} {'Frequency':>10}")
    print("-" * 27)
    for word, count in sorted_items:
        print(f"{word:<15} {count:>10}")


# Main program
print("WORD FREQUENCY COUNTER")
print("=" * 50)

# Example 1: Simple text
text1 = "hello world hello python world python programming"
print(f"\nText: {text1}")
freq1 = count_word_frequency(text1)
display_frequency(freq1)

print("\n" + "=" * 50)

# Example 2: Longer text
text2 = """
Python is a great programming language. 
Python is easy to learn and Python is powerful.
Many developers love Python because Python is versatile.
"""

print(f"\nText: {text2.strip()}")
freq2 = count_word_frequency(text2)

print("\nSorted by word:")
display_frequency(freq2, sort_by="word")

print("\nSorted by frequency:")
display_frequency(freq2, sort_by="frequency")

print("\n" + "=" * 50)

# Example 3: Find most common words
print("\nMost common words:")
sorted_by_freq = sorted(freq2.items(), key=lambda x: x[1], reverse=True)

top_5 = sorted_by_freq[:5]
print("\nTop 5 words:")
for i, (word, count) in enumerate(top_5, 1):
    print(f"{i}. '{word}': {count} times")

print("\n" + "=" * 50)

# Example 4: Statistics
total_words = sum(freq2.values())
unique_words = len(freq2)

print("\nStatistics:")
print(f"Total words: {total_words}")
print(f"Unique words: {unique_words}")
print(f"Average frequency: {total_words/unique_words:.2f}")

print("\n" + "=" * 50)

# Interactive mode
print("\nInteractive Mode:")
user_text = input("Enter a sentence: ")

if user_text:
    user_freq = count_word_frequency(user_text)
    
    print(f"\nYou entered {len(user_text.split())} words")
    print(f"Unique words: {len(user_freq)}")
    
    display_frequency(user_freq, sort_by="frequency")
    
    # Find most repeated word
    if user_freq:
        most_common = max(user_freq, key=user_freq.get)
        print(f"\nMost repeated word: '{most_common}' ({user_freq[most_common]} times)")

print("\n" + "=" * 50)
