# Output Formatting with print()
# Exploring different ways to format output

print("BASIC PRINT EXAMPLES")
print("=" * 50)

# Multiple arguments
print("Python", "is", "awesome")
print("Value1:", 10, "Value2:", 20)

print("\n" + "=" * 50)

# Custom separator
print("\nCUSTOM SEPARATOR:")
print("Apple", "Banana", "Cherry", sep=" | ")
print("2026", "01", "19", sep="-")
print("Hello", "World", sep="")

print("\n" + "=" * 50)

# Custom ending
print("\nCUSTOM ENDING:")
print("This is line 1", end=" ")
print("This is line 2")
print("Loading", end="...")
print("Done!")

print("\n" + "=" * 50)

# Combining sep and end
print("\nCOMBINING SEP AND END:")
print("A", "B", "C", sep="-", end=" | ")
print("X", "Y", "Z", sep="-")

print("\n" + "=" * 50)

# Escape characters
print("\nESCAPE CHARACTERS:")
print("Line 1\nLine 2\nLine 3")  # \n = newline
print("Tab\tseparated\tvalues")  # \t = tab
print("He said, \"Python is great!\"")  # \" = quote
print("Path: C:\\Users\\Python")  # \\ = backslash
