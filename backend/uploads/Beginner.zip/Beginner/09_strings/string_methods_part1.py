# String Methods - Part 1
# Case conversion and searching methods

print("STRING METHODS - PART 1")
print("=" * 50)

# Case conversion methods
print("\nCase Conversion:")
text = "Python Programming"
print(f"Original: '{text}'")
print(f"upper(): '{text.upper()}'")
print(f"lower(): '{text.lower()}'")
print(f"capitalize(): '{text.capitalize()}'")
print(f"title(): '{text.title()}'")
print(f"swapcase(): '{text.swapcase()}'")

print("\n" + "=" * 50)

# Searching methods
print("\nSearching Methods:")
sentence = "Python is easy to learn. Python is powerful."
print(f"String: '{sentence}'")
print()

print(f"find('Python'): {sentence.find('Python')}")
print(f"find('Java'): {sentence.find('Java')}")  # Returns -1
print(f"rfind('Python'): {sentence.rfind('Python')}")  # Find from right
print(f"index('easy'): {sentence.index('easy')}")
print(f"count('Python'): {sentence.count('Python')}")
print(f"count('is'): {sentence.count('is')}")

print("\n" + "=" * 50)

# Checking start and end
print("\nChecking Start and End:")
filename = "document.pdf"
print(f"Filename: '{filename}'")
print(f"startswith('doc'): {filename.startswith('doc')}")
print(f"startswith('image'): {filename.startswith('image')}")
print(f"endswith('.pdf'): {filename.endswith('.pdf')}")
print(f"endswith('.txt'): {filename.endswith('.txt')}")

print("\n" + "=" * 50)

# Validation methods
print("\nValidation Methods:")

text1 = "hello"
print(f"'{text1}'.isalpha(): {text1.isalpha()}")
print(f"'{text1}'.islower(): {text1.islower()}")

text2 = "HELLO"
print(f"'{text2}'.isupper(): {text2.isupper()}")

text3 = "12345"
print(f"'{text3}'.isdigit(): {text3.isdigit()}")
print(f"'{text3}'.isnumeric(): {text3.isnumeric()}")

text4 = "hello123"
print(f"'{text4}'.isalnum(): {text4.isalnum()}")

text5 = "   "
print(f"'{text5}'.isspace(): {text5.isspace()}")

text6 = "Hello World"
print(f"'{text6}'.istitle(): {text6.istitle()}")

print("\n" + "=" * 50)

# Practical examples
print("\nPractical Examples:")

# Email validation (simple)
email = "user@example.com"
if "@" in email and "." in email:
    print(f"'{email}' looks like a valid email")

# Check if password contains digit
password = "secret123"
has_digit = any(char.isdigit() for char in password)
print(f"Password '{password}' contains digit: {has_digit}")

# File type check
files = ["image.jpg", "document.pdf", "script.py", "data.txt"]
print("\nImage files:")
for file in files:
    if file.endswith(('.jpg', '.png', '.gif')):
        print(f"  {file}")
