# Practice: Prime Number Checker
# Function to check if a number is prime

def is_prime(number):
    """
    Check if a number is prime.
    Returns True if prime, False otherwise.
    """
    # Handle special cases
    if number < 2:
        return False
    
    if number == 2:
        return True
    
    if number % 2 == 0:
        return False
    
    # Check odd divisors up to square root
    for i in range(3, int(number ** 0.5) + 1, 2):
        if number % i == 0:
            return False
    
    return True


def find_primes_in_range(start, end):
    """Find all prime numbers in a range"""
    primes = []
    for num in range(start, end + 1):
        if is_prime(num):
            primes.append(num)
    return primes


def prime_factorization(number):
    """Find prime factors of a number"""
    factors = []
    divisor = 2
    
    while number > 1:
        while number % divisor == 0:
            factors.append(divisor)
            number = number // divisor
        divisor += 1
        
        if divisor * divisor > number and number > 1:
            factors.append(number)
            break
    
    return factors


# Main program
print("PRIME NUMBER CHECKER")
print("=" * 50)
print()

# Test single numbers
test_numbers = [2, 3, 4, 5, 10, 17, 20, 29, 30, 37]

print("Checking individual numbers:")
for num in test_numbers:
    result = "Prime" if is_prime(num) else "Not Prime"
    print(f"{num}: {result}")

print("\n" + "=" * 50)

# Find primes in a range
print("\nPrime numbers from 1 to 50:")
primes = find_primes_in_range(1, 50)
print(primes)
print(f"Total: {len(primes)} prime numbers")

print("\n" + "=" * 50)

# Interactive prime checker
print("\nInteractive Prime Checker:")
user_num = int(input("Enter a number to check if it's prime: "))

if is_prime(user_num):
    print(f"{user_num} is a PRIME number!")
else:
    print(f"{user_num} is NOT a prime number.")
    factors = prime_factorization(user_num)
    print(f"Prime factorization: {' × '.join(map(str, factors))}")

print("\n" + "=" * 50)

# Find first N primes
print("\nFind first N prime numbers:")
n = int(input("How many prime numbers do you want? "))
count = 0
num = 2
primes_list = []

while count < n:
    if is_prime(num):
        primes_list.append(num)
        count += 1
    num += 1

print(f"First {n} prime numbers:")
print(primes_list)
