# Practice: Calculator Using Functions
# Complete calculator with functions for each operation

def add(a, b):
    """Add two numbers"""
    return a + b


def subtract(a, b):
    """Subtract b from a"""
    return a - b


def multiply(a, b):
    """Multiply two numbers"""
    return a * b


def divide(a, b):
    """Divide a by b"""
    if b == 0:
        return "Error: Division by zero"
    return a / b


def power(base, exponent):
    """Calculate base raised to exponent"""
    return base ** exponent


def modulus(a, b):
    """Find remainder of a divided by b"""
    if b == 0:
        return "Error: Division by zero"
    return a % b


def percentage(value, percent):
    """Calculate percentage of a value"""
    return (value * percent) / 100


def display_menu():
    """Display calculator menu"""
    print("\n" + "=" * 50)
    print("CALCULATOR MENU")
    print("=" * 50)
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Power")
    print("6. Modulus")
    print("7. Percentage")
    print("0. Exit")
    print("=" * 50)


def get_numbers():
    """Get two numbers from user"""
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))
    return num1, num2


def calculate(choice, num1, num2):
    """Perform calculation based on choice"""
    if choice == 1:
        result = add(num1, num2)
        print(f"{num1} + {num2} = {result}")
    elif choice == 2:
        result = subtract(num1, num2)
        print(f"{num1} - {num2} = {result}")
    elif choice == 3:
        result = multiply(num1, num2)
        print(f"{num1} × {num2} = {result}")
    elif choice == 4:
        result = divide(num1, num2)
        print(f"{num1} ÷ {num2} = {result}")
    elif choice == 5:
        result = power(num1, num2)
        print(f"{num1} ^ {num2} = {result}")
    elif choice == 6:
        result = modulus(num1, num2)
        print(f"{num1} % {num2} = {result}")
    elif choice == 7:
        result = percentage(num1, num2)
        print(f"{num2}% of {num1} = {result}")


# Main program
print("ADVANCED CALCULATOR")
print("=" * 50)

# Run calculator
while True:
    display_menu()
    
    try:
        choice = int(input("\nEnter your choice (0-7): "))
        
        if choice == 0:
            print("\nThank you for using the calculator!")
            print("Goodbye!")
            break
        
        if choice < 1 or choice > 7:
            print("Invalid choice! Please select 0-7.")
            continue
        
        num1, num2 = get_numbers()
        calculate(choice, num1, num2)
        
    except ValueError:
        print("Error: Please enter valid numbers!")
    except Exception as e:
        print(f"An error occurred: {e}")
    
    input("\nPress Enter to continue...")

print("\n" + "=" * 50)
