# Function Scope
# Understanding local and global variables

print("VARIABLE SCOPE IN FUNCTIONS")
print("=" * 50)

# Example 1: Local variables
def my_function():
    """Function with local variable"""
    local_var = 10  # Local to this function
    print(f"Inside function: local_var = {local_var}")

print("\nLocal variable example:")
my_function()
# print(local_var)  # This would cause an error!

print("\n" + "=" * 50)

# Example 2: Global variables
global_var = 100

def read_global():
    """Function reading global variable"""
    print(f"Inside function: global_var = {global_var}")

print("\nReading global variable:")
print(f"Outside function: global_var = {global_var}")
read_global()

print("\n" + "=" * 50)

# Example 3: Local variable shadows global
x = 50

def local_shadows_global():
    """Local variable with same name as global"""
    x = 20  # This is a new local variable
    print(f"Inside function: x = {x}")

print("\nLocal shadowing global:")
print(f"Before function: x = {x}")
local_shadows_global()
print(f"After function: x = {x}")  # Global unchanged

print("\n" + "=" * 50)

# Example 4: Modifying global variable
count = 0

def increment_global():
    """Modify global variable using global keyword"""
    global count
    count += 1
    print(f"Inside function: count = {count}")

print("\nModifying global variable:")
print(f"Initial: count = {count}")
increment_global()
increment_global()
increment_global()
print(f"Final: count = {count}")

print("\n" + "=" * 50)

# Example 5: Function parameters create local variables
def modify_parameter(value):
    """Parameters are local variables"""
    value = value * 2
    print(f"Inside function: value = {value}")
    return value

print("\nParameters are local:")
original = 10
print(f"Before: original = {original}")
result = modify_parameter(original)
print(f"After: original = {original}")  # Unchanged
print(f"Returned: result = {result}")
