# Function Parameters and Return Values
# Different types of parameters and return statements

print("PARAMETERS AND RETURN VALUES")
print("=" * 50)

# Example 1: Multiple return values
def get_min_max(numbers):
    """Return both minimum and maximum from a list"""
    return min(numbers), max(numbers)

print("\nReturning multiple values:")
nums = [5, 2, 8, 1, 9, 3]
minimum, maximum = get_min_max(nums)
print(f"Numbers: {nums}")
print(f"Min: {minimum}, Max: {maximum}")

print("\n" + "=" * 50)

# Example 2: Positional and keyword arguments
def student_info(name, age, grade, city="Unknown"):
    """Display student information"""
    print(f"Name: {name}")
    print(f"Age: {age}")
    print(f"Grade: {grade}")
    print(f"City: {city}")

print("\nPositional arguments:")
student_info("Alice", 20, "A")

print("\nKeyword arguments:")
student_info(name="Bob", grade="B", age=21, city="NYC")

print("\nMixed arguments:")
student_info("Charlie", 19, grade="A", city="LA")

print("\n" + "=" * 50)

# Example 3: Function returning different types
def divide(a, b):
    """Divide two numbers with error handling"""
    if b == 0:
        return "Error: Cannot divide by zero"
    return a / b

print("\nFunction with conditional return:")
print(f"10 / 2 = {divide(10, 2)}")
print(f"10 / 0 = {divide(10, 0)}")

print("\n" + "=" * 50)

# Example 4: Function with multiple default parameters
def create_profile(name, age=18, city="Unknown", country="Unknown"):
    """Create a user profile"""
    return {
        "name": name,
        "age": age,
        "city": city,
        "country": country
    }

print("\nMultiple default parameters:")
profile1 = create_profile("Alice")
profile2 = create_profile("Bob", 25)
profile3 = create_profile("Charlie", 30, "NYC", "USA")

print(f"Profile 1: {profile1}")
print(f"Profile 2: {profile2}")
print(f"Profile 3: {profile3}")

print("\n" + "=" * 50)

# Example 5: Function modifying and returning data
def double_list(numbers):
    """Return a new list with doubled values"""
    doubled = []
    for num in numbers:
        doubled.append(num * 2)
    return doubled

print("\nFunction returning new list:")
original = [1, 2, 3, 4, 5]
doubled = double_list(original)
print(f"Original: {original}")
print(f"Doubled: {doubled}")
