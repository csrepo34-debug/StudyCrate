# Type Casting in Python
# Converting one data type to another

print("TYPE CASTING EXAMPLES")
print("=" * 50)

# Integer to Float
num_int = 10
num_float = float(num_int)
print(f"Integer to Float: {num_int} -> {num_float}")
print(f"Types: {type(num_int)} -> {type(num_float)}")

print("\n" + "=" * 50)

# Float to Integer (truncates decimal part)
decimal = 9.99
integer = int(decimal)
print(f"Float to Integer: {decimal} -> {integer}")
print(f"Types: {type(decimal)} -> {type(integer)}")

print("\n" + "=" * 50)

# String to Integer
str_num = "123"
converted_int = int(str_num)
print(f"String to Integer: '{str_num}' -> {converted_int}")
print(f"Types: {type(str_num)} -> {type(converted_int)}")

print("\n" + "=" * 50)

# String to Float
str_decimal = "45.67"
converted_float = float(str_decimal)
print(f"String to Float: '{str_decimal}' -> {converted_float}")
print(f"Types: {type(str_decimal)} -> {type(converted_float)}")

print("\n" + "=" * 50)

# Number to String
number = 100
str_number = str(number)
print(f"Number to String: {number} -> '{str_number}'")
print(f"Types: {type(number)} -> {type(str_number)}")

print("\n" + "=" * 50)

# Boolean Conversion
print("Boolean Conversions:")
print(f"bool(1) = {bool(1)}")
print(f"bool(0) = {bool(0)}")
print(f"bool('Hello') = {bool('Hello')}")
print(f"bool('') = {bool('')}")
print(f"int(True) = {int(True)}")
print(f"int(False) = {int(False)}")
