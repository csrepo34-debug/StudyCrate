# Practice: Store name, age, marks
# This program demonstrates storing and displaying different types of data

# Storing student information
student_name = "John Doe"
student_age = 18
marks_math = 95
marks_science = 87.5
marks_english = 92
is_passed = True

# Displaying student information
print("STUDENT INFORMATION")
print("=" * 50)
print(f"Name: {student_name}")
print(f"Age: {student_age} years")
print(f"Passed: {is_passed}")
print()

print("MARKS:")
print(f"Mathematics: {marks_math}")
print(f"Science: {marks_science}")
print(f"English: {marks_english}")
print()

# Calculating average
total_marks = marks_math + marks_science + marks_english
average = total_marks / 3

print("RESULTS:")
print(f"Total Marks: {total_marks}")
print(f"Average: {average:.2f}")

# Checking types
print()
print("DATA TYPES:")
print(f"Name type: {type(student_name)}")
print(f"Age type: {type(student_age)}")
print(f"Marks type: {type(marks_math)}")
print(f"Average type: {type(average)}")
print(f"Passed type: {type(is_passed)}")
