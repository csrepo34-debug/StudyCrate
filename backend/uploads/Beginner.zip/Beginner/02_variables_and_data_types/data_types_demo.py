# Data Types in Python
# Exploring int, float, str, bool

# INTEGER (int) - Whole numbers
age = 25
year = 2026
temperature = -5

print("INTEGER Examples:")
print(f"Age: {age}, Type: {type(age)}")
print(f"Year: {year}, Type: {type(year)}")
print(f"Temperature: {temperature}, Type: {type(temperature)}")

print("\n" + "=" * 50)

# FLOAT (float) - Decimal numbers
price = 99.99
pi = 3.14159
height = 5.8

print("FLOAT Examples:")
print(f"Price: {price}, Type: {type(price)}")
print(f"Pi: {pi}, Type: {type(pi)}")
print(f"Height: {height}, Type: {type(height)}")

print("\n" + "=" * 50)

# STRING (str) - Text data
name = "Python"
message = 'Hello, World!'
mixed = "I am 25 years old"

print("STRING Examples:")
print(f"Name: {name}, Type: {type(name)}")
print(f"Message: {message}, Type: {type(message)}")
print(f"Mixed: {mixed}, Type: {type(mixed)}")

print("\n" + "=" * 50)

# BOOLEAN (bool) - True or False
is_active = True
has_license = False

print("BOOLEAN Examples:")
print(f"Is Active: {is_active}, Type: {type(is_active)}")
print(f"Has License: {has_license}, Type: {type(has_license)}")
