# Understanding Variables in Python
# Variables are containers for storing data

# Creating variables (no declaration needed)
name = "Alice"
age = 25
height = 5.6
is_student = True

# Displaying variables
print("Variable Examples:")
print("Name:", name)
print("Age:", age)
print("Height:", height)
print("Is Student:", is_student)

print("\n" + "=" * 40)

# Variables can change
print("\nChanging Variables:")
age = 26
print("Updated Age:", age)

# Multiple assignment
x, y, z = 10, 20, 30
print("\nMultiple Assignment:")
print(f"x = {x}, y = {y}, z = {z}")

# Same value to multiple variables
a = b = c = 100
print(f"\nSame value: a = {a}, b = {b}, c = {c}")
