# If-Elif-Else Statement
# Testing multiple conditions

print("IF-ELIF-ELSE STATEMENT EXAMPLES")
print("=" * 50)

# Example 1: Grade system
marks = 78
print(f"Marks: {marks}")

if marks >= 90:
    grade = "A+"
    print("Grade: A+ (Excellent!)")
elif marks >= 80:
    grade = "A"
    print("Grade: A (Very Good)")
elif marks >= 70:
    grade = "B"
    print("Grade: B (Good)")
elif marks >= 60:
    grade = "C"
    print("Grade: C (Average)")
elif marks >= 50:
    grade = "D"
    print("Grade: D (Pass)")
else:
    grade = "F"
    print("Grade: F (Fail)")

print("\n" + "=" * 50)

# Example 2: Temperature classification
temperature = 15
print(f"\nTemperature: {temperature}°C")

if temperature > 35:
    print("Extremely Hot")
elif temperature > 25:
    print("Hot")
elif temperature > 15:
    print("Warm")
elif temperature > 5:
    print("Cool")
else:
    print("Cold")

print("\n" + "=" * 50)

# Example 3: Age categories
age = 35
print(f"\nAge: {age}")

if age < 0:
    print("Invalid age")
elif age < 13:
    print("Child")
elif age < 20:
    print("Teenager")
elif age < 60:
    print("Adult")
else:
    print("Senior Citizen")

print("\n" + "=" * 50)

# Example 4: Day of week
day = 3
print(f"\nDay number: {day}")

if day == 1:
    print("Monday")
elif day == 2:
    print("Tuesday")
elif day == 3:
    print("Wednesday")
elif day == 4:
    print("Thursday")
elif day == 5:
    print("Friday")
elif day == 6:
    print("Saturday")
elif day == 7:
    print("Sunday")
else:
    print("Invalid day number")
