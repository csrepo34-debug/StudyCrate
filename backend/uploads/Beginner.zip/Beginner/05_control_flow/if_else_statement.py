# If-Else Statement
# Providing alternative code paths

print("IF-ELSE STATEMENT EXAMPLES")
print("=" * 50)

# Example 1: Basic if-else
age = 15
print(f"Age: {age}")

if age >= 18:
    print("You can vote")
else:
    print("You cannot vote yet")

print("\n" + "=" * 50)

# Example 2: Even or odd
number = 7
print(f"\nNumber: {number}")

if number % 2 == 0:
    print(f"{number} is even")
else:
    print(f"{number} is odd")

print("\n" + "=" * 50)

# Example 3: Pass or fail
marks = 45
passing_marks = 50
print(f"\nMarks: {marks}")
print(f"Passing marks: {passing_marks}")

if marks >= passing_marks:
    print("Result: PASS")
else:
    print("Result: FAIL")

print("\n" + "=" * 50)

# Example 4: Positive or negative
num = -5
print(f"\nNumber: {num}")

if num >= 0:
    print(f"{num} is positive")
else:
    print(f"{num} is negative")

print("\n" + "=" * 50)

# Example 5: Login check
password = "secret123"
user_input = "secret123"

print(f"\nAttempting login...")

if user_input == password:
    print("Login successful!")
else:
    print("Incorrect password!")
