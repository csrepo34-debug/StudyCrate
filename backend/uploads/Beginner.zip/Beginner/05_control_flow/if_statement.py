# If Statement Basics
# Simple if conditions

print("IF STATEMENT EXAMPLES")
print("=" * 50)

# Example 1: Simple if
age = 20
print(f"Age: {age}")

if age >= 18:
    print("You are an adult")

print("\n" + "=" * 50)

# Example 2: Checking multiple conditions
temperature = 35
print(f"\nTemperature: {temperature}°C")

if temperature > 30:
    print("It's hot outside!")

if temperature > 40:
    print("It's extremely hot!")

print("\n" + "=" * 50)

# Example 3: Boolean variable
is_raining = True
print(f"\nIs it raining? {is_raining}")

if is_raining:
    print("Take an umbrella")

print("\n" + "=" * 50)

# Example 4: String comparison
username = "admin"
print(f"\nUsername: {username}")

if username == "admin":
    print("Welcome, Administrator!")

print("\n" + "=" * 50)

# Example 5: Numeric comparison
score = 95
print(f"\nScore: {score}")

if score >= 90:
    print("Excellent performance!")

if score >= 75:
    print("Good job!")

if score >= 50:
    print("You passed!")
