# Practice: Sum of Digits
# Calculate sum of digits of a number

print("SUM OF DIGITS CALCULATOR")
print("=" * 50)
print()

# Get number from user
number = int(input("Enter a number: "))
original_number = number  # Store original for display

# Calculate sum of digits
sum_of_digits = 0

print("\nBreaking down the digits:")
while number > 0:
    digit = number % 10  # Get last digit
    print(f"Extracted digit: {digit}")
    sum_of_digits += digit
    number = number // 10  # Remove last digit

print("\n" + "=" * 50)
print("RESULT")
print("=" * 50)

print(f"\nOriginal number: {original_number}")
print(f"Sum of digits: {sum_of_digits}")

print("\n" + "=" * 50)

# Alternative method using string conversion
print("\nAlternative method (using strings):")
number_str = str(original_number)
sum_alt = 0

for digit_char in number_str:
    digit = int(digit_char)
    sum_alt += digit
    print(f"{digit}", end=" + " if digit != int(number_str[-1]) else "")

print(f" = {sum_alt}")

print("\n" + "=" * 50)

# Additional examples
print("\nMore examples:")
test_numbers = [123, 456, 789, 1000, 9999]

for num in test_numbers:
    digit_sum = sum(int(d) for d in str(num))
    print(f"Sum of digits in {num}: {digit_sum}")
