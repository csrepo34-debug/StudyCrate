# Practice: Save User Data to File
# Collecting and storing user information

def collect_user_data():
    """Collect user information"""
    print("USER REGISTRATION")
    print("=" * 50)
    print()
    
    name = input("Enter your name: ")
    age = input("Enter your age: ")
    email = input("Enter your email: ")
    city = input("Enter your city: ")
    phone = input("Enter your phone number: ")
    
    return {
        'name': name,
        'age': age,
        'email': email,
        'city': city,
        'phone': phone
    }


def save_user_data(user_data, filename="user_data.txt"):
    """Save user data to file"""
    try:
        with open(filename, "a") as file:
            file.write("=" * 50 + "\n")
            file.write("USER RECORD\n")
            file.write("=" * 50 + "\n")
            file.write(f"Name: {user_data['name']}\n")
            file.write(f"Age: {user_data['age']}\n")
            file.write(f"Email: {user_data['email']}\n")
            file.write(f"City: {user_data['city']}\n")
            file.write(f"Phone: {user_data['phone']}\n")
            file.write("\n")
        
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False


def save_user_data_csv(user_data, filename="users.csv"):
    """Save user data in CSV format"""
    import os
    
    # Check if file exists
    file_exists = os.path.exists(filename)
    
    try:
        with open(filename, "a") as file:
            # Write header if file is new
            if not file_exists:
                file.write("Name,Age,Email,City,Phone\n")
            
            # Write data
            file.write(f"{user_data['name']},")
            file.write(f"{user_data['age']},")
            file.write(f"{user_data['email']},")
            file.write(f"{user_data['city']},")
            file.write(f"{user_data['phone']}\n")
        
        return True
    except Exception as e:
        print(f"Error saving CSV: {e}")
        return False


def display_all_users(filename="user_data.txt"):
    """Display all saved users"""
    try:
        with open(filename, "r") as file:
            content = file.read()
            if content:
                print("\nSAVED USER DATA:")
                print(content)
            else:
                print("No users found.")
    except FileNotFoundError:
        print("No user data file found. No users registered yet.")
    except Exception as e:
        print(f"Error reading file: {e}")


def count_users(filename="users.csv"):
    """Count total registered users"""
    try:
        with open(filename, "r") as file:
            lines = file.readlines()
            # Subtract 1 for header
            return len(lines) - 1 if len(lines) > 1 else 0
    except FileNotFoundError:
        return 0
    except Exception as e:
        print(f"Error counting users: {e}")
        return 0


# Main program
print("USER DATA MANAGEMENT SYSTEM")
print("=" * 50)

while True:
    print("\nMENU:")
    print("1. Register new user")
    print("2. View all users")
    print("3. Count total users")
    print("4. Exit")
    
    choice = input("\nEnter your choice (1-4): ")
    
    if choice == "1":
        # Collect and save user data
        user_data = collect_user_data()
        
        print("\n" + "=" * 50)
        print("CONFIRM YOUR DETAILS:")
        print("=" * 50)
        for key, value in user_data.items():
            print(f"{key.capitalize()}: {value}")
        
        confirm = input("\nSave this data? (yes/no): ").lower()
        
        if confirm == "yes":
            # Save in both formats
            if save_user_data(user_data) and save_user_data_csv(user_data):
                print("\nUser registered successfully!")
                print("Data saved to 'user_data.txt' and 'users.csv'")
            else:
                print("\nError saving user data!")
        else:
            print("\nRegistration cancelled.")
    
    elif choice == "2":
        # Display all users
        display_all_users()
    
    elif choice == "3":
        # Count users
        total = count_users()
        print(f"\nTotal registered users: {total}")
    
    elif choice == "4":
        print("\nThank you for using the system!")
        print("Goodbye!")
        break
    
    else:
        print("\nInvalid choice! Please select 1-4.")

print("\n" + "=" * 50)
