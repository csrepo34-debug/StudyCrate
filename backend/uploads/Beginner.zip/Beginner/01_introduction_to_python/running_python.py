# Running Python in Different Ways
# This file demonstrates different ways to run Python code

# 1. Interactive Shell (REPL)
# Open terminal and type: python
# Then type commands line by line
# Example:
# >>> print("Hello")
# >>> 2 + 2
# >>> exit()

# 2. Running Python Files
# Save this file and run: python filename.py

print("This is a Python script file")
print("=" * 40)

# Simple calculations
print("Simple Math:")
print("5 + 3 =", 5 + 3)
print("10 - 4 =", 10 - 4)
print("3 * 4 =", 3 * 4)

print("=" * 40)
print("Script executed successfully!")
