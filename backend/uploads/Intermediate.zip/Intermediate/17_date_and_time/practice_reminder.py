"""
Practice: Reminder Program
Create reminders with date and time tracking.
"""

from datetime import datetime, timedelta
import json
import os

REMINDERS_FILE = 'reminders.json'

def load_reminders():
    """Load reminders from file"""
    if os.path.exists(REMINDERS_FILE):
        with open(REMINDERS_FILE, 'r') as file:
            reminders = json.load(file)
            # Convert string dates back to datetime
            for reminder in reminders:
                reminder['datetime'] = datetime.fromisoformat(reminder['datetime'])
            return reminders
    return []

def save_reminders(reminders):
    """Save reminders to file"""
    # Convert datetime to string for JSON
    reminders_copy = []
    for reminder in reminders:
        r_copy = reminder.copy()
        r_copy['datetime'] = reminder['datetime'].isoformat()
        reminders_copy.append(r_copy)
    
    with open(REMINDERS_FILE, 'w') as file:
        json.dump(reminders_copy, file, indent=4)

def add_reminder():
    """Add a new reminder"""
    reminders = load_reminders()
    
    print("\n=== Add New Reminder ===")
    title = input("Reminder title: ")
    description = input("Description (optional): ")
    
    print("\nWhen should you be reminded?")
    print("1. Specific date and time")
    print("2. After X days")
    print("3. After X hours")
    
    choice = input("Choose option (1-3): ")
    
    if choice == '1':
        date_str = input("Enter date (YYYY-MM-DD): ")
        time_str = input("Enter time (HH:MM): ")
        datetime_str = f"{date_str} {time_str}"
        reminder_dt = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M")
    
    elif choice == '2':
        days = int(input("Number of days: "))
        reminder_dt = datetime.now() + timedelta(days=days)
    
    elif choice == '3':
        hours = int(input("Number of hours: "))
        reminder_dt = datetime.now() + timedelta(hours=hours)
    
    else:
        print("Invalid choice!")
        return
    
    reminder = {
        'id': len(reminders) + 1,
        'title': title,
        'description': description,
        'datetime': reminder_dt,
        'created': datetime.now().isoformat(),
        'completed': False
    }
    
    reminders.append(reminder)
    save_reminders(reminders)
    
    print(f"\n✓ Reminder added for {reminder_dt.strftime('%B %d, %Y at %I:%M %p')}")

def view_reminders():
    """View all reminders"""
    reminders = load_reminders()
    
    if not reminders:
        print("\n📭 No reminders found!")
        return
    
    now = datetime.now()
    
    # Separate into categories
    overdue = []
    upcoming = []
    completed = []
    
    for reminder in reminders:
        if reminder['completed']:
            completed.append(reminder)
        elif reminder['datetime'] < now:
            overdue.append(reminder)
        else:
            upcoming.append(reminder)
    
    # Display overdue
    if overdue:
        print("\n" + "="*60)
        print("⚠️  OVERDUE REMINDERS")
        print("="*60)
        for r in sorted(overdue, key=lambda x: x['datetime']):
            days_overdue = (now - r['datetime']).days
            print(f"\nID: {r['id']}")
            print(f"Title: {r['title']}")
            if r['description']:
                print(f"Description: {r['description']}")
            print(f"Due: {r['datetime'].strftime('%B %d, %Y at %I:%M %p')}")
            print(f"⚠️  {days_overdue} days overdue!")
    
    # Display upcoming
    if upcoming:
        print("\n" + "="*60)
        print("📅 UPCOMING REMINDERS")
        print("="*60)
        for r in sorted(upcoming, key=lambda x: x['datetime']):
            time_left = r['datetime'] - now
            days_left = time_left.days
            hours_left = time_left.seconds // 3600
            
            print(f"\nID: {r['id']}")
            print(f"Title: {r['title']}")
            if r['description']:
                print(f"Description: {r['description']}")
            print(f"Due: {r['datetime'].strftime('%B %d, %Y at %I:%M %p')}")
            
            if days_left > 0:
                print(f"⏰ In {days_left} days")
            elif hours_left > 0:
                print(f"⏰ In {hours_left} hours")
            else:
                minutes_left = time_left.seconds // 60
                print(f"⏰ In {minutes_left} minutes")
    
    # Display completed
    if completed:
        print("\n" + "="*60)
        print("✅ COMPLETED REMINDERS")
        print("="*60)
        for r in completed:
            print(f"\nID: {r['id']}")
            print(f"Title: {r['title']}")
            print(f"Was due: {r['datetime'].strftime('%B %d, %Y at %I:%M %p')}")

def check_due_reminders():
    """Check for reminders due now"""
    reminders = load_reminders()
    now = datetime.now()
    
    due_reminders = [r for r in reminders 
                     if not r['completed'] and r['datetime'] <= now]
    
    if due_reminders:
        print("\n" + "="*60)
        print("🔔 REMINDERS DUE NOW!")
        print("="*60)
        
        for r in due_reminders:
            print(f"\n⏰ {r['title']}")
            if r['description']:
                print(f"   {r['description']}")
            print(f"   Due: {r['datetime'].strftime('%B %d, %Y at %I:%M %p')}")
        
        return len(due_reminders)
    
    print("\n✓ No reminders due right now")
    return 0

def mark_completed():
    """Mark a reminder as completed"""
    reminders = load_reminders()
    
    view_reminders()
    
    reminder_id = int(input("\nEnter reminder ID to mark as completed: "))
    
    for reminder in reminders:
        if reminder['id'] == reminder_id:
            reminder['completed'] = True
            save_reminders(reminders)
            print(f"\n✓ Reminder '{reminder['title']}' marked as completed!")
            return
    
    print("❌ Reminder not found!")

def delete_reminder():
    """Delete a reminder"""
    reminders = load_reminders()
    
    view_reminders()
    
    reminder_id = int(input("\nEnter reminder ID to delete: "))
    
    reminders = [r for r in reminders if r['id'] != reminder_id]
    
    # Reassign IDs
    for i, reminder in enumerate(reminders, 1):
        reminder['id'] = i
    
    save_reminders(reminders)
    print("✓ Reminder deleted!")

def upcoming_today():
    """Show reminders due today"""
    reminders = load_reminders()
    today = datetime.now().date()
    
    today_reminders = [r for r in reminders 
                       if not r['completed'] 
                       and r['datetime'].date() == today]
    
    if today_reminders:
        print("\n" + "="*60)
        print(f"📅 REMINDERS FOR TODAY ({today.strftime('%B %d, %Y')})")
        print("="*60)
        
        for r in sorted(today_reminders, key=lambda x: x['datetime']):
            print(f"\n⏰ {r['datetime'].strftime('%I:%M %p')} - {r['title']}")
            if r['description']:
                print(f"   {r['description']}")
    else:
        print(f"\n✓ No reminders for today!")

def get_statistics():
    """Display reminder statistics"""
    reminders = load_reminders()
    
    if not reminders:
        print("\nNo reminders to analyze!")
        return
    
    now = datetime.now()
    
    total = len(reminders)
    completed = len([r for r in reminders if r['completed']])
    overdue = len([r for r in reminders 
                   if not r['completed'] and r['datetime'] < now])
    upcoming = len([r for r in reminders 
                    if not r['completed'] and r['datetime'] >= now])
    
    print("\n" + "="*60)
    print("📊 REMINDER STATISTICS")
    print("="*60)
    print(f"Total reminders: {total}")
    print(f"Completed: {completed} ({completed/total*100:.1f}%)")
    print(f"Overdue: {overdue}")
    print(f"Upcoming: {upcoming}")

def main():
    """Main menu"""
    while True:
        print("\n" + "="*60)
        print("🔔 REMINDER PROGRAM")
        print("="*60)
        print("1. Add Reminder")
        print("2. View All Reminders")
        print("3. Check Due Reminders")
        print("4. Today's Reminders")
        print("5. Mark as Completed")
        print("6. Delete Reminder")
        print("7. Statistics")
        print("8. Exit")
        print("="*60)
        
        choice = input("Enter your choice (1-8): ")
        
        try:
            if choice == '1':
                add_reminder()
            elif choice == '2':
                view_reminders()
            elif choice == '3':
                check_due_reminders()
            elif choice == '4':
                upcoming_today()
            elif choice == '5':
                mark_completed()
            elif choice == '6':
                delete_reminder()
            elif choice == '7':
                get_statistics()
            elif choice == '8':
                print("\nGoodbye! 👋")
                break
            else:
                print("\n❌ Invalid choice! Please try again.")
        
        except ValueError as e:
            print(f"\n❌ Error: {e}")
        except KeyboardInterrupt:
            print("\n\nGoodbye! 👋")
            break

if __name__ == "__main__":
    main()
