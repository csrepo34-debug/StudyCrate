# Practice: Create a student grade management system using comprehensions

students_data = [
    {'name': 'Alice', 'scores': [85, 90, 92, 88]},
    {'name': 'Bob', 'scores': [70, 75, 68, 72]},
    {'name': 'Charlie', 'scores': [95, 98, 96, 94]},
    {'name': 'David', 'scores': [60, 65, 58, 62]},
    {'name': 'Eve', 'scores': [88, 85, 90, 87]}
]

# Calculate average for each student using dict comprehension
averages = {student['name']: sum(student['scores']) / len(student['scores']) 
            for student in students_data}
print("Student Averages:")
for name, avg in averages.items():
    print(f"{name}: {avg:.2f}")

# Find students who passed (average >= 70)
passed_students = {student['name']: sum(student['scores']) / len(student['scores']) 
                   for student in students_data 
                   if sum(student['scores']) / len(student['scores']) >= 70}
print("\nPassed Students:")
for name, avg in passed_students.items():
    print(f"{name}: {avg:.2f}")

# Get all unique scores across all students
all_scores = {score for student in students_data for score in student['scores']}
print(f"\nAll unique scores: {sorted(all_scores)}")

# Create grade distribution (A: 90+, B: 80-89, C: 70-79, F: <70)
def get_grade(avg):
    if avg >= 90:
        return 'A'
    elif avg >= 80:
        return 'B'
    elif avg >= 70:
        return 'C'
    else:
        return 'F'

grade_distribution = {student['name']: get_grade(sum(student['scores']) / len(student['scores']))
                      for student in students_data}
print("\nGrade Distribution:")
for name, grade in grade_distribution.items():
    print(f"{name}: {grade}")

# Count students per grade using nested comprehension
grades = list(grade_distribution.values())
grade_counts = {grade: grades.count(grade) for grade in set(grades)}
print("\nGrade Counts:", grade_counts)
