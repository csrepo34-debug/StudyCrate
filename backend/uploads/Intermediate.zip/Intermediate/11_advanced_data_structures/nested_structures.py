# Nested Data Structures Examples

# Nested lists
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

# Access elements
print("Element at [1][2]:", matrix[1][2])  # 6

# Iterate nested list
for row in matrix:
    for element in row:
        print(element, end=' ')
    print()

# Nested dictionary
students = {
    'Alice': {
        'age': 20,
        'grades': [85, 90, 92],
        'major': 'CS'
    },
    'Bob': {
        'age': 21,
        'grades': [78, 82, 88],
        'major': 'Math'
    }
}

# Access nested data
print("\nAlice's age:", students['Alice']['age'])
print("Alice's grades:", students['Alice']['grades'])
print("Bob's average:", sum(students['Bob']['grades']) / len(students['Bob']['grades']))

# List of dictionaries
products = [
    {'name': 'Laptop', 'price': 1200, 'quantity': 5},
    {'name': 'Mouse', 'price': 25, 'quantity': 50},
    {'name': 'Keyboard', 'price': 80, 'quantity': 30}
]

# Process list of dictionaries
for product in products:
    total_value = product['price'] * product['quantity']
    print(f"{product['name']}: ${total_value}")

# Dictionary of lists
courses = {
    'Math': ['Alice', 'Bob', 'Charlie'],
    'Physics': ['Alice', 'David'],
    'Chemistry': ['Bob', 'Eve', 'Frank']
}

print("\nStudents in Math:", courses['Math'])
print("Number of Physics students:", len(courses['Physics']))
