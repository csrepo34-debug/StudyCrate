# List Comprehension Examples

# Basic list comprehension
numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print("Squares:", squares)

# With condition
even_squares = [x**2 for x in numbers if x % 2 == 0]
print("Even squares:", even_squares)

# Multiple conditions
filtered = [x for x in range(1, 21) if x % 2 == 0 if x % 3 == 0]
print("Divisible by 2 and 3:", filtered)

# Nested list comprehension
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
flattened = [num for row in matrix for num in row]
print("Flattened matrix:", flattened)

# String manipulation
words = ['hello', 'world', 'python']
uppercase = [word.upper() for word in words]
print("Uppercase:", uppercase)

# If-else in list comprehension
numbers = [1, 2, 3, 4, 5, 6]
result = ['even' if x % 2 == 0 else 'odd' for x in numbers]
print("Even/Odd:", result)
