# Generator Expressions Examples

# Basic generator expression
numbers_gen = (x**2 for x in range(1, 6))
print("Generator object:", numbers_gen)
print("Values:", list(numbers_gen))

# Memory efficient iteration
large_squares = (x**2 for x in range(1000000))
first_five = [next(large_squares) for _ in range(5)]
print("\nFirst 5 squares:", first_five)

# With condition
even_squares = (x**2 for x in range(1, 21) if x % 2 == 0)
print("Even squares:", list(even_squares))

# Sum using generator
total = sum(x**2 for x in range(1, 11))
print("\nSum of squares 1-10:", total)

# File reading with generator
def read_large_file(filename):
    """Generator for reading large files line by line"""
    try:
        with open(filename, 'r') as f:
            for line in f:
                yield line.strip()
    except FileNotFoundError:
        print(f"File {filename} not found")

# Generator function
def fibonacci_gen(n):
    """Generate Fibonacci sequence"""
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

print("\nFibonacci sequence:")
for num in fibonacci_gen(10):
    print(num, end=' ')

# Infinite generator
def infinite_counter(start=0):
    """Infinite counter generator"""
    count = start
    while True:
        yield count
        count += 1

# Use with break
print("\n\nFirst 5 from infinite counter:")
counter = infinite_counter(10)
for i in range(5):
    print(next(counter), end=' ')
