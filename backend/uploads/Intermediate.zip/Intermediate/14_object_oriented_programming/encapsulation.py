# Encapsulation - Public, Protected, and Private Attributes

print("=== Encapsulation ===\n")

# Example 1: Public, Protected, Private attributes
class BankAccount:
    """Bank account with encapsulation"""
    
    def __init__(self, account_number, holder_name, balance=0):
        self.account_number = account_number    # Public
        self._holder_name = holder_name         # Protected (convention)
        self.__balance = balance                # Private (name mangling)
    
    # Public method
    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited ${amount}. New balance: ${self.__balance}")
        else:
            print("Invalid deposit amount")
    
    # Public method
    def withdraw(self, amount):
        if amount > 0:
            if amount <= self.__balance:
                self.__balance -= amount
                print(f"Withdrew ${amount}. New balance: ${self.__balance}")
            else:
                print("Insufficient funds")
        else:
            print("Invalid withdrawal amount")
    
    # Getter method
    def get_balance(self):
        return self.__balance
    
    # Setter method
    def set_balance(self, balance):
        if balance >= 0:
            self.__balance = balance
        else:
            print("Balance cannot be negative")
    
    # Protected method
    def _internal_transfer(self, amount):
        return amount * 0.99  # 1% fee
    
    # Private method
    def __calculate_interest(self, rate):
        return self.__balance * rate

# Create account
account = BankAccount("123456", "John Doe", 1000)

print("Account Number (public):", account.account_number)
print("Holder Name (protected):", account._holder_name)

# Try to access private attribute (won't work directly)
# print(account.__balance)  # This will cause an error

# Use getter to access private attribute
print(f"Balance (via getter): ${account.get_balance()}")

# Use public methods
print()
account.deposit(500)
account.withdraw(200)
print(f"Final balance: ${account.get_balance()}")

# Example 2: Property Decorators
class Person:
    """Person class with property decorators"""
    
    def __init__(self, name, age):
        self._name = name
        self._age = age
    
    @property
    def name(self):
        """Getter for name"""
        return self._name
    
    @name.setter
    def name(self, value):
        """Setter for name"""
        if isinstance(value, str) and len(value) > 0:
            self._name = value
        else:
            print("Invalid name")
    
    @property
    def age(self):
        """Getter for age"""
        return self._age
    
    @age.setter
    def age(self, value):
        """Setter for age with validation"""
        if isinstance(value, int) and 0 <= value <= 150:
            self._age = value
        else:
            print("Invalid age")
    
    @property
    def info(self):
        """Read-only property"""
        return f"{self._name}, {self._age} years old"

# Use property decorators
print("\n--- Property Decorators ---")
person = Person("Alice", 25)

# Use properties like attributes
print(f"Name: {person.name}")
print(f"Age: {person.age}")
print(person.info)

# Modify using setters
person.name = "Bob"
person.age = 30
print(f"\nUpdated: {person.info}")

# Try invalid values
person.age = -5  # Will show error
person.age = 200  # Will show error

# Example 3: Complete encapsulation example
class Temperature:
    """Temperature class with validation"""
    
    def __init__(self, celsius=0):
        self.__celsius = celsius
    
    @property
    def celsius(self):
        return self.__celsius
    
    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            print("Temperature below absolute zero is not possible")
        else:
            self.__celsius = value
    
    @property
    def fahrenheit(self):
        return (self.__celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        self.celsius = (value - 32) * 5/9
    
    def display(self):
        print(f"{self.__celsius:.2f}°C = {self.fahrenheit:.2f}°F")

print("\n--- Temperature Converter ---")
temp = Temperature(25)
temp.display()

temp.celsius = 100
temp.display()

temp.fahrenheit = 32
temp.display()

temp.celsius = -300  # Below absolute zero
