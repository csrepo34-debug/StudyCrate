"""
Sys Library Basics
The sys module provides access to system-specific parameters and functions.
"""

import sys

# Python version information
print("=== Python Version ===")
print(f"Version: {sys.version}")
print(f"Version info: {sys.version_info}")
print(f"Major: {sys.version_info.major}")
print(f"Minor: {sys.version_info.minor}")
print(f"Micro: {sys.version_info.micro}")

# Platform information
print("\n=== Platform Information ===")
print(f"Platform: {sys.platform}")
print(f"Executable: {sys.executable}")
print(f"Implementation: {sys.implementation.name}")

# Command line arguments
print("\n=== Command Line Arguments ===")
print(f"Script name: {sys.argv[0]}")
print(f"All arguments: {sys.argv}")
print(f"Number of arguments: {len(sys.argv)}")

if len(sys.argv) > 1:
    print("\nArguments passed:")
    for i, arg in enumerate(sys.argv[1:], 1):
        print(f"  Argument {i}: {arg}")
else:
    print("\nNo additional arguments passed")
    print("Run with: python sys_library.py arg1 arg2 arg3")

# Module search path
print("\n=== Module Search Path ===")
print("Python searches for modules in these directories:")
for i, path in enumerate(sys.path[:5], 1):
    print(f"  {i}. {path}")
if len(sys.path) > 5:
    print(f"  ... and {len(sys.path) - 5} more paths")

# Standard streams
print("\n=== Standard Streams ===")
print(f"Standard input: {sys.stdin}")
print(f"Standard output: {sys.stdout}")
print(f"Standard error: {sys.stderr}")

# Writing to stderr
sys.stderr.write("⚠️  This is an error message\n")

# Maximum integer size
print("\n=== Integer Information ===")
print(f"Max size (in digits): {sys.maxsize}")
print(f"Max unicode: {sys.maxunicode}")

# Recursion limit
print("\n=== Recursion Limit ===")
print(f"Current recursion limit: {sys.getrecursionlimit()}")
print("(Can be changed with sys.setrecursionlimit())")

# Reference count
print("\n=== Reference Count ===")
my_list = [1, 2, 3]
ref_count = sys.getrefcount(my_list)
print(f"Reference count of my_list: {ref_count}")
# Note: getrefcount adds 1 temporary reference

# Size of objects
print("\n=== Object Size in Memory ===")
objects = [
    (42, "int"),
    (3.14, "float"),
    ("Hello", "string"),
    ([1, 2, 3], "list"),
    ({'a': 1}, "dict"),
]

for obj, name in objects:
    size = sys.getsizeof(obj)
    print(f"  {name}: {size} bytes")

# Exit functions
print("\n=== Exit Functions ===")
print("sys.exit() - Exit the program")
print("sys.exit(0) - Exit with success code")
print("sys.exit(1) - Exit with error code")
print("sys.exit('Error message') - Exit with message")

# Float information
print("\n=== Float Information ===")
print(f"Float info: {sys.float_info}")
print(f"  Max float: {sys.float_info.max}")
print(f"  Min float: {sys.float_info.min}")
print(f"  Epsilon: {sys.float_info.epsilon}")

# Hash information
print("\n=== Hash Information ===")
print(f"Hash info: {sys.hash_info}")

# Byte order
print("\n=== Byte Order ===")
print(f"Byte order: {sys.byteorder}")

# Modules loaded
print("\n=== Loaded Modules ===")
print(f"Total modules loaded: {len(sys.modules)}")
print("Some loaded modules:")
for i, module in enumerate(list(sys.modules.keys())[:10]):
    print(f"  • {module}")

# Builtin module names
print("\n=== Builtin Modules ===")
print(f"Number of builtin modules: {len(sys.builtin_module_names)}")
print("Some builtin modules:")
for i, module in enumerate(sorted(sys.builtin_module_names)[:10]):
    print(f"  • {module}")

# Practical examples
print("\n" + "="*60)
print("=== Practical Examples ===\n")

# Command line argument processor
print("📝 Command Line Argument Processor:")
def process_arguments():
    if len(sys.argv) < 2:
        print("  No arguments provided")
        print("  Usage: python script.py <arg1> <arg2> ...")
        return
    
    for i, arg in enumerate(sys.argv[1:], 1):
        print(f"  Processing argument {i}: {arg}")

process_arguments()

# Memory usage checker
print("\n💾 Memory Usage:")
import random

small_list = [1, 2, 3]
medium_list = list(range(1000))
large_list = list(range(100000))

print(f"  Small list (3 items): {sys.getsizeof(small_list)} bytes")
print(f"  Medium list (1000 items): {sys.getsizeof(medium_list)} bytes")
print(f"  Large list (100000 items): {sys.getsizeof(large_list)} bytes")

# Version compatibility check
print("\n🐍 Python Version Check:")
def check_python_version(major, minor):
    if sys.version_info >= (major, minor):
        print(f"  ✓ Python {major}.{minor}+ detected")
        return True
    else:
        print(f"  ✗ Python {major}.{minor}+ required")
        return False

check_python_version(3, 6)
check_python_version(3, 9)

# Platform-specific code
print("\n💻 Platform-Specific Code:")
if sys.platform.startswith('win'):
    print("  Running on Windows")
elif sys.platform.startswith('linux'):
    print("  Running on Linux")
elif sys.platform.startswith('darwin'):
    print("  Running on macOS")
else:
    print(f"  Running on {sys.platform}")

# Encoding information
print("\n🔤 Encoding Information:")
print(f"  Default encoding: {sys.getdefaultencoding()}")
print(f"  File system encoding: {sys.getfilesystemencoding()}")

# Interactive mode check
print("\n🖥️  Interactive Mode:")
if hasattr(sys, 'ps1'):
    print("  Running in interactive mode")
else:
    print("  Running as script")

# Exception information
print("\n⚠️  Exception Information:")
print("When an exception occurs, use:")
print("  sys.exc_info() - Get current exception info")
print("  sys.last_type - Type of last exception")
print("  sys.last_value - Value of last exception")
print("  sys.last_traceback - Traceback of last exception")

# Example: Graceful exit
print("\n🚪 Graceful Exit Example:")
print("""
try:
    # Your code here
    pass
except KeyboardInterrupt:
    print("\\nInterrupted by user")
    sys.exit(0)
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
""")
