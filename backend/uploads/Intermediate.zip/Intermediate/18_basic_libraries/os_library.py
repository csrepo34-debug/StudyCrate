"""
OS Library Basics
The os module provides functions for interacting with the operating system.
"""

import os

# Current working directory
print("=== Current Working Directory ===")
cwd = os.getcwd()
print(f"Current directory: {cwd}")

# Change directory (commented out to avoid actually changing)
# os.chdir('path/to/directory')

# List directory contents
print("\n=== List Directory Contents ===")
contents = os.listdir('.')
print(f"Files and folders in current directory:")
for item in contents[:10]:  # Show first 10 items
    print(f"  • {item}")

if len(contents) > 10:
    print(f"  ... and {len(contents) - 10} more items")

# Get directory entries with more info
print("\n=== Directory Entries (with type) ===")
with os.scandir('.') as entries:
    for i, entry in enumerate(entries):
        if i >= 10:
            break
        item_type = "📁 DIR " if entry.is_dir() else "📄 FILE"
        print(f"  {item_type} {entry.name}")

# Path operations
print("\n=== Path Operations ===")
path = os.path.join('folder', 'subfolder', 'file.txt')
print(f"Joined path: {path}")

# Split path
directory, filename = os.path.split(path)
print(f"Directory: {directory}")
print(f"Filename: {filename}")

# Split extension
name, ext = os.path.splitext(filename)
print(f"Name: {name}")
print(f"Extension: {ext}")

# Absolute path
print(f"\nAbsolute path of '.': {os.path.abspath('.')}")

# Path existence checks
print("\n=== Path Checks ===")
test_path = '.'
print(f"Path: {test_path}")
print(f"  Exists: {os.path.exists(test_path)}")
print(f"  Is file: {os.path.isfile(test_path)}")
print(f"  Is directory: {os.path.isdir(test_path)}")
print(f"  Is absolute: {os.path.isabs(test_path)}")

# File/directory operations (examples - commented out)
print("\n=== File/Directory Operations (Examples) ===")
print("Create directory:")
print("  os.mkdir('new_folder')")
print("  os.makedirs('parent/child/grandchild')  # Create nested")

print("\nRename:")
print("  os.rename('old_name.txt', 'new_name.txt')")

print("\nRemove:")
print("  os.remove('file.txt')  # Remove file")
print("  os.rmdir('empty_folder')  # Remove empty directory")
print("  os.removedirs('parent/child')  # Remove nested empty dirs")

# Environment variables
print("\n=== Environment Variables ===")
print("Some environment variables:")

# Common environment variables
env_vars = ['PATH', 'HOME', 'USER', 'USERPROFILE', 'COMPUTERNAME', 'OS']
for var in env_vars:
    value = os.environ.get(var)
    if value:
        # Truncate long values
        display_value = value[:50] + '...' if len(value) > 50 else value
        print(f"  {var}: {display_value}")

# Get specific environment variable
home = os.environ.get('HOME') or os.environ.get('USERPROFILE')
print(f"\nHome directory: {home}")

# Process information
print("\n=== Process Information ===")
print(f"Process ID: {os.getpid()}")
print(f"Parent Process ID: {os.getppid()}")

# System information
print("\n=== System Information ===")
print(f"Operating System: {os.name}")

# Get detailed OS info (platform-specific)
try:
    import platform
    print(f"Platform: {platform.system()}")
    print(f"Release: {platform.release()}")
    print(f"Version: {platform.version()}")
except:
    pass

# Path separators
print("\n=== Path Separators ===")
print(f"Path separator: '{os.sep}'")
print(f"Alternative separator: '{os.altsep}'")
print(f"Path list separator: '{os.pathsep}'")
print(f"Line separator: {repr(os.linesep)}")

# File statistics
print("\n=== File Statistics ===")
current_file = __file__ if '__file__' in globals() else 'os_library.py'

if os.path.exists(current_file):
    stats = os.stat(current_file)
    print(f"File: {current_file}")
    print(f"  Size: {stats.st_size} bytes")
    print(f"  Created: {stats.st_ctime}")
    print(f"  Modified: {stats.st_mtime}")
    print(f"  Accessed: {stats.st_atime}")

# Walking directory tree
print("\n=== Walking Directory Tree ===")
print("Example of walking a directory tree:")
print("""
for root, dirs, files in os.walk('.'):
    print(f"Directory: {root}")
    print(f"  Subdirectories: {dirs}")
    print(f"  Files: {files}")
""")

# Practical examples
print("="*60)
print("=== Practical Examples ===\n")

# Get all Python files in current directory
print("🐍 Python files in current directory:")
python_files = [f for f in os.listdir('.') if f.endswith('.py')]
for f in python_files[:5]:
    print(f"  • {f}")

# Create a safe filename
print("\n📝 Creating safe filenames:")
unsafe_name = "My File: (2026) [version 1].txt"
safe_name = "".join(c if c.isalnum() or c in (' ', '.', '_', '-') else '_' for c in unsafe_name)
print(f"  Unsafe: {unsafe_name}")
print(f"  Safe: {safe_name}")

# Get file extension
print("\n📄 Getting file extensions:")
files = ['document.pdf', 'image.jpg', 'script.py', 'archive.tar.gz']
for f in files:
    name, ext = os.path.splitext(f)
    print(f"  {f} → Extension: '{ext}'")

# Build cross-platform paths
print("\n🛤️  Cross-platform paths:")
path = os.path.join('data', 'users', 'documents', 'report.pdf')
print(f"  Joined path: {path}")

# Check disk usage (if available)
try:
    import shutil
    print("\n💾 Disk Usage:")
    usage = shutil.disk_usage('.')
    print(f"  Total: {usage.total / (1024**3):.2f} GB")
    print(f"  Used: {usage.used / (1024**3):.2f} GB")
    print(f"  Free: {usage.free / (1024**3):.2f} GB")
except:
    print("\n💾 Disk usage info not available")
