"""
Math Library Basics
The math module provides mathematical functions and constants.
"""

import math

# Mathematical constants
print("=== Mathematical Constants ===")
print(f"Pi (π): {math.pi}")
print(f"Euler's number (e): {math.e}")
print(f"Tau (τ = 2π): {math.tau}")
print(f"Infinity: {math.inf}")
print(f"Not a Number: {math.nan}")

# Basic functions
print("\n=== Basic Mathematical Functions ===")
print(f"Absolute value of -5: {math.fabs(-5)}")
print(f"Ceiling of 4.3: {math.ceil(4.3)}")
print(f"Floor of 4.8: {math.floor(4.8)}")
print(f"Truncate 4.8: {math.trunc(4.8)}")

# Power and logarithms
print("\n=== Power and Logarithms ===")
print(f"2^3 = {math.pow(2, 3)}")
print(f"√16 = {math.sqrt(16)}")
print(f"∛27 = {27 ** (1/3)}")  # Cube root
print(f"e^2 = {math.exp(2)}")
print(f"log(100) base 10 = {math.log10(100)}")
print(f"ln(e) = {math.log(math.e)}")
print(f"log₂(8) = {math.log2(8)}")

# Trigonometric functions
print("\n=== Trigonometric Functions ===")
angle_degrees = 45
angle_radians = math.radians(angle_degrees)

print(f"Angle: {angle_degrees}° = {angle_radians:.4f} radians")
print(f"sin(45°) = {math.sin(angle_radians):.4f}")
print(f"cos(45°) = {math.cos(angle_radians):.4f}")
print(f"tan(45°) = {math.tan(angle_radians):.4f}")

# Convert back from radians
angle_back = math.degrees(angle_radians)
print(f"\n{angle_radians:.4f} radians = {angle_back}°")

# Inverse trigonometric functions
print("\n=== Inverse Trigonometric Functions ===")
value = 0.5
print(f"arcsin(0.5) = {math.degrees(math.asin(value)):.2f}°")
print(f"arccos(0.5) = {math.degrees(math.acos(value)):.2f}°")
print(f"arctan(1) = {math.degrees(math.atan(1)):.2f}°")

# Hyperbolic functions
print("\n=== Hyperbolic Functions ===")
x = 1
print(f"sinh({x}) = {math.sinh(x):.4f}")
print(f"cosh({x}) = {math.cosh(x):.4f}")
print(f"tanh({x}) = {math.tanh(x):.4f}")

# Special functions
print("\n=== Special Functions ===")
print(f"Factorial of 5: {math.factorial(5)}")
print(f"GCD of 48 and 18: {math.gcd(48, 18)}")
print(f"LCM of 12 and 18: {math.lcm(12, 18)}")

# Number theory functions
print("\n=== Number Theory ===")
print(f"5! = {math.factorial(5)}")
print(f"Permutations P(5,2) = {math.perm(5, 2)}")
print(f"Combinations C(5,2) = {math.comb(5, 2)}")

# Rounding and modulo
print("\n=== Rounding Functions ===")
x, y = 17, 5
print(f"{x} / {y} = {x/y}")
print(f"Quotient (floor division): {x // y}")
print(f"Remainder: {x % y}")
print(f"Using math.remainder: {math.remainder(x, y)}")

# Distance calculations
print("\n=== Distance Calculations ===")
# Distance from origin
print(f"Distance from (0,0) to (3,4): {math.hypot(3, 4)}")
print(f"Distance from (0,0) to (1,1,1): {math.hypot(1, 1, 1)}")

# Sum and product
print("\n=== Sum and Product ===")
numbers = [1, 2, 3, 4, 5]
print(f"Numbers: {numbers}")
print(f"Sum: {math.fsum(numbers)}")  # More accurate than sum()
print(f"Product: {math.prod(numbers)}")

# Checking values
print("\n=== Value Checks ===")
values = [5, math.inf, -math.inf, math.nan, 0]
for val in values:
    print(f"\nValue: {val}")
    print(f"  Is finite: {math.isfinite(val)}")
    print(f"  Is infinite: {math.isinf(val)}")
    print(f"  Is NaN: {math.isnan(val)}")

# Practical examples
print("\n" + "="*60)
print("=== Practical Examples ===\n")

# Calculate circle properties
radius = 5
area = math.pi * radius ** 2
circumference = 2 * math.pi * radius
print(f"Circle with radius {radius}:")
print(f"  Area = {area:.2f}")
print(f"  Circumference = {circumference:.2f}")

# Calculate distance between two points
x1, y1 = 1, 2
x2, y2 = 4, 6
distance = math.hypot(x2 - x1, y2 - y1)
print(f"\nDistance between ({x1},{y1}) and ({x2},{y2}): {distance:.2f}")

# Convert temperature
celsius = 25
fahrenheit = (celsius * 9/5) + 32
print(f"\n{celsius}°C = {fahrenheit}°F")

# Compound interest
principal = 1000
rate = 0.05  # 5%
time = 10
amount = principal * math.exp(rate * time)
print(f"\nCompound interest (continuous):")
print(f"  Principal: ${principal}")
print(f"  Rate: {rate*100}%")
print(f"  Time: {time} years")
print(f"  Final amount: ${amount:.2f}")
