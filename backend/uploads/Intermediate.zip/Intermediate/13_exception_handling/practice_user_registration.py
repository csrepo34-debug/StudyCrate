# Practice: User registration system with validation and exception handling

class RegistrationError(Exception):
    """Base exception for registration errors"""
    pass

class UsernameError(RegistrationError):
    """Exception for username validation errors"""
    pass

class PasswordError(RegistrationError):
    """Exception for password validation errors"""
    pass

class EmailError(RegistrationError):
    """Exception for email validation errors"""
    pass

class User:
    """User class with validation"""
    
    def __init__(self, username, password, email, age):
        self.username = self.validate_username(username)
        self.password = self.validate_password(password)
        self.email = self.validate_email(email)
        self.age = self.validate_age(age)
    
    def validate_username(self, username):
        """Validate username"""
        if not username:
            raise UsernameError("Username cannot be empty")
        if len(username) < 3:
            raise UsernameError("Username must be at least 3 characters")
        if len(username) > 20:
            raise UsernameError("Username cannot exceed 20 characters")
        if not username.replace('_', '').isalnum():
            raise UsernameError("Username can only contain letters, numbers, and underscores")
        return username
    
    def validate_password(self, password):
        """Validate password"""
        if not password:
            raise PasswordError("Password cannot be empty")
        if len(password) < 8:
            raise PasswordError("Password must be at least 8 characters")
        if not any(char.isdigit() for char in password):
            raise PasswordError("Password must contain at least one digit")
        if not any(char.isupper() for char in password):
            raise PasswordError("Password must contain at least one uppercase letter")
        if not any(char.islower() for char in password):
            raise PasswordError("Password must contain at least one lowercase letter")
        return password
    
    def validate_email(self, email):
        """Validate email"""
        if not email:
            raise EmailError("Email cannot be empty")
        if '@' not in email:
            raise EmailError("Email must contain @ symbol")
        if '.' not in email.split('@')[1]:
            raise EmailError("Email must have valid domain")
        if email.count('@') != 1:
            raise EmailError("Email can only contain one @ symbol")
        return email
    
    def validate_age(self, age):
        """Validate age"""
        try:
            age = int(age)
            if age < 13:
                raise RegistrationError("User must be at least 13 years old")
            if age > 120:
                raise RegistrationError("Invalid age")
            return age
        except ValueError:
            raise RegistrationError("Age must be a valid number")
    
    def __str__(self):
        return f"User: {self.username}, Email: {self.email}, Age: {self.age}"

class RegistrationSystem:
    """User registration system"""
    
    def __init__(self):
        self.users = {}
    
    def register_user(self, username, password, email, age):
        """Register a new user"""
        try:
            # Check if username already exists
            if username in self.users:
                raise UsernameError(f"Username '{username}' already exists")
            
            # Create user (will validate all fields)
            user = User(username, password, email, age)
            
            # Add to users dictionary
            self.users[username] = user
            
            print(f"Success! User '{username}' registered successfully")
            return True
            
        except RegistrationError as e:
            print(f"Registration failed: {e}")
            return False
        except Exception as e:
            print(f"Unexpected error during registration: {e}")
            return False
    
    def list_users(self):
        """List all registered users"""
        if self.users:
            print("\nRegistered Users:")
            for user in self.users.values():
                print(f"  - {user}")
        else:
            print("No users registered yet")

# Test the registration system
print("=== User Registration System ===\n")

system = RegistrationSystem()

# Test data: (username, password, email, age)
test_registrations = [
    ("alice123", "SecurePass1", "alice@email.com", "25"),      # Valid
    ("bob", "weak", "bob@email.com", "30"),                     # Weak password
    ("charlie_99", "StrongPass123", "invalid-email", "22"),    # Invalid email
    ("dave_smith", "MyPassword1", "dave@email.com", "10"),     # Age too young
    ("eve_miller", "GoodPass99", "eve@example.com", "35"),     # Valid
    ("alice123", "Another1Pass", "alice2@email.com", "28"),    # Duplicate username
    ("frank!", "Password1", "frank@email.com", "40"),          # Invalid username
    ("grace_lee", "Short1", "grace@email.com", "27"),          # Short password
    ("henry_wong", "ValidPass123", "henry@example.com", "abc"), # Invalid age
]

print("--- Registration Attempts ---\n")
for username, password, email, age in test_registrations:
    print(f"Attempting to register: {username}")
    system.register_user(username, password, email, age)
    print()

# List all successfully registered users
system.list_users()

print("\n--- Registration Statistics ---")
print(f"Total registered users: {len(system.users)}")
