# Basic Exception Handling - Try-Except

print("=== Basic Exception Handling ===\n")

# Example 1: Handling ZeroDivisionError
try:
    number = 10
    result = number / 0
    print(result)
except ZeroDivisionError:
    print("Error: Cannot divide by zero!")

# Example 2: Handling ValueError
try:
    age = int(input("\nEnter your age: "))
    print(f"You are {age} years old")
except ValueError:
    print("Error: Please enter a valid number")

# Example 3: Multiple except blocks
try:
    numbers = [1, 2, 3]
    index = int(input("\nEnter index (0-2): "))
    print(f"Value at index {index}: {numbers[index]}")
except ValueError:
    print("Error: Invalid input! Enter a number")
except IndexError:
    print("Error: Index out of range")

# Example 4: Generic exception handler
try:
    value = int(input("\nEnter a number: "))
    result = 100 / value
    print(f"100 / {value} = {result}")
except Exception as e:
    print(f"An error occurred: {e}")
    print(f"Error type: {type(e).__name__}")
