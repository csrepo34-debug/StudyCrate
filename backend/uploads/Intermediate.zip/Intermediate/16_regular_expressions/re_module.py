"""
Python re Module
The re module provides regular expression matching operations.
"""

import re

# re.search() - Search for first occurrence
print("=== re.search() ===")
text = "The rain in Spain"
match = re.search(r'rain', text)

if match:
    print(f"✓ Found: '{match.group()}' at position {match.start()}-{match.end()}")

# re.match() - Match at the beginning
print("\n=== re.match() ===")
text = "Hello World"
match = re.match(r'Hello', text)

if match:
    print(f"✓ Text starts with: '{match.group()}'")

match = re.match(r'World', text)
if not match:
    print("✗ 'World' not at the beginning")

# re.findall() - Find all occurrences
print("\n=== re.findall() ===")
text = "Contact us at: support@email.com or sales@email.com"
emails = re.findall(r'\w+@\w+\.\w+', text)
print(f"Emails found: {emails}")

# re.finditer() - Find all with match objects
print("\n=== re.finditer() ===")
text = "Price: $10, $20, $30"
matches = re.finditer(r'\$(\d+)', text)

for match in matches:
    print(f"Found ${match.group(1)} at position {match.start()}")

# re.sub() - Replace matches
print("\n=== re.sub() ===")
text = "I love cats. Cats are amazing. cats everywhere!"
new_text = re.sub(r'cats', 'dogs', text, flags=re.IGNORECASE)
print(f"Original: {text}")
print(f"Modified: {new_text}")

# Replace with a function
def double_number(match):
    num = int(match.group())
    return str(num * 2)

text = "I have 5 apples and 10 oranges"
new_text = re.sub(r'\d+', double_number, text)
print(f"\nOriginal: {text}")
print(f"Doubled: {new_text}")

# re.split() - Split string by pattern
print("\n=== re.split() ===")
text = "apple,banana;orange:grape"
fruits = re.split(r'[,;:]', text)
print(f"Fruits: {fruits}")

text = "one1two2three3four"
parts = re.split(r'\d+', text)
print(f"Parts: {parts}")

# re.compile() - Compile pattern for reuse
print("\n=== re.compile() ===")
pattern = re.compile(r'\d{3}-\d{4}')

text1 = "Call 555-1234"
text2 = "Phone: 555-5678"

if pattern.search(text1):
    print(f"✓ Pattern found in: {text1}")

if pattern.search(text2):
    print(f"✓ Pattern found in: {text2}")

# Groups and capturing
print("\n=== Groups and Capturing ===")
text = "John Doe, age: 30, email: john@email.com"
pattern = r'(\w+) (\w+), age: (\d+), email: (\S+)'

match = re.search(pattern, text)
if match:
    print(f"First Name: {match.group(1)}")
    print(f"Last Name: {match.group(2)}")
    print(f"Age: {match.group(3)}")
    print(f"Email: {match.group(4)}")
    print(f"Full match: {match.group(0)}")

# Named groups
print("\n=== Named Groups ===")
pattern = r'(?P<first>\w+) (?P<last>\w+), age: (?P<age>\d+)'
match = re.search(pattern, text)

if match:
    print(f"First Name: {match.group('first')}")
    print(f"Last Name: {match.group('last')}")
    print(f"Age: {match.group('age')}")
    print(f"All groups: {match.groupdict()}")

# Flags
print("\n=== Flags ===")

# re.IGNORECASE - Case-insensitive matching
text = "Python is AWESOME"
matches = re.findall(r'python', text, re.IGNORECASE)
print(f"Case-insensitive: {matches}")

# re.MULTILINE - ^ and $ match start/end of each line
text = """First line
Second line
Third line"""

matches = re.findall(r'^.*line$', text, re.MULTILINE)
print(f"Multiline matches: {matches}")

# re.DOTALL - . matches newline
text = "Hello\nWorld"
match = re.search(r'Hello.World', text, re.DOTALL)
if match:
    print(f"✓ Dotall matched across newline")

# Lookahead and lookbehind
print("\n=== Lookahead and Lookbehind ===")

# Positive lookahead (?=...)
text = "I have 100 dollars and 50 euros"
amounts = re.findall(r'\d+(?= dollars)', text)
print(f"Dollar amounts: {amounts}")

# Negative lookahead (?!...)
words = "apple orange grape banana"
fruits = re.findall(r'\b\w+(?!e\b)', words)
print(f"Words not ending with 'e': {fruits}")

# Positive lookbehind (?<=...)
text = "Price: $50, Cost: $30"
prices = re.findall(r'(?<=\$)\d+', text)
print(f"Prices: {prices}")
