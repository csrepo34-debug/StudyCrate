"""
Practice: Email Validator
Validate email addresses using regular expressions.
"""

import re

def validate_email(email):
    """
    Validate email address format
    
    Rules:
    - Must have @ symbol
    - Local part (before @) can contain letters, numbers, dots, hyphens, underscores
    - Domain part (after @) must have at least one dot
    - Domain must end with 2-6 letter extension
    """
    pattern = r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$'
    
    if re.match(pattern, email):
        return True
    return False

def validate_email_detailed(email):
    """
    Detailed email validation with specific error messages
    """
    # Check for @ symbol
    if '@' not in email:
        return False, "Missing @ symbol"
    
    # Split into local and domain parts
    parts = email.split('@')
    
    if len(parts) != 2:
        return False, "Multiple @ symbols found"
    
    local, domain = parts
    
    # Validate local part
    if not local:
        return False, "Empty local part (before @)"
    
    if not re.match(r'^[a-zA-Z0-9._-]+$', local):
        return False, "Invalid characters in local part"
    
    if local[0] == '.' or local[-1] == '.':
        return False, "Local part cannot start or end with a dot"
    
    if '..' in local:
        return False, "Local part cannot have consecutive dots"
    
    # Validate domain part
    if not domain:
        return False, "Empty domain part (after @)"
    
    if '.' not in domain:
        return False, "Domain must contain at least one dot"
    
    if not re.match(r'^[a-zA-Z0-9.-]+$', domain):
        return False, "Invalid characters in domain"
    
    # Validate domain extension
    domain_parts = domain.split('.')
    extension = domain_parts[-1]
    
    if not re.match(r'^[a-zA-Z]{2,6}$', extension):
        return False, "Invalid domain extension (must be 2-6 letters)"
    
    return True, "Valid email address"

def extract_emails_from_text(text):
    """Extract all email addresses from a text"""
    pattern = r'\b[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}\b'
    return re.findall(pattern, text)

def get_email_parts(email):
    """Extract parts from a valid email"""
    if not validate_email(email):
        return None
    
    match = re.match(r'^([a-zA-Z0-9._-]+)@([a-zA-Z0-9.-]+)\.([a-zA-Z]{2,6})$', email)
    
    if match:
        return {
            'username': match.group(1),
            'domain': match.group(2),
            'extension': match.group(3),
            'full_domain': f"{match.group(2)}.{match.group(3)}"
        }
    return None

# Test the validators
print("=== Email Validation Tests ===\n")

test_emails = [
    "user@example.com",          # Valid
    "john.doe@company.co.uk",    # Valid
    "test_123@domain.org",       # Valid
    "invalid.email",             # Invalid - no @
    "@example.com",              # Invalid - no local part
    "user@",                     # Invalid - no domain
    "user@@example.com",         # Invalid - multiple @
    "user@domain",               # Invalid - no extension
    ".user@example.com",         # Invalid - starts with dot
    "user..name@example.com",    # Invalid - consecutive dots
    "user@domain.c",             # Invalid - extension too short
    "user@domain.toolongext",    # Invalid - extension too long
]

for email in test_emails:
    is_valid = validate_email(email)
    status = "✓ Valid" if is_valid else "✗ Invalid"
    print(f"{status}: {email}")

# Detailed validation
print("\n" + "="*60)
print("=== Detailed Email Validation ===\n")

detailed_test = [
    "good@example.com",
    "bad@@example.com",
    ".start@example.com",
]

for email in detailed_test:
    is_valid, message = validate_email_detailed(email)
    status = "✓" if is_valid else "✗"
    print(f"{status} {email}")
    print(f"  → {message}\n")

# Extract emails from text
print("="*60)
print("=== Extract Emails from Text ===\n")

text = """
Please contact us at:
- Support: support@company.com
- Sales: sales@company.com
- Info: info@company.co.uk
You can also reach John at john.doe@example.org
or Jane at jane_smith@domain.net
Invalid emails like test@invalid or @example.com will be ignored.
"""

found_emails = extract_emails_from_text(text)
print(f"Found {len(found_emails)} valid emails:")
for email in found_emails:
    print(f"  • {email}")

# Get email parts
print("\n" + "="*60)
print("=== Email Parts Extraction ===\n")

sample_email = "john.doe@example.com"
parts = get_email_parts(sample_email)

if parts:
    print(f"Email: {sample_email}")
    print(f"  Username: {parts['username']}")
    print(f"  Domain: {parts['full_domain']}")
    print(f"  Extension: {parts['extension']}")

# Interactive validator
print("\n" + "="*60)
print("=== Interactive Email Validator ===\n")

def interactive_validator():
    while True:
        email = input("Enter email to validate (or 'quit' to exit): ").strip()
        
        if email.lower() == 'quit':
            print("Goodbye! 👋")
            break
        
        if not email:
            print("❌ Please enter an email address\n")
            continue
        
        is_valid, message = validate_email_detailed(email)
        
        if is_valid:
            print(f"✓ {message}")
            parts = get_email_parts(email)
            if parts:
                print(f"  Username: {parts['username']}")
                print(f"  Domain: {parts['full_domain']}")
        else:
            print(f"✗ {message}")
        
        print()

# Uncomment to run interactive mode
# interactive_validator()
