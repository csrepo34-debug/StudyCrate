# Using the Custom Module

# Import the custom module
import math_operations

# Use module functions
result1 = math_operations.add(10, 5)
print(f"Addition: {result1}")

result2 = math_operations.multiply(4, 7)
print(f"Multiplication: {result2}")

# Use module constants
print(f"PI value: {math_operations.PI}")

# Calculate circle properties
radius = 5
area = math_operations.circle_area(radius)
circumference = math_operations.circle_circumference(radius)
print(f"\nCircle with radius {radius}:")
print(f"Area: {area:.2f}")
print(f"Circumference: {circumference:.2f}")

# Use the class from module
calculator = math_operations.Calculator()
calculator.add(10)
calculator.add(20)
calculator.add(5)
print(f"\nCalculator total: {calculator.result}")

# Alternative import method
from math_operations import add, subtract, PI

result3 = add(100, 50)
result4 = subtract(100, 50)
print(f"\nUsing imported functions:")
print(f"100 + 50 = {result3}")
print(f"100 - 50 = {result4}")
print(f"PI constant: {PI}")

# Check module attributes
print(f"\nModule name: {math_operations.__name__}")
print(f"Module documentation: {math_operations.__doc__}")
