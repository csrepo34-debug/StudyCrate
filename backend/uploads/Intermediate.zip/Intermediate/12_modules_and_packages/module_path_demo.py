# Understanding Module Search Path and sys.path

import sys
import os

# Display Python version
print("Python Version:", sys.version)
print("\n" + "="*50)

# Display module search path
print("\nModule Search Path (sys.path):")
for i, path in enumerate(sys.path, 1):
    print(f"{i}. {path}")

print("\n" + "="*50)

# Current working directory
print("\nCurrent Working Directory:")
print(os.getcwd())

# Add custom path to sys.path (if needed)
custom_path = r"D:\My folder\Personal Finance\Programming Languages\Python Language\Intermediate\12_modules_and_packages"
if custom_path not in sys.path:
    sys.path.append(custom_path)
    print(f"\nAdded custom path: {custom_path}")

# Check if module can be found
module_name = "math_operations"
try:
    import importlib
    importlib.import_module(module_name)
    print(f"\nModule '{module_name}' found and imported successfully!")
except ImportError as e:
    print(f"\nError importing module '{module_name}': {e}")

# Display information about imported modules
print("\n" + "="*50)
print("\nCurrently imported modules:")
module_list = [mod for mod in sys.modules.keys() if not mod.startswith('_')]
print(f"Total modules imported: {len(module_list)}")
print("Sample modules:", module_list[:10])

# Module attributes
print("\n" + "="*50)
print("\nCurrent script information:")
print(f"Script name: {__name__}")
print(f"File location: {__file__ if '__file__' in dir() else 'Not available'}")
