# Importing Modules - Different Ways

# Method 1: Import entire module
import math
print("Pi value:", math.pi)
print("Square root of 16:", math.sqrt(16))

# Method 2: Import specific functions
from math import sqrt, pow
print("Square root of 25:", sqrt(25))
print("2 to the power 3:", pow(2, 3))

# Method 3: Import with alias
import datetime as dt
now = dt.datetime.now()
print("Current time:", now)

# Method 4: Import all (not recommended)
from random import *
print("Random number:", randint(1, 10))

# Method 5: Import from submodules
from os.path import exists, join
print("Path exists:", exists("test.txt"))
print("Joined path:", join("folder", "file.txt"))

# Multiple imports
import sys, os, json

# Import and use different modules
from collections import Counter
from statistics import mean

data = [1, 2, 2, 3, 3, 3, 4]
print("\nCounter:", Counter(data))
print("Mean:", mean(data))
