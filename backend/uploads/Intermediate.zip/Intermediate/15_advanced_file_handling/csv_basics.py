"""
CSV (Comma Separated Values) Basics
CSV files are commonly used for storing tabular data.
Python's csv module makes it easy to read and write CSV files.
"""

import csv

# Writing to a CSV file
print("=== Writing to CSV ===")
data = [
    ['Name', 'Age', 'City'],
    ['Alice', '25', 'New York'],
    ['Bob', '30', 'Los Angeles'],
    ['Charlie', '35', 'Chicago']
]

# Create a CSV file
with open('sample.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)
    print("Data written to sample.csv")

# Reading from a CSV file
print("\n=== Reading from CSV ===")
with open('sample.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)

# Reading CSV as a dictionary
print("\n=== Reading CSV as Dictionary ===")
with open('sample.csv', 'r') as file:
    dict_reader = csv.DictReader(file)
    for row in dict_reader:
        print(row)

# Writing CSV using DictWriter
print("\n=== Writing CSV using DictWriter ===")
data_dict = [
    {'Name': 'David', 'Age': '28', 'City': 'Miami'},
    {'Name': 'Emma', 'Age': '32', 'City': 'Seattle'}
]

with open('people.csv', 'w', newline='') as file:
    fieldnames = ['Name', 'Age', 'City']
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    
    writer.writeheader()  # Write column headers
    writer.writerows(data_dict)
    print("Dictionary data written to people.csv")

# Reading with different delimiter
print("\n=== Custom Delimiter (tab-separated) ===")
with open('custom.tsv', 'w', newline='') as file:
    writer = csv.writer(file, delimiter='\t')
    writer.writerow(['Product', 'Price', 'Quantity'])
    writer.writerow(['Laptop', '999.99', '5'])
    writer.writerow(['Mouse', '29.99', '20'])
    print("TSV file created")

with open('custom.tsv', 'r') as file:
    reader = csv.reader(file, delimiter='\t')
    for row in reader:
        print(row)
