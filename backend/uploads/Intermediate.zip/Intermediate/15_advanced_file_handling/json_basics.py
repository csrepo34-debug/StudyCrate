"""
JSON (JavaScript Object Notation) Basics
JSON is a lightweight data format for storing and exchanging data.
Python's json module makes it easy to work with JSON data.
"""

import json

# Python dictionary to JSON string
print("=== Python to JSON ===")
person = {
    "name": "John Doe",
    "age": 30,
    "city": "New York",
    "is_student": False,
    "hobbies": ["reading", "gaming", "coding"]
}

json_string = json.dumps(person)
print(json_string)
print(type(json_string))

# Pretty printing JSON
print("\n=== Pretty Printing JSON ===")
json_pretty = json.dumps(person, indent=4)
print(json_pretty)

# Writing JSON to a file
print("\n=== Writing to JSON File ===")
with open('person.json', 'w') as file:
    json.dump(person, file, indent=4)
    print("Data written to person.json")

# Reading JSON from a file
print("\n=== Reading from JSON File ===")
with open('person.json', 'r') as file:
    data = json.load(file)
    print(data)
    print(f"Name: {data['name']}")
    print(f"Age: {data['age']}")

# JSON string to Python object
print("\n=== JSON String to Python ===")
json_text = '{"product": "Laptop", "price": 999.99, "in_stock": true}'
product = json.loads(json_text)
print(product)
print(type(product))

# Complex nested structure
print("\n=== Complex JSON Structure ===")
company = {
    "name": "Tech Corp",
    "employees": [
        {
            "id": 1,
            "name": "Alice",
            "position": "Developer",
            "skills": ["Python", "JavaScript"]
        },
        {
            "id": 2,
            "name": "Bob",
            "position": "Designer",
            "skills": ["Photoshop", "Illustrator"]
        }
    ],
    "location": {
        "city": "San Francisco",
        "country": "USA"
    }
}

with open('company.json', 'w') as file:
    json.dump(company, file, indent=2)
    print("Complex data written to company.json")

# Reading and accessing nested data
with open('company.json', 'r') as file:
    company_data = json.load(file)
    print(f"\nCompany: {company_data['name']}")
    print(f"First employee: {company_data['employees'][0]['name']}")
    print(f"Location: {company_data['location']['city']}")
