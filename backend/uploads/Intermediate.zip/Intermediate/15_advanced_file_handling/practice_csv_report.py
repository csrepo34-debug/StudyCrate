"""
Practice: CSV Report Generator
Generate sales reports from CSV data.
"""

import csv
from datetime import datetime

def create_sample_data():
    """Create sample sales data"""
    sales_data = [
        ['Date', 'Product', 'Quantity', 'Price', 'Total'],
        ['2026-01-01', 'Laptop', '2', '999.99', '1999.98'],
        ['2026-01-02', 'Mouse', '5', '29.99', '149.95'],
        ['2026-01-02', 'Keyboard', '3', '79.99', '239.97'],
        ['2026-01-03', 'Monitor', '1', '299.99', '299.99'],
        ['2026-01-03', 'Laptop', '1', '999.99', '999.99'],
        ['2026-01-04', 'Mouse', '10', '29.99', '299.90'],
        ['2026-01-05', 'Headphones', '4', '149.99', '599.96'],
        ['2026-01-05', 'Webcam', '2', '89.99', '179.98']
    ]
    
    with open('sales_data.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(sales_data)
    
    print("✓ Sample sales data created in sales_data.csv")

def read_sales_data():
    """Read sales data from CSV"""
    sales = []
    try:
        with open('sales_data.csv', 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                sales.append(row)
        return sales
    except FileNotFoundError:
        print("❌ sales_data.csv not found! Creating sample data...")
        create_sample_data()
        return read_sales_data()

def generate_total_sales_report():
    """Generate total sales report"""
    sales = read_sales_data()
    
    total_revenue = sum(float(sale['Total']) for sale in sales)
    total_items = sum(int(sale['Quantity']) for sale in sales)
    
    print("\n" + "="*50)
    print("TOTAL SALES REPORT")
    print("="*50)
    print(f"Total Revenue: ${total_revenue:.2f}")
    print(f"Total Items Sold: {total_items}")
    print(f"Number of Transactions: {len(sales)}")
    print(f"Average Transaction Value: ${total_revenue/len(sales):.2f}")
    print("="*50)

def generate_product_report():
    """Generate product-wise sales report"""
    sales = read_sales_data()
    
    product_data = {}
    
    for sale in sales:
        product = sale['Product']
        quantity = int(sale['Quantity'])
        total = float(sale['Total'])
        
        if product in product_data:
            product_data[product]['quantity'] += quantity
            product_data[product]['revenue'] += total
        else:
            product_data[product] = {
                'quantity': quantity,
                'revenue': total
            }
    
    print("\n" + "="*60)
    print("PRODUCT-WISE SALES REPORT")
    print("="*60)
    print(f"{'Product':<15} {'Quantity':<12} {'Revenue':<15}")
    print("-"*60)
    
    for product, data in sorted(product_data.items(), key=lambda x: x[1]['revenue'], reverse=True):
        print(f"{product:<15} {data['quantity']:<12} ${data['revenue']:<14.2f}")
    
    print("="*60)

def generate_daily_report():
    """Generate day-wise sales report"""
    sales = read_sales_data()
    
    daily_data = {}
    
    for sale in sales:
        date = sale['Date']
        total = float(sale['Total'])
        
        if date in daily_data:
            daily_data[date] += total
        else:
            daily_data[date] = total
    
    print("\n" + "="*50)
    print("DAILY SALES REPORT")
    print("="*50)
    print(f"{'Date':<15} {'Revenue':<15}")
    print("-"*50)
    
    for date in sorted(daily_data.keys()):
        print(f"{date:<15} ${daily_data[date]:<14.2f}")
    
    print("="*50)

def export_summary_report():
    """Export summary report to CSV"""
    sales = read_sales_data()
    
    product_summary = {}
    
    for sale in sales:
        product = sale['Product']
        quantity = int(sale['Quantity'])
        revenue = float(sale['Total'])
        
        if product in product_summary:
            product_summary[product]['quantity'] += quantity
            product_summary[product]['revenue'] += revenue
            product_summary[product]['transactions'] += 1
        else:
            product_summary[product] = {
                'quantity': quantity,
                'revenue': revenue,
                'transactions': 1
            }
    
    # Write summary report
    with open('sales_summary.csv', 'w', newline='') as file:
        fieldnames = ['Product', 'Total_Quantity', 'Total_Revenue', 'Transactions', 'Avg_Transaction']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        
        writer.writeheader()
        
        for product, data in product_summary.items():
            writer.writerow({
                'Product': product,
                'Total_Quantity': data['quantity'],
                'Total_Revenue': f"{data['revenue']:.2f}",
                'Transactions': data['transactions'],
                'Avg_Transaction': f"{data['revenue']/data['transactions']:.2f}"
            })
    
    print("\n✓ Summary report exported to sales_summary.csv")

def add_new_sale():
    """Add a new sale entry"""
    print("\n=== Add New Sale ===")
    date = input("Enter date (YYYY-MM-DD) or press Enter for today: ")
    if not date:
        date = datetime.now().strftime('%Y-%m-%d')
    
    product = input("Enter product name: ")
    quantity = int(input("Enter quantity: "))
    price = float(input("Enter price per unit: "))
    total = quantity * price
    
    with open('sales_data.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([date, product, quantity, price, total])
    
    print(f"✓ Sale added: {quantity}x {product} = ${total:.2f}")

def main():
    """Main menu"""
    while True:
        print("\n" + "="*50)
        print("CSV SALES REPORT GENERATOR")
        print("="*50)
        print("1. Generate Total Sales Report")
        print("2. Generate Product-Wise Report")
        print("3. Generate Daily Sales Report")
        print("4. Export Summary Report")
        print("5. Add New Sale")
        print("6. Create Sample Data")
        print("7. Exit")
        print("="*50)
        
        choice = input("Enter your choice (1-7): ")
        
        if choice == '1':
            generate_total_sales_report()
        elif choice == '2':
            generate_product_report()
        elif choice == '3':
            generate_daily_report()
        elif choice == '4':
            export_summary_report()
        elif choice == '5':
            add_new_sale()
        elif choice == '6':
            create_sample_data()
        elif choice == '7':
            print("\nGoodbye! 👋")
            break
        else:
            print("\n❌ Invalid choice! Please try again.")

if __name__ == "__main__":
    main()
