"""
Pickle Basics
Pickle is used to serialize and deserialize Python objects.
It can save any Python object to a file and load it back.
"""

import pickle

# Pickling basic data types
print("=== Pickling Basic Data ===")
data = {
    'name': 'Alice',
    'age': 25,
    'scores': [85, 90, 78],
    'is_active': True
}

# Save to file
with open('data.pickle', 'wb') as file:
    pickle.dump(data, file)
    print("Data pickled to data.pickle")

# Load from file
with open('data.pickle', 'rb') as file:
    loaded_data = pickle.load(file)
    print("Loaded data:", loaded_data)

# Pickling custom objects
print("\n=== Pickling Custom Objects ===")
class Student:
    def __init__(self, name, roll_no, marks):
        self.name = name
        self.roll_no = roll_no
        self.marks = marks
    
    def display(self):
        return f"Student: {self.name}, Roll: {self.roll_no}, Marks: {self.marks}"

student1 = Student("John", 101, 85)
student2 = Student("Emma", 102, 92)

# Pickle multiple objects
students = [student1, student2]

with open('students.pickle', 'wb') as file:
    pickle.dump(students, file)
    print("Students pickled")

# Unpickle and use objects
with open('students.pickle', 'rb') as file:
    loaded_students = pickle.load(file)
    for student in loaded_students:
        print(student.display())

# Pickling complex structures
print("\n=== Pickling Complex Structures ===")
complex_data = {
    'users': [
        {'id': 1, 'name': 'Alice', 'friends': [2, 3]},
        {'id': 2, 'name': 'Bob', 'friends': [1]},
        {'id': 3, 'name': 'Charlie', 'friends': [1]}
    ],
    'settings': {
        'theme': 'dark',
        'notifications': True
    }
}

with open('complex.pickle', 'wb') as file:
    pickle.dump(complex_data, file)

with open('complex.pickle', 'rb') as file:
    loaded_complex = pickle.load(file)
    print("Complex data loaded successfully")
    print(f"First user: {loaded_complex['users'][0]['name']}")
    print(f"Theme: {loaded_complex['settings']['theme']}")

# Multiple dumps in one file
print("\n=== Multiple Objects in One File ===")
with open('multi.pickle', 'wb') as file:
    pickle.dump([1, 2, 3], file)
    pickle.dump({'key': 'value'}, file)
    pickle.dump("Hello, World!", file)
    print("Multiple objects pickled")

with open('multi.pickle', 'rb') as file:
    obj1 = pickle.load(file)
    obj2 = pickle.load(file)
    obj3 = pickle.load(file)
    print(f"Object 1: {obj1}")
    print(f"Object 2: {obj2}")
    print(f"Object 3: {obj3}")

print("\n⚠️ Warning: Only unpickle files from trusted sources!")
print("Pickle files can contain malicious code.")
