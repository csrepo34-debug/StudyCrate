"""
Practice: User Data Management with JSON
Create a simple user database using JSON files.
"""

import json
import os

# File to store user data
USER_FILE = 'users_database.json'

def load_users():
    """Load users from JSON file"""
    if os.path.exists(USER_FILE):
        with open(USER_FILE, 'r') as file:
            return json.load(file)
    return []

def save_users(users):
    """Save users to JSON file"""
    with open(USER_FILE, 'w') as file:
        json.dump(users, file, indent=4)

def add_user():
    """Add a new user"""
    users = load_users()
    
    print("\n=== Add New User ===")
    name = input("Enter name: ")
    email = input("Enter email: ")
    age = input("Enter age: ")
    city = input("Enter city: ")
    
    user = {
        'id': len(users) + 1,
        'name': name,
        'email': email,
        'age': int(age),
        'city': city
    }
    
    users.append(user)
    save_users(users)
    print(f"✓ User '{name}' added successfully!")

def view_all_users():
    """Display all users"""
    users = load_users()
    
    if not users:
        print("\nNo users found!")
        return
    
    print("\n=== All Users ===")
    for user in users:
        print(f"ID: {user['id']}, Name: {user['name']}, Email: {user['email']}, Age: {user['age']}, City: {user['city']}")

def search_user():
    """Search user by name"""
    users = load_users()
    
    search_name = input("\nEnter name to search: ").lower()
    found = False
    
    for user in users:
        if search_name in user['name'].lower():
            print(f"\n✓ Found: {user}")
            found = True
    
    if not found:
        print("No user found with that name.")

def delete_user():
    """Delete a user by ID"""
    users = load_users()
    
    view_all_users()
    user_id = int(input("\nEnter user ID to delete: "))
    
    users = [user for user in users if user['id'] != user_id]
    
    # Reassign IDs
    for i, user in enumerate(users, 1):
        user['id'] = i
    
    save_users(users)
    print("✓ User deleted successfully!")

def update_user():
    """Update user information"""
    users = load_users()
    
    view_all_users()
    user_id = int(input("\nEnter user ID to update: "))
    
    for user in users:
        if user['id'] == user_id:
            print(f"\nCurrent data: {user}")
            user['name'] = input(f"Enter new name (current: {user['name']}): ") or user['name']
            user['email'] = input(f"Enter new email (current: {user['email']}): ") or user['email']
            age_input = input(f"Enter new age (current: {user['age']}): ")
            user['age'] = int(age_input) if age_input else user['age']
            user['city'] = input(f"Enter new city (current: {user['city']}): ") or user['city']
            
            save_users(users)
            print("✓ User updated successfully!")
            return
    
    print("User not found!")

def main():
    """Main menu"""
    while True:
        print("\n" + "="*40)
        print("USER DATA MANAGEMENT SYSTEM")
        print("="*40)
        print("1. Add User")
        print("2. View All Users")
        print("3. Search User")
        print("4. Update User")
        print("5. Delete User")
        print("6. Exit")
        print("="*40)
        
        choice = input("Enter your choice (1-6): ")
        
        if choice == '1':
            add_user()
        elif choice == '2':
            view_all_users()
        elif choice == '3':
            search_user()
        elif choice == '4':
            update_user()
        elif choice == '5':
            delete_user()
        elif choice == '6':
            print("\nGoodbye! 👋")
            break
        else:
            print("\n❌ Invalid choice! Please try again.")

if __name__ == "__main__":
    main()
