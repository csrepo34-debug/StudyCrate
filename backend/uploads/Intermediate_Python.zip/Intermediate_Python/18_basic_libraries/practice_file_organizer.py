"""
Practice: File Organizer
Organize files in a directory by type, date, or size using os module.
"""

import os
import shutil
from datetime import datetime

def get_file_info(filepath):
    """Get detailed file information"""
    stats = os.stat(filepath)
    return {
        'name': os.path.basename(filepath),
        'path': filepath,
        'size': stats.st_size,
        'modified': datetime.fromtimestamp(stats.st_mtime),
        'created': datetime.fromtimestamp(stats.st_ctime),
        'extension': os.path.splitext(filepath)[1].lower()
    }

def organize_by_type(source_dir, target_dir='organized'):
    """Organize files by their extension/type"""
    
    # Create target directory if it doesn't exist
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
        print(f"✓ Created directory: {target_dir}")
    
    # File type categories
    categories = {
        'Images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.ico'],
        'Documents': ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt'],
        'Spreadsheets': ['.xls', '.xlsx', '.csv'],
        'Videos': ['.mp4', '.avi', '.mov', '.mkv', '.flv'],
        'Audio': ['.mp3', '.wav', '.flac', '.aac', '.ogg'],
        'Archives': ['.zip', '.rar', '.7z', '.tar', '.gz'],
        'Code': ['.py', '.js', '.html', '.css', '.java', '.cpp', '.c'],
        'Executables': ['.exe', '.msi', '.app', '.deb'],
    }
    
    files_moved = {}
    
    # Scan directory
    for filename in os.listdir(source_dir):
        filepath = os.path.join(source_dir, filename)
        
        # Skip directories
        if os.path.isdir(filepath):
            continue
        
        # Get file extension
        _, ext = os.path.splitext(filename)
        ext = ext.lower()
        
        # Find category
        category = 'Others'
        for cat, extensions in categories.items():
            if ext in extensions:
                category = cat
                break
        
        # Create category folder
        category_path = os.path.join(target_dir, category)
        if not os.path.exists(category_path):
            os.makedirs(category_path)
        
        # Move file (simulate - copy instead of move for safety)
        target_path = os.path.join(category_path, filename)
        
        # Handle duplicate names
        counter = 1
        base_name, extension = os.path.splitext(filename)
        while os.path.exists(target_path):
            new_name = f"{base_name}_{counter}{extension}"
            target_path = os.path.join(category_path, new_name)
            counter += 1
        
        # Copy file (use shutil.move to actually move)
        print(f"Moving: {filename} → {category}/")
        # shutil.copy2(filepath, target_path)  # Uncomment to actually copy
        
        # Track moved files
        if category not in files_moved:
            files_moved[category] = []
        files_moved[category].append(filename)
    
    # Summary
    print("\n" + "="*60)
    print("ORGANIZATION SUMMARY")
    print("="*60)
    for category, files in sorted(files_moved.items()):
        print(f"{category}: {len(files)} file(s)")
        for f in files[:3]:
            print(f"  • {f}")
        if len(files) > 3:
            print(f"  ... and {len(files) - 3} more")

def organize_by_date(source_dir, target_dir='organized_by_date'):
    """Organize files by modification date (Year/Month)"""
    
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    
    files_organized = {}
    
    for filename in os.listdir(source_dir):
        filepath = os.path.join(source_dir, filename)
        
        if os.path.isdir(filepath):
            continue
        
        # Get file modification date
        info = get_file_info(filepath)
        date = info['modified']
        
        # Create year/month folder structure
        year_folder = str(date.year)
        month_folder = date.strftime('%m_%B')
        
        folder_path = os.path.join(target_dir, year_folder, month_folder)
        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        
        date_key = f"{year_folder}/{month_folder}"
        if date_key not in files_organized:
            files_organized[date_key] = []
        files_organized[date_key].append(filename)
        
        print(f"Organizing: {filename} → {date_key}/")
    
    # Summary
    print("\n" + "="*60)
    print("DATE ORGANIZATION SUMMARY")
    print("="*60)
    for date_path, files in sorted(files_organized.items()):
        print(f"{date_path}: {len(files)} file(s)")

def organize_by_size(source_dir, target_dir='organized_by_size'):
    """Organize files by size categories"""
    
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    
    # Size categories (in bytes)
    size_categories = {
        'Tiny (< 1 KB)': (0, 1024),
        'Small (1 KB - 1 MB)': (1024, 1024**2),
        'Medium (1 MB - 10 MB)': (1024**2, 10 * 1024**2),
        'Large (10 MB - 100 MB)': (10 * 1024**2, 100 * 1024**2),
        'Huge (> 100 MB)': (100 * 1024**2, float('inf'))
    }
    
    files_by_size = {}
    
    for filename in os.listdir(source_dir):
        filepath = os.path.join(source_dir, filename)
        
        if os.path.isdir(filepath):
            continue
        
        # Get file size
        size = os.path.getsize(filepath)
        
        # Find category
        for category, (min_size, max_size) in size_categories.items():
            if min_size <= size < max_size:
                if category not in files_by_size:
                    files_by_size[category] = []
                files_by_size[category].append((filename, size))
                
                category_path = os.path.join(target_dir, category)
                if not os.path.exists(category_path):
                    os.makedirs(category_path)
                
                print(f"Categorizing: {filename} ({size} bytes) → {category}")
                break
    
    # Summary
    print("\n" + "="*60)
    print("SIZE ORGANIZATION SUMMARY")
    print("="*60)
    for category, files in sorted(files_by_size.items()):
        total_size = sum(f[1] for f in files)
        print(f"\n{category}: {len(files)} file(s), Total: {format_size(total_size)}")
        for filename, size in files[:3]:
            print(f"  • {filename} ({format_size(size)})")
        if len(files) > 3:
            print(f"  ... and {len(files) - 3} more")

def format_size(bytes):
    """Format bytes to human-readable size"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024.0:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.2f} PB"

def find_duplicates(directory):
    """Find duplicate files by size"""
    
    size_map = {}
    
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        
        if os.path.isdir(filepath):
            continue
        
        size = os.path.getsize(filepath)
        
        if size not in size_map:
            size_map[size] = []
        size_map[size].append(filename)
    
    # Find duplicates
    duplicates = {size: files for size, files in size_map.items() if len(files) > 1}
    
    if duplicates:
        print("\n" + "="*60)
        print("POTENTIAL DUPLICATES (by size)")
        print("="*60)
        for size, files in duplicates.items():
            print(f"\nSize: {format_size(size)}")
            for f in files:
                print(f"  • {f}")
    else:
        print("\n✓ No duplicates found")

def clean_empty_folders(directory):
    """Remove empty folders"""
    
    removed = []
    
    for root, dirs, files in os.walk(directory, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            
            if not os.listdir(dir_path):
                print(f"Removing empty folder: {dir_path}")
                # os.rmdir(dir_path)  # Uncomment to actually remove
                removed.append(dir_path)
    
    print(f"\n✓ Found {len(removed)} empty folder(s)")

def show_directory_stats(directory):
    """Show statistics about a directory"""
    
    total_files = 0
    total_size = 0
    extensions = {}
    
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        
        if os.path.isdir(filepath):
            continue
        
        total_files += 1
        size = os.path.getsize(filepath)
        total_size += size
        
        ext = os.path.splitext(filename)[1].lower() or 'no extension'
        extensions[ext] = extensions.get(ext, 0) + 1
    
    print("\n" + "="*60)
    print(f"DIRECTORY STATISTICS: {directory}")
    print("="*60)
    print(f"Total files: {total_files}")
    print(f"Total size: {format_size(total_size)}")
    print(f"\nFile types:")
    for ext, count in sorted(extensions.items(), key=lambda x: x[1], reverse=True):
        print(f"  {ext}: {count} file(s)")

# Main menu
def main():
    """Main menu for file organizer"""
    
    while True:
        print("\n" + "="*60)
        print("📁 FILE ORGANIZER")
        print("="*60)
        print("1. Organize by File Type")
        print("2. Organize by Date")
        print("3. Organize by Size")
        print("4. Find Duplicates")
        print("5. Clean Empty Folders")
        print("6. Show Directory Stats")
        print("7. Exit")
        print("="*60)
        
        choice = input("Enter your choice (1-7): ")
        
        try:
            if choice in ['1', '2', '3', '4', '5', '6']:
                source_dir = input("Enter source directory path (or '.' for current): ").strip()
                
                if not source_dir:
                    source_dir = '.'
                
                if not os.path.exists(source_dir):
                    print(f"❌ Directory not found: {source_dir}")
                    continue
            
            if choice == '1':
                organize_by_type(source_dir)
            elif choice == '2':
                organize_by_date(source_dir)
            elif choice == '3':
                organize_by_size(source_dir)
            elif choice == '4':
                find_duplicates(source_dir)
            elif choice == '5':
                clean_empty_folders(source_dir)
            elif choice == '6':
                show_directory_stats(source_dir)
            elif choice == '7':
                print("\nGoodbye! 👋")
                break
            else:
                print("\n❌ Invalid choice! Please try again.")
        
        except Exception as e:
            print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    print("="*60)
    print("FILE ORGANIZER - Practice Program")
    print("="*60)
    print("\n⚠️  NOTE: This is a demonstration program.")
    print("Actual file operations are commented out for safety.")
    print("Uncomment shutil.copy2() or shutil.move() to enable moving files.")
    print("\n")
    
    main()
