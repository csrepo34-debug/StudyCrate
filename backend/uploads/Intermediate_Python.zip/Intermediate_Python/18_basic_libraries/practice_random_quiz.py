"""
Practice: Random Quiz App
Create an interactive quiz application with random questions.
"""

import random
import json
import os

QUIZ_FILE = 'quiz_questions.json'

# Sample quiz questions
SAMPLE_QUESTIONS = [
    {
        'question': 'What is the capital of France?',
        'options': ['London', 'Berlin', 'Paris', 'Madrid'],
        'correct': 2,
        'category': 'Geography'
    },
    {
        'question': 'What is 2 + 2?',
        'options': ['3', '4', '5', '6'],
        'correct': 1,
        'category': 'Math'
    },
    {
        'question': 'Who wrote "Romeo and Juliet"?',
        'options': ['Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain'],
        'correct': 1,
        'category': 'Literature'
    },
    {
        'question': 'What is the largest planet in our solar system?',
        'options': ['Earth', 'Mars', 'Jupiter', 'Saturn'],
        'correct': 2,
        'category': 'Science'
    },
    {
        'question': 'In which year did World War II end?',
        'options': ['1943', '1944', '1945', '1946'],
        'correct': 2,
        'category': 'History'
    },
    {
        'question': 'What is the chemical symbol for gold?',
        'options': ['Go', 'Gd', 'Au', 'Ag'],
        'correct': 2,
        'category': 'Science'
    },
    {
        'question': 'Which programming language is known for its use in web development?',
        'options': ['Python', 'JavaScript', 'C++', 'Java'],
        'correct': 1,
        'category': 'Technology'
    },
    {
        'question': 'What is the smallest prime number?',
        'options': ['0', '1', '2', '3'],
        'correct': 2,
        'category': 'Math'
    },
    {
        'question': 'Which ocean is the largest?',
        'options': ['Atlantic', 'Indian', 'Arctic', 'Pacific'],
        'correct': 3,
        'category': 'Geography'
    },
    {
        'question': 'Who painted the Mona Lisa?',
        'options': ['Vincent van Gogh', 'Pablo Picasso', 'Leonardo da Vinci', 'Michelangelo'],
        'correct': 2,
        'category': 'Art'
    }
]

def load_questions():
    """Load questions from file or create default"""
    if os.path.exists(QUIZ_FILE):
        with open(QUIZ_FILE, 'r') as file:
            return json.load(file)
    else:
        save_questions(SAMPLE_QUESTIONS)
        return SAMPLE_QUESTIONS

def save_questions(questions):
    """Save questions to file"""
    with open(QUIZ_FILE, 'w') as file:
        json.dump(questions, file, indent=4)

def add_question():
    """Add a new question to the quiz"""
    questions = load_questions()
    
    print("\n=== Add New Question ===")
    question_text = input("Enter question: ")
    
    options = []
    for i in range(4):
        option = input(f"Option {i+1}: ")
        options.append(option)
    
    correct = int(input("Correct option (1-4): ")) - 1
    category = input("Category: ")
    
    new_question = {
        'question': question_text,
        'options': options,
        'correct': correct,
        'category': category
    }
    
    questions.append(new_question)
    save_questions(questions)
    
    print("✓ Question added successfully!")

def take_quiz(num_questions=5, category=None):
    """Take a random quiz"""
    questions = load_questions()
    
    # Filter by category if specified
    if category:
        questions = [q for q in questions if q['category'].lower() == category.lower()]
        
        if not questions:
            print(f"❌ No questions found in category: {category}")
            return
    
    # Select random questions
    if len(questions) < num_questions:
        print(f"⚠️  Only {len(questions)} questions available")
        num_questions = len(questions)
    
    selected_questions = random.sample(questions, num_questions)
    
    score = 0
    results = []
    
    print("\n" + "="*60)
    print(f"🎯 QUIZ TIME! ({num_questions} questions)")
    print("="*60)
    
    for i, q in enumerate(selected_questions, 1):
        print(f"\nQuestion {i}/{num_questions}")
        print(f"Category: {q['category']}")
        print(f"\n{q['question']}")
        
        # Randomize option order
        options = list(enumerate(q['options']))
        random.shuffle(options)
        
        # Display options
        option_map = {}
        for j, (original_idx, option_text) in enumerate(options):
            print(f"  {j+1}. {option_text}")
            option_map[j+1] = original_idx
        
        # Get answer
        while True:
            try:
                answer = int(input("\nYour answer (1-4): "))
                if 1 <= answer <= 4:
                    break
                print("❌ Please enter a number between 1 and 4")
            except ValueError:
                print("❌ Please enter a valid number")
        
        # Check answer
        is_correct = option_map[answer] == q['correct']
        
        if is_correct:
            print("✅ Correct!")
            score += 1
        else:
            correct_answer = q['options'][q['correct']]
            print(f"❌ Wrong! The correct answer was: {correct_answer}")
        
        results.append({
            'question': q['question'],
            'your_answer': q['options'][option_map[answer]],
            'correct_answer': q['options'][q['correct']],
            'is_correct': is_correct
        })
    
    # Show final results
    print("\n" + "="*60)
    print("📊 QUIZ RESULTS")
    print("="*60)
    print(f"Score: {score}/{num_questions} ({score/num_questions*100:.1f}%)")
    
    if score == num_questions:
        print("🎉 Perfect score! Excellent work!")
    elif score >= num_questions * 0.8:
        print("🌟 Great job! You did very well!")
    elif score >= num_questions * 0.6:
        print("👍 Good effort! Keep practicing!")
    else:
        print("📚 Keep learning! You'll do better next time!")
    
    # Detailed results
    print("\n=== Detailed Results ===")
    for i, result in enumerate(results, 1):
        status = "✅" if result['is_correct'] else "❌"
        print(f"\n{i}. {status} {result['question']}")
        print(f"   Your answer: {result['your_answer']}")
        if not result['is_correct']:
            print(f"   Correct answer: {result['correct_answer']}")

def practice_mode():
    """Practice with immediate feedback"""
    questions = load_questions()
    
    print("\n=== Practice Mode ===")
    print("Get immediate feedback after each question!")
    
    random.shuffle(questions)
    
    correct_streak = 0
    max_streak = 0
    
    for i, q in enumerate(questions, 1):
        print(f"\n{'='*60}")
        print(f"Question {i}/{len(questions)}")
        print(f"Current streak: {correct_streak} | Best: {max_streak}")
        print(f"Category: {q['category']}")
        print(f"\n{q['question']}")
        
        for j, option in enumerate(q['options'], 1):
            print(f"  {j}. {option}")
        
        try:
            answer = int(input("\nYour answer (1-4, or 0 to skip): "))
            
            if answer == 0:
                print(f"⏭️  Skipped. Correct answer: {q['options'][q['correct']]}")
                correct_streak = 0
                continue
            
            if answer - 1 == q['correct']:
                correct_streak += 1
                max_streak = max(max_streak, correct_streak)
                print(f"✅ Correct! Streak: {correct_streak}")
            else:
                print(f"❌ Wrong! Correct answer: {q['options'][q['correct']]}")
                correct_streak = 0
        
        except (ValueError, IndexError):
            print("❌ Invalid input")
            correct_streak = 0
    
    print(f"\n🎯 Practice complete! Best streak: {max_streak}")

def show_categories():
    """Show all available categories"""
    questions = load_questions()
    
    categories = {}
    for q in questions:
        cat = q['category']
        categories[cat] = categories.get(cat, 0) + 1
    
    print("\n=== Available Categories ===")
    for cat, count in sorted(categories.items()):
        print(f"  • {cat}: {count} question(s)")

def quiz_statistics():
    """Show quiz statistics"""
    questions = load_questions()
    
    categories = {}
    for q in questions:
        cat = q['category']
        categories[cat] = categories.get(cat, 0) + 1
    
    print("\n" + "="*60)
    print("📊 QUIZ STATISTICS")
    print("="*60)
    print(f"Total questions: {len(questions)}")
    print(f"Categories: {len(categories)}")
    
    print("\n=== Questions by Category ===")
    for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        percentage = (count / len(questions)) * 100
        bar = '█' * int(percentage / 5)
        print(f"{cat:15} {bar} {count} ({percentage:.1f}%)")

def main():
    """Main menu"""
    
    while True:
        print("\n" + "="*60)
        print("🎮 RANDOM QUIZ APP")
        print("="*60)
        print("1. Take Random Quiz")
        print("2. Take Quiz by Category")
        print("3. Practice Mode")
        print("4. Add Question")
        print("5. Show Categories")
        print("6. Quiz Statistics")
        print("7. Exit")
        print("="*60)
        
        choice = input("Enter your choice (1-7): ")
        
        try:
            if choice == '1':
                num = int(input("Number of questions (default 5): ") or "5")
                take_quiz(num)
            
            elif choice == '2':
                show_categories()
                category = input("\nEnter category: ")
                num = int(input("Number of questions (default 5): ") or "5")
                take_quiz(num, category)
            
            elif choice == '3':
                practice_mode()
            
            elif choice == '4':
                add_question()
            
            elif choice == '5':
                show_categories()
            
            elif choice == '6':
                quiz_statistics()
            
            elif choice == '7':
                print("\nThanks for playing! 👋")
                break
            
            else:
                print("\n❌ Invalid choice! Please try again.")
        
        except ValueError as e:
            print(f"\n❌ Error: {e}")
        except KeyboardInterrupt:
            print("\n\nGoodbye! 👋")
            break

if __name__ == "__main__":
    main()
