"""
Random Library Basics
The random module provides functions for generating random numbers.
"""

import random

# Random floats
print("=== Random Floats ===")
print(f"Random float [0.0, 1.0): {random.random()}")
print(f"Random float [0.0, 1.0): {random.random()}")
print(f"Random float [0.0, 1.0): {random.random()}")

# Random integers
print("\n=== Random Integers ===")
print(f"Random int [1, 10]: {random.randint(1, 10)}")
print(f"Random int [1, 10]: {random.randint(1, 10)}")
print(f"Random int [1, 10]: {random.randint(1, 10)}")

# randrange - like range()
print("\n=== Random Range ===")
print(f"Random even number [0, 100): {random.randrange(0, 100, 2)}")
print(f"Random number [0, 100) step 5: {random.randrange(0, 100, 5)}")

# Random float in range
print("\n=== Random Float in Range ===")
print(f"Random float [10.0, 20.0]: {random.uniform(10, 20):.2f}")
print(f"Random float [10.0, 20.0]: {random.uniform(10, 20):.2f}")

# Random choice from sequence
print("\n=== Random Choice ===")
colors = ['red', 'green', 'blue', 'yellow', 'purple']
print(f"Colors: {colors}")
print(f"Random color: {random.choice(colors)}")
print(f"Random color: {random.choice(colors)}")
print(f"Random color: {random.choice(colors)}")

# Random choices with replacement (can repeat)
print("\n=== Random Choices (with replacement) ===")
choices = random.choices(colors, k=3)
print(f"3 random colors (can repeat): {choices}")

# Random sample without replacement (no repeats)
print("\n=== Random Sample (without replacement) ===")
sample = random.sample(colors, k=3)
print(f"3 random colors (unique): {sample}")

# Shuffle a list
print("\n=== Shuffle List ===")
deck = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
print(f"Original: {deck}")
random.shuffle(deck)
print(f"Shuffled: {deck}")

# Weighted random choices
print("\n=== Weighted Random Choices ===")
items = ['common', 'uncommon', 'rare', 'legendary']
weights = [50, 30, 15, 5]  # Probability weights

print(f"Items: {items}")
print(f"Weights: {weights}")

for i in range(5):
    item = random.choices(items, weights=weights, k=1)[0]
    print(f"  Drop {i+1}: {item}")

# Random seed (for reproducibility)
print("\n=== Random Seed ===")
print("Without seed (different each time):")
for i in range(3):
    print(f"  {random.randint(1, 100)}")

print("\nWith seed (same sequence):")
random.seed(42)
for i in range(3):
    print(f"  {random.randint(1, 100)}")

print("\nReset seed to 42 (same sequence again):")
random.seed(42)
for i in range(3):
    print(f"  {random.randint(1, 100)}")

# Random distributions
print("\n=== Random Distributions ===")

# Gaussian/Normal distribution
print("Normal distribution (mean=0, std=1):")
for i in range(5):
    value = random.gauss(0, 1)
    print(f"  {value:.3f}")

# Triangular distribution
print("\nTriangular distribution (low=0, high=10, mode=5):")
for i in range(5):
    value = random.triangular(0, 10, 5)
    print(f"  {value:.2f}")

# Beta distribution
print("\nBeta distribution (alpha=2, beta=5):")
for i in range(5):
    value = random.betavariate(2, 5)
    print(f"  {value:.3f}")

# Random bytes
print("\n=== Random Bytes ===")
random_bytes = random.randbytes(8)
print(f"8 random bytes: {random_bytes.hex()}")

# Practical examples
print("\n" + "="*60)
print("=== Practical Examples ===\n")

# Dice roll
print("🎲 Dice Roll:")
dice1 = random.randint(1, 6)
dice2 = random.randint(1, 6)
print(f"  Die 1: {dice1}")
print(f"  Die 2: {dice2}")
print(f"  Total: {dice1 + dice2}")

# Coin flip
print("\n🪙 Coin Flip:")
flips = [random.choice(['Heads', 'Tails']) for _ in range(10)]
print(f"  10 flips: {flips}")
print(f"  Heads: {flips.count('Heads')}, Tails: {flips.count('Tails')}")

# Random password generator
print("\n🔐 Random Password Generator:")
import string

def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

for i in range(3):
    print(f"  Password {i+1}: {generate_password()}")

# Random quiz question selector
print("\n📚 Random Quiz Questions:")
questions = [
    "What is Python?",
    "What is a variable?",
    "What is a function?",
    "What is a loop?",
    "What is a list?"
]

quiz = random.sample(questions, k=3)
for i, question in enumerate(quiz, 1):
    print(f"  Q{i}: {question}")

# Random color generator (RGB)
print("\n🎨 Random RGB Colors:")
for i in range(3):
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    print(f"  Color {i+1}: RGB({r}, {g}, {b}) - #{r:02x}{g:02x}{b:02x}")

# Lottery number generator
print("\n🎰 Lottery Numbers:")
lottery = sorted(random.sample(range(1, 50), k=6))
print(f"  Your lucky numbers: {lottery}")

# Random team selector
print("\n👥 Random Team Selector:")
players = ['Alice', 'Bob', 'Charlie', 'David', 'Emma', 'Frank', 'Grace', 'Henry']
random.shuffle(players)

team_size = len(players) // 2
team1 = players[:team_size]
team2 = players[team_size:]

print(f"  Team 1: {', '.join(team1)}")
print(f"  Team 2: {', '.join(team2)}")
