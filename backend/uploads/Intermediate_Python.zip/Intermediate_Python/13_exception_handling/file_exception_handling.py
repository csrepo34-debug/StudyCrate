# File Operations with Exception Handling

print("=== File Operations with Exception Handling ===\n")

# Example 1: Reading a file with error handling
def read_file_safe(filename):
    try:
        with open(filename, 'r') as file:
            content = file.read()
            return content
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found")
        return None
    except PermissionError:
        print(f"Error: No permission to read '{filename}'")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None

# Test file reading
print("--- Reading Files ---")
content = read_file_safe("nonexistent.txt")
if content:
    print(content)

# Example 2: Writing to file with error handling
def write_file_safe(filename, content):
    try:
        with open(filename, 'w') as file:
            file.write(content)
        print(f"Successfully wrote to '{filename}'")
        return True
    except PermissionError:
        print(f"Error: No permission to write to '{filename}'")
        return False
    except Exception as e:
        print(f"Error writing file: {e}")
        return False

print("\n--- Writing Files ---")
write_file_safe("output.txt", "This is test data\nLine 2\nLine 3")

# Example 3: Processing file with multiple exception types
def process_data_file(filename):
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
            
        numbers = []
        for line_num, line in enumerate(lines, 1):
            try:
                number = int(line.strip())
                numbers.append(number)
            except ValueError:
                print(f"Warning: Line {line_num} contains invalid number: '{line.strip()}'")
                continue
        
        if numbers:
            total = sum(numbers)
            average = total / len(numbers)
            print(f"\nProcessed {len(numbers)} numbers")
            print(f"Total: {total}")
            print(f"Average: {average:.2f}")
        else:
            print("No valid numbers found")
            
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found")
    except Exception as e:
        print(f"Error processing file: {e}")

# Create test file and process it
print("\n--- Processing Data File ---")
try:
    with open("numbers.txt", 'w') as f:
        f.write("10\n20\ninvalid\n30\n40\n")
    
    process_data_file("numbers.txt")
except Exception as e:
    print(f"Error: {e}")

# Example 4: Cleanup with finally
def copy_file_with_cleanup(source, destination):
    source_file = None
    dest_file = None
    
    try:
        source_file = open(source, 'r')
        dest_file = open(destination, 'w')
        
        content = source_file.read()
        dest_file.write(content)
        
        print(f"Successfully copied '{source}' to '{destination}'")
        
    except FileNotFoundError:
        print(f"Error: Source file '{source}' not found")
    except PermissionError:
        print("Error: Permission denied")
    except Exception as e:
        print(f"Error during copy: {e}")
    finally:
        # Ensure files are closed
        if source_file:
            source_file.close()
            print("Source file closed")
        if dest_file:
            dest_file.close()
            print("Destination file closed")

print("\n--- File Copy with Cleanup ---")
copy_file_with_cleanup("output.txt", "backup.txt")
