# Raising Exceptions

print("=== Raising Exceptions ===\n")

# Example 1: Raise basic exception
def check_positive(number):
    if number < 0:
        raise ValueError("Number must be positive")
    return number

try:
    value = check_positive(-5)
except ValueError as e:
    print(f"Error: {e}")

# Example 2: Age validation
def set_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative")
    if age > 150:
        raise ValueError("Age is unrealistically high")
    return age

try:
    age = set_age(200)
except ValueError as e:
    print(f"\nAge validation error: {e}")

# Example 3: Division function with raise
def safe_divide(a, b):
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero")
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("Both arguments must be numbers")
    return a / b

try:
    result = safe_divide(10, 0)
except ZeroDivisionError as e:
    print(f"\n{e}")

# Example 4: Re-raising exceptions
def process_data(data):
    try:
        # Simulate processing
        result = int(data)
        return result
    except ValueError as e:
        print(f"Error processing data: {e}")
        raise  # Re-raise the same exception

try:
    process_data("invalid")
except ValueError:
    print("Caught re-raised exception")

# Example 5: Password validation
def validate_password(password):
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    if not any(char.isdigit() for char in password):
        raise ValueError("Password must contain at least one digit")
    if not any(char.isupper() for char in password):
        raise ValueError("Password must contain at least one uppercase letter")
    return True

passwords = ["weak", "StrongPass", "Strong123"]

print("\n--- Password Validation ---")
for pwd in passwords:
    try:
        validate_password(pwd)
        print(f"'{pwd}' is valid")
    except ValueError as e:
        print(f"'{pwd}' is invalid: {e}")
