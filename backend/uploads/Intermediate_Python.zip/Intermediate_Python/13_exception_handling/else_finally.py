# Exception Handling with Else and Finally

print("=== Try-Except-Else-Finally ===\n")

# Example 1: Using else clause
try:
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))
    result = num1 / num2
except ValueError:
    print("Invalid input! Please enter numbers only")
except ZeroDivisionError:
    print("Cannot divide by zero!")
else:
    # This runs only if no exception occurred
    print(f"Result: {num1} / {num2} = {result}")

# Example 2: Using finally clause
print("\n--- File Operation Example ---")
file_name = "test_data.txt"

try:
    file = open(file_name, 'w')
    file.write("Test data")
    print("Data written successfully")
except IOError:
    print(f"Error writing to file {file_name}")
finally:
    # This always runs, even if exception occurs
    try:
        file.close()
        print("File closed")
    except:
        print("File was not opened")

# Example 3: Complete structure
print("\n--- Complete Try-Except-Else-Finally ---")

def divide_numbers(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Error: Division by zero")
        return None
    except TypeError:
        print("Error: Invalid types for division")
        return None
    else:
        print(f"Division successful: {a} / {b} = {result}")
        return result
    finally:
        print("Function execution completed")

# Test the function
print("\nTest 1:")
divide_numbers(10, 2)

print("\nTest 2:")
divide_numbers(10, 0)

print("\nTest 3:")
divide_numbers(10, "2")
