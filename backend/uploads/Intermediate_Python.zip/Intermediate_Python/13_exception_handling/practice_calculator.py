# Practice: Create a calculator with comprehensive exception handling

class CalculatorError(Exception):
    """Base exception for calculator errors"""
    pass

class InvalidOperatorError(CalculatorError):
    """Exception for invalid operators"""
    pass

class Calculator:
    """Calculator with exception handling"""
    
    def __init__(self):
        self.history = []
    
    def add(self, a, b):
        """Add two numbers"""
        try:
            result = float(a) + float(b)
            self.history.append(f"{a} + {b} = {result}")
            return result
        except (ValueError, TypeError) as e:
            raise CalculatorError(f"Invalid input for addition: {e}")
    
    def subtract(self, a, b):
        """Subtract b from a"""
        try:
            result = float(a) - float(b)
            self.history.append(f"{a} - {b} = {result}")
            return result
        except (ValueError, TypeError) as e:
            raise CalculatorError(f"Invalid input for subtraction: {e}")
    
    def multiply(self, a, b):
        """Multiply two numbers"""
        try:
            result = float(a) * float(b)
            self.history.append(f"{a} * {b} = {result}")
            return result
        except (ValueError, TypeError) as e:
            raise CalculatorError(f"Invalid input for multiplication: {e}")
    
    def divide(self, a, b):
        """Divide a by b"""
        try:
            a = float(a)
            b = float(b)
            if b == 0:
                raise ZeroDivisionError("Cannot divide by zero")
            result = a / b
            self.history.append(f"{a} / {b} = {result}")
            return result
        except ZeroDivisionError as e:
            raise CalculatorError(str(e))
        except (ValueError, TypeError) as e:
            raise CalculatorError(f"Invalid input for division: {e}")
    
    def power(self, base, exponent):
        """Calculate base raised to exponent"""
        try:
            result = float(base) ** float(exponent)
            self.history.append(f"{base} ^ {exponent} = {result}")
            return result
        except (ValueError, TypeError) as e:
            raise CalculatorError(f"Invalid input for power: {e}")
        except OverflowError:
            raise CalculatorError("Result too large to calculate")
    
    def calculate(self, expression):
        """Parse and calculate expression like '5 + 3'"""
        try:
            parts = expression.split()
            if len(parts) != 3:
                raise InvalidOperatorError("Expression must be in format: number operator number")
            
            num1, operator, num2 = parts
            
            if operator == '+':
                return self.add(num1, num2)
            elif operator == '-':
                return self.subtract(num1, num2)
            elif operator == '*':
                return self.multiply(num1, num2)
            elif operator == '/':
                return self.divide(num1, num2)
            elif operator == '^' or operator == '**':
                return self.power(num1, num2)
            else:
                raise InvalidOperatorError(f"Unknown operator: {operator}")
        
        except InvalidOperatorError as e:
            raise CalculatorError(str(e))
        except Exception as e:
            raise CalculatorError(f"Error parsing expression: {e}")
    
    def show_history(self):
        """Display calculation history"""
        if self.history:
            print("\nCalculation History:")
            for i, calc in enumerate(self.history, 1):
                print(f"{i}. {calc}")
        else:
            print("No calculations yet")

# Test the calculator
print("=== Advanced Calculator with Exception Handling ===\n")

calc = Calculator()

# Test cases
test_expressions = [
    "10 + 5",
    "20 - 8",
    "6 * 7",
    "15 / 3",
    "2 ^ 8",
    "10 / 0",      # Division by zero
    "5 + abc",     # Invalid number
    "10 % 3",      # Invalid operator
    "5 +",         # Incomplete expression
]

for expr in test_expressions:
    try:
        result = calc.calculate(expr)
        print(f"{expr} = {result}")
    except CalculatorError as e:
        print(f"Error with '{expr}': {e}")

# Show history
calc.show_history()

# Direct method calls
print("\n--- Direct Method Calls ---")
try:
    print(f"100 / 4 = {calc.divide(100, 4)}")
    print(f"3 ^ 4 = {calc.power(3, 4)}")
    calc.divide(10, 0)  # Will raise exception
except CalculatorError as e:
    print(f"Error: {e}")

# Final history
calc.show_history()
