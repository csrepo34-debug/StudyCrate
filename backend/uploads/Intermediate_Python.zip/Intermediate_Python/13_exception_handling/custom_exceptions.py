# Custom Exceptions

print("=== Custom Exception Classes ===\n")

# Example 1: Simple custom exception
class InvalidAgeError(Exception):
    """Exception raised for invalid age values"""
    pass

def set_age(age):
    if age < 0:
        raise InvalidAgeError("Age cannot be negative")
    if age > 150:
        raise InvalidAgeError("Age cannot exceed 150")
    return age

try:
    user_age = set_age(-5)
except InvalidAgeError as e:
    print(f"Custom Exception Caught: {e}")

# Example 2: Custom exception with attributes
class InsufficientFundsError(Exception):
    """Exception raised when account has insufficient funds"""
    
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount
        message = f"Insufficient funds: Balance ${balance}, Required ${amount}"
        super().__init__(message)

class BankAccount:
    def __init__(self, balance=0):
        self.balance = balance
    
    def withdraw(self, amount):
        if amount > self.balance:
            raise InsufficientFundsError(self.balance, amount)
        self.balance -= amount
        return self.balance

# Test custom exception
print("\n--- Bank Account Example ---")
account = BankAccount(100)

try:
    account.withdraw(50)
    print("Withdrawal successful. Balance: $", account.balance)
    account.withdraw(100)  # This will raise exception
except InsufficientFundsError as e:
    print(f"Error: {e}")
    print(f"Current balance: ${e.balance}")
    print(f"Attempted withdrawal: ${e.amount}")

# Example 3: Multiple custom exceptions
class ValidationError(Exception):
    """Base class for validation errors"""
    pass

class EmailValidationError(ValidationError):
    """Invalid email format"""
    pass

class PhoneValidationError(ValidationError):
    """Invalid phone number format"""
    pass

def validate_email(email):
    if '@' not in email or '.' not in email:
        raise EmailValidationError(f"Invalid email format: {email}")
    return True

def validate_phone(phone):
    if not phone.replace('-', '').replace(' ', '').isdigit():
        raise PhoneValidationError(f"Invalid phone number: {phone}")
    return True

print("\n--- Validation Examples ---")
test_data = [
    ('email', 'invalid-email'),
    ('phone', 'abc-def-ghij'),
    ('email', 'valid@email.com'),
    ('phone', '555-1234')
]

for data_type, value in test_data:
    try:
        if data_type == 'email':
            validate_email(value)
            print(f"Valid email: {value}")
        elif data_type == 'phone':
            validate_phone(value)
            print(f"Valid phone: {value}")
    except ValidationError as e:
        print(f"Validation Error: {e}")
