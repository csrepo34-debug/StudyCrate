"""
datetime Module Basics
The datetime module provides classes for working with dates and times.
"""

from datetime import datetime, date, time, timedelta

# Current date and time
print("=== Current Date and Time ===")
now = datetime.now()
print(f"Current datetime: {now}")
print(f"Year: {now.year}")
print(f"Month: {now.month}")
print(f"Day: {now.day}")
print(f"Hour: {now.hour}")
print(f"Minute: {now.minute}")
print(f"Second: {now.second}")

# Today's date
print("\n=== Today's Date ===")
today = date.today()
print(f"Today: {today}")
print(f"Day of week: {today.strftime('%A')}")
print(f"Day of year: {today.timetuple().tm_yday}")

# Creating specific dates
print("\n=== Creating Specific Dates ===")
specific_date = date(2026, 12, 25)
print(f"Christmas 2026: {specific_date}")

specific_datetime = datetime(2026, 1, 1, 12, 30, 45)
print(f"Specific datetime: {specific_datetime}")

# Creating time objects
print("\n=== Time Objects ===")
morning = time(9, 30, 0)
evening = time(18, 45, 30)
print(f"Morning: {morning}")
print(f"Evening: {evening}")

# Date arithmetic with timedelta
print("\n=== Date Arithmetic ===")
today = date.today()
print(f"Today: {today}")

# Add days
tomorrow = today + timedelta(days=1)
print(f"Tomorrow: {tomorrow}")

next_week = today + timedelta(weeks=1)
print(f"Next week: {next_week}")

# Subtract days
yesterday = today - timedelta(days=1)
print(f"Yesterday: {yesterday}")

# Add hours, minutes, seconds
now = datetime.now()
future = now + timedelta(hours=2, minutes=30, seconds=45)
print(f"\nNow: {now.strftime('%H:%M:%S')}")
print(f"Future: {future.strftime('%H:%M:%S')}")

# Difference between dates
print("\n=== Date Differences ===")
birthday = date(2000, 5, 15)
today = date.today()
age_days = today - birthday
print(f"Days since birthday: {age_days.days}")
print(f"Years old: {age_days.days // 365}")

# Comparing dates
print("\n=== Comparing Dates ===")
date1 = date(2026, 1, 1)
date2 = date(2026, 12, 31)

if date1 < date2:
    print(f"{date1} is before {date2}")

if date2 > date1:
    print(f"{date2} is after {date1}")

# Weekday
print("\n=== Weekday Information ===")
today = date.today()
print(f"Today: {today}")
print(f"Weekday number: {today.weekday()}")  # Monday = 0, Sunday = 6
print(f"ISO Weekday: {today.isoweekday()}")  # Monday = 1, Sunday = 7
print(f"Day name: {today.strftime('%A')}")

# Replace parts of datetime
print("\n=== Replacing DateTime Parts ===")
now = datetime.now()
print(f"Original: {now}")

new_year = now.replace(month=1, day=1)
print(f"Changed to New Year: {new_year}")

midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
print(f"Midnight today: {midnight}")

# Parsing dates from strings
print("\n=== Parsing Dates from Strings ===")
date_string = "2026-01-19"
parsed_date = datetime.strptime(date_string, "%Y-%m-%d")
print(f"Parsed: {parsed_date}")

date_string2 = "19/01/2026 14:30"
parsed_date2 = datetime.strptime(date_string2, "%d/%m/%Y %H:%M")
print(f"Parsed: {parsed_date2}")

# ISO format
print("\n=== ISO Format ===")
now = datetime.now()
iso_format = now.isoformat()
print(f"ISO format: {iso_format}")

# Timestamp
print("\n=== Unix Timestamp ===")
now = datetime.now()
timestamp = now.timestamp()
print(f"Timestamp: {timestamp}")

# Convert timestamp back to datetime
dt_from_timestamp = datetime.fromtimestamp(timestamp)
print(f"From timestamp: {dt_from_timestamp}")

# Useful timedelta examples
print("\n=== Useful Timedelta Examples ===")
print(f"One week from now: {date.today() + timedelta(weeks=1)}")
print(f"30 days ago: {date.today() - timedelta(days=30)}")
print(f"6 months from now (approx): {date.today() + timedelta(days=180)}")
print(f"1 year ago (approx): {date.today() - timedelta(days=365)}")
