"""
Time Formatting with strftime and strptime
Format dates and times as strings and parse strings as dates.
"""

from datetime import datetime, date

# strftime - Convert datetime to string
print("=== strftime - Format DateTime as String ===")
now = datetime.now()

# Common format codes
print(f"Full date and time: {now.strftime('%c')}")
print(f"Date only: {now.strftime('%x')}")
print(f"Time only: {now.strftime('%X')}")

# Custom formats
print("\n=== Custom Date Formats ===")
print(f"YYYY-MM-DD: {now.strftime('%Y-%m-%d')}")
print(f"DD/MM/YYYY: {now.strftime('%d/%m/%Y')}")
print(f"MM/DD/YYYY: {now.strftime('%m/%d/%Y')}")
print(f"Month DD, YYYY: {now.strftime('%B %d, %Y')}")
print(f"DD-Mon-YY: {now.strftime('%d-%b-%y')}")

# Custom time formats
print("\n=== Custom Time Formats ===")
print(f"24-hour: {now.strftime('%H:%M:%S')}")
print(f"12-hour: {now.strftime('%I:%M:%S %p')}")
print(f"Hour and minute: {now.strftime('%H:%M')}")
print(f"With AM/PM: {now.strftime('%I:%M %p')}")

# Day and month names
print("\n=== Day and Month Names ===")
print(f"Full weekday: {now.strftime('%A')}")
print(f"Short weekday: {now.strftime('%a')}")
print(f"Full month: {now.strftime('%B')}")
print(f"Short month: {now.strftime('%b')}")

# Combined formats
print("\n=== Combined Formats ===")
print(f"Full: {now.strftime('%A, %B %d, %Y at %I:%M %p')}")
print(f"ISO 8601: {now.strftime('%Y-%m-%dT%H:%M:%S')}")
print(f"RFC 2822: {now.strftime('%a, %d %b %Y %H:%M:%S')}")

# Week and day numbers
print("\n=== Week and Day Numbers ===")
print(f"Week number: {now.strftime('%W')}")
print(f"Day of year: {now.strftime('%j')}")
print(f"Weekday (0-6): {now.strftime('%w')}")

# strptime - Parse string to datetime
print("\n" + "="*60)
print("=== strptime - Parse String to DateTime ===")

# Parse different date formats
date_strings = [
    ("2026-01-19", "%Y-%m-%d"),
    ("19/01/2026", "%d/%m/%Y"),
    ("01-19-2026", "%m-%d-%Y"),
    ("January 19, 2026", "%B %d, %Y"),
    ("19-Jan-26", "%d-%b-%y"),
]

for date_str, format_str in date_strings:
    parsed = datetime.strptime(date_str, format_str)
    print(f"'{date_str}' → {parsed}")

# Parse datetime with time
print("\n=== Parsing DateTime with Time ===")
datetime_strings = [
    ("2026-01-19 14:30:00", "%Y-%m-%d %H:%M:%S"),
    ("19/01/2026 2:30 PM", "%d/%m/%Y %I:%M %p"),
    ("Jan 19, 2026 14:30", "%b %d, %Y %H:%M"),
]

for dt_str, format_str in datetime_strings:
    parsed = datetime.strptime(dt_str, format_str)
    print(f"'{dt_str}' → {parsed}")

# Format codes reference
print("\n" + "="*60)
print("=== Common Format Codes Reference ===")
print("""
Date Codes:
  %Y - Year with century (2026)
  %y - Year without century (26)
  %m - Month as number (01-12)
  %B - Full month name (January)
  %b - Abbreviated month (Jan)
  %d - Day of month (01-31)
  %A - Full weekday name (Monday)
  %a - Abbreviated weekday (Mon)
  %j - Day of year (001-366)
  %w - Weekday as number (0=Sunday, 6=Saturday)
  %W - Week number (00-53)

Time Codes:
  %H - Hour 24-hour (00-23)
  %I - Hour 12-hour (01-12)
  %M - Minute (00-59)
  %S - Second (00-59)
  %p - AM/PM
  %f - Microsecond (000000-999999)

Combined:
  %c - Complete date and time
  %x - Date representation
  %X - Time representation
""")

# Practical examples
print("="*60)
print("=== Practical Formatting Examples ===\n")

now = datetime.now()

# Log format
log_format = now.strftime('[%Y-%m-%d %H:%M:%S]')
print(f"Log format: {log_format} Application started")

# User-friendly format
friendly = now.strftime('%A, %B %d, %Y at %I:%M %p')
print(f"Friendly: {friendly}")

# Filename format
filename = now.strftime('backup_%Y%m%d_%H%M%S.zip')
print(f"Filename: {filename}")

# Database format
db_format = now.strftime('%Y-%m-%d %H:%M:%S')
print(f"Database: {db_format}")

# Converting between formats
print("\n=== Converting Between Formats ===")

# Input format: DD/MM/YYYY
input_date = "19/01/2026"
# Parse it
parsed = datetime.strptime(input_date, "%d/%m/%Y")
# Output format: Month DD, YYYY
output_date = parsed.strftime("%B %d, %Y")
print(f"Input: {input_date}")
print(f"Output: {output_date}")

# Time zone considerations
print("\n=== Important Notes ===")
print("⚠️  datetime.now() returns local time")
print("⚠️  For time zones, use the 'pytz' or 'zoneinfo' module")
print("⚠️  strptime is strict - format must match exactly")
