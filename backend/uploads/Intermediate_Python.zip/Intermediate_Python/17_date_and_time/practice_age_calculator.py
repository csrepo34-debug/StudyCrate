"""
Practice: Age Calculator
Calculate age and related information from birthdate.
"""

from datetime import datetime, date, timedelta

def calculate_age(birthdate):
    """Calculate age in years from birthdate"""
    today = date.today()
    age = today.year - birthdate.year
    
    # Check if birthday has occurred this year
    if (today.month, today.day) < (birthdate.month, birthdate.day):
        age -= 1
    
    return age

def calculate_detailed_age(birthdate):
    """Calculate age in years, months, and days"""
    today = date.today()
    
    # Calculate years
    years = today.year - birthdate.year
    
    # Calculate months
    months = today.month - birthdate.month
    
    # Calculate days
    days = today.day - birthdate.day
    
    # Adjust if necessary
    if days < 0:
        months -= 1
        # Get days in previous month
        if today.month == 1:
            prev_month = date(today.year - 1, 12, birthdate.day)
        else:
            prev_month = date(today.year, today.month - 1, birthdate.day)
        days = (today - prev_month).days
    
    if months < 0:
        years -= 1
        months += 12
    
    return years, months, days

def days_until_next_birthday(birthdate):
    """Calculate days until next birthday"""
    today = date.today()
    
    # Get this year's birthday
    next_birthday = date(today.year, birthdate.month, birthdate.day)
    
    # If birthday has passed this year, get next year's
    if next_birthday < today:
        next_birthday = date(today.year + 1, birthdate.month, birthdate.day)
    
    days_left = (next_birthday - today).days
    return days_left, next_birthday

def total_days_lived(birthdate):
    """Calculate total days lived"""
    today = date.today()
    return (today - birthdate).days

def get_zodiac_sign(birthdate):
    """Get zodiac sign from birthdate"""
    day = birthdate.day
    month = birthdate.month
    
    zodiac_signs = {
        (3, 21, 4, 19): 'Aries',
        (4, 20, 5, 20): 'Taurus',
        (5, 21, 6, 20): 'Gemini',
        (6, 21, 7, 22): 'Cancer',
        (7, 23, 8, 22): 'Leo',
        (8, 23, 9, 22): 'Virgo',
        (9, 23, 10, 22): 'Libra',
        (10, 23, 11, 21): 'Scorpio',
        (11, 22, 12, 21): 'Sagittarius',
        (12, 22, 1, 19): 'Capricorn',
        (1, 20, 2, 18): 'Aquarius',
        (2, 19, 3, 20): 'Pisces'
    }
    
    for (start_month, start_day, end_month, end_day), sign in zodiac_signs.items():
        if (month == start_month and day >= start_day) or (month == end_month and day <= end_day):
            return sign
    
    return 'Unknown'

def get_day_of_week_born(birthdate):
    """Get the day of the week when born"""
    return birthdate.strftime('%A')

def calculate_life_events(birthdate):
    """Calculate when life events occurred/will occur"""
    today = date.today()
    events = {}
    
    # 18th birthday
    event_18 = birthdate + timedelta(days=365*18)
    events['18th_birthday'] = {
        'date': event_18,
        'passed': event_18 < today
    }
    
    # 21st birthday
    event_21 = birthdate + timedelta(days=365*21)
    events['21st_birthday'] = {
        'date': event_21,
        'passed': event_21 < today
    }
    
    # 1000 days old
    event_1000 = birthdate + timedelta(days=1000)
    events['1000_days'] = {
        'date': event_1000,
        'passed': event_1000 < today
    }
    
    # 10000 days old
    event_10000 = birthdate + timedelta(days=10000)
    events['10000_days'] = {
        'date': event_10000,
        'passed': event_10000 < today
    }
    
    return events

# Example usage
print("=== Age Calculator Examples ===\n")

# Sample birthdate
birthdate = date(1995, 5, 15)

print(f"Birthdate: {birthdate.strftime('%B %d, %Y')}")
print(f"Day of week born: {get_day_of_week_born(birthdate)}")
print()

# Simple age
age = calculate_age(birthdate)
print(f"Age: {age} years old")

# Detailed age
years, months, days = calculate_detailed_age(birthdate)
print(f"Detailed age: {years} years, {months} months, {days} days")
print()

# Days lived
days_lived = total_days_lived(birthdate)
print(f"Total days lived: {days_lived:,} days")
print(f"Total weeks lived: {days_lived // 7:,} weeks")
print(f"Total hours lived (approx): {days_lived * 24:,} hours")
print()

# Next birthday
days_left, next_bday = days_until_next_birthday(birthdate)
print(f"Next birthday: {next_bday.strftime('%B %d, %Y')} ({next_bday.strftime('%A')})")
print(f"Days until next birthday: {days_left} days")
print()

# Zodiac sign
zodiac = get_zodiac_sign(birthdate)
print(f"Zodiac sign: {zodiac}")
print()

# Life events
print("=== Life Events ===")
events = calculate_life_events(birthdate)

for event_name, event_data in events.items():
    event_date = event_data['date']
    passed = event_data['passed']
    status = "✓ Passed" if passed else "⏳ Upcoming"
    
    print(f"{event_name.replace('_', ' ').title()}: {event_date.strftime('%B %d, %Y')} - {status}")

# Interactive age calculator
print("\n" + "="*60)
print("=== Interactive Age Calculator ===\n")

def interactive_calculator():
    while True:
        print("\nEnter birthdate information:")
        
        try:
            year = input("Year (YYYY) or 'quit' to exit: ").strip()
            
            if year.lower() == 'quit':
                print("\nGoodbye! 👋")
                break
            
            year = int(year)
            month = int(input("Month (1-12): "))
            day = int(input("Day (1-31): "))
            
            birthdate = date(year, month, day)
            
            print("\n" + "="*60)
            print(f"📅 BIRTHDATE: {birthdate.strftime('%B %d, %Y (%A)')}")
            print("="*60)
            
            # Age
            age = calculate_age(birthdate)
            years, months, days = calculate_detailed_age(birthdate)
            print(f"\n🎂 AGE: {age} years old")
            print(f"   Detailed: {years} years, {months} months, {days} days")
            
            # Days lived
            days_lived = total_days_lived(birthdate)
            print(f"\n⏱️  DAYS LIVED: {days_lived:,} days")
            print(f"   Weeks: {days_lived // 7:,}")
            print(f"   Hours (approx): {days_lived * 24:,}")
            
            # Next birthday
            days_left, next_bday = days_until_next_birthday(birthdate)
            print(f"\n🎉 NEXT BIRTHDAY: {next_bday.strftime('%B %d, %Y (%A)')}")
            print(f"   In {days_left} days")
            
            # Zodiac
            zodiac = get_zodiac_sign(birthdate)
            print(f"\n♋ ZODIAC SIGN: {zodiac}")
            
            # Life milestones
            print("\n🎯 LIFE MILESTONES:")
            events = calculate_life_events(birthdate)
            
            for event_name, event_data in events.items():
                event_date = event_data['date']
                passed = event_data['passed']
                
                if passed:
                    days_ago = (date.today() - event_date).days
                    print(f"   ✓ {event_name.replace('_', ' ').title()}: {event_date.strftime('%B %d, %Y')} ({days_ago} days ago)")
                else:
                    days_until = (event_date - date.today()).days
                    print(f"   ⏳ {event_name.replace('_', ' ').title()}: {event_date.strftime('%B %d, %Y')} (in {days_until} days)")
            
            print("\n" + "="*60)
            
        except ValueError as e:
            print(f"\n❌ Error: Invalid date! {e}")
        except KeyboardInterrupt:
            print("\n\nGoodbye! 👋")
            break

# Uncomment to run interactive mode
# interactive_calculator()

print("\n💡 Uncomment 'interactive_calculator()' at the end to run interactive mode")
