"""
Pattern Matching Basics
Regular expressions allow you to search for patterns in text.
"""

import re

# Basic pattern matching
print("=== Basic Pattern Matching ===")
text = "The quick brown fox jumps over the lazy dog"

# Search for a word
if re.search(r'fox', text):
    print("✓ 'fox' found in text")

# Find all occurrences
print("\n=== Finding All Matches ===")
text = "cat bat rat mat cat"
matches = re.findall(r'cat', text)
print(f"Found 'cat' {len(matches)} times: {matches}")

# Character classes
print("\n=== Character Classes ===")
text = "My phone number is 555-1234"

# Find digits
digits = re.findall(r'\d', text)
print(f"Digits: {digits}")

# Find all numbers
numbers = re.findall(r'\d+', text)
print(f"Numbers: {numbers}")

# Find words
words = re.findall(r'\w+', text)
print(f"Words: {words}")

# Metacharacters
print("\n=== Metacharacters ===")

# . (dot) - matches any character except newline
text = "cat, bat, hat, mat"
matches = re.findall(r'.at', text)
print(f"Matches for '.at': {matches}")

# ^ - matches start of string
text = "Hello World"
if re.search(r'^Hello', text):
    print("✓ Text starts with 'Hello'")

# $ - matches end of string
if re.search(r'World$', text):
    print("✓ Text ends with 'World'")

# Character sets
print("\n=== Character Sets ===")
text = "The year is 2026"

# [0-9] matches any digit
years = re.findall(r'[0-9]+', text)
print(f"Years found: {years}")

# [a-z] matches lowercase letters
text = "Hello World 123"
lowercase = re.findall(r'[a-z]+', text)
print(f"Lowercase words: {lowercase}")

# [A-Z] matches uppercase letters
uppercase = re.findall(r'[A-Z]', text)
print(f"Uppercase letters: {uppercase}")

# [a-zA-Z] matches any letter
letters = re.findall(r'[a-zA-Z]+', text)
print(f"All words: {letters}")

# Quantifiers
print("\n=== Quantifiers ===")

# * - zero or more
text = "color colour"
matches = re.findall(r'colou*r', text)
print(f"Matches for 'colou*r': {matches}")

# + - one or more
text = "goooogle google gogle"
matches = re.findall(r'go+gle', text)
print(f"Matches for 'go+gle': {matches}")

# ? - zero or one
text = "color colour"
matches = re.findall(r'colou?r', text)
print(f"Matches for 'colou?r': {matches}")

# {n} - exactly n times
text = "File1 File12 File123"
matches = re.findall(r'File\d{2}', text)
print(f"Matches for 'File\\d{{2}}': {matches}")

# {n,m} - between n and m times
matches = re.findall(r'File\d{1,3}', text)
print(f"Matches for 'File\\d{{1,3}}': {matches}")

# Groups
print("\n=== Groups ===")
text = "John: 555-1234, Jane: 555-5678"

# Capturing groups
matches = re.findall(r'(\w+): (\d{3}-\d{4})', text)
print(f"Name-Number pairs: {matches}")

for name, number in matches:
    print(f"  {name} -> {number}")

# Special sequences
print("\n=== Special Sequences ===")
text = "Hello World! How are you?"

# \d - digits [0-9]
# \D - non-digits [^0-9]
# \w - word characters [a-zA-Z0-9_]
# \W - non-word characters
# \s - whitespace characters
# \S - non-whitespace characters

spaces = re.findall(r'\s', text)
print(f"Spaces found: {len(spaces)}")

words = re.findall(r'\S+', text)
print(f"Words: {words}")
