"""
Practice: Password Strength Checker
Validate password strength using regular expressions.
"""

import re

def check_password_strength(password):
    """
    Check password strength based on multiple criteria
    
    Strength levels:
    - Weak: Less than 8 characters
    - Medium: 8+ characters with letters and numbers
    - Strong: 8+ characters with letters, numbers, and special chars
    - Very Strong: 12+ characters with all types + mixed case
    """
    score = 0
    feedback = []
    
    # Length check
    length = len(password)
    if length < 8:
        feedback.append("❌ Too short (minimum 8 characters)")
    elif length >= 8 and length < 12:
        score += 1
        feedback.append("✓ Adequate length")
    else:
        score += 2
        feedback.append("✓ Good length")
    
    # Lowercase letters
    if re.search(r'[a-z]', password):
        score += 1
        feedback.append("✓ Contains lowercase letters")
    else:
        feedback.append("❌ Missing lowercase letters")
    
    # Uppercase letters
    if re.search(r'[A-Z]', password):
        score += 1
        feedback.append("✓ Contains uppercase letters")
    else:
        feedback.append("❌ Missing uppercase letters")
    
    # Numbers
    if re.search(r'\d', password):
        score += 1
        feedback.append("✓ Contains numbers")
    else:
        feedback.append("❌ Missing numbers")
    
    # Special characters
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 1
        feedback.append("✓ Contains special characters")
    else:
        feedback.append("❌ Missing special characters (!@#$%^&* etc.)")
    
    # No repeating characters
    if not re.search(r'(.)\1{2,}', password):
        score += 1
        feedback.append("✓ No excessive repeating characters")
    else:
        feedback.append("⚠ Contains repeating characters")
    
    # Determine strength
    if score <= 2:
        strength = "Weak"
        color = "🔴"
    elif score <= 4:
        strength = "Medium"
        color = "🟡"
    elif score <= 6:
        strength = "Strong"
        color = "🟢"
    else:
        strength = "Very Strong"
        color = "🔵"
    
    return {
        'strength': strength,
        'score': score,
        'max_score': 8,
        'color': color,
        'feedback': feedback
    }

def validate_password_requirements(password, min_length=8, require_upper=True, 
                                   require_lower=True, require_digit=True, 
                                   require_special=True):
    """
    Validate password against specific requirements
    """
    errors = []
    
    # Length requirement
    if len(password) < min_length:
        errors.append(f"Password must be at least {min_length} characters")
    
    # Uppercase requirement
    if require_upper and not re.search(r'[A-Z]', password):
        errors.append("Password must contain at least one uppercase letter")
    
    # Lowercase requirement
    if require_lower and not re.search(r'[a-z]', password):
        errors.append("Password must contain at least one lowercase letter")
    
    # Digit requirement
    if require_digit and not re.search(r'\d', password):
        errors.append("Password must contain at least one digit")
    
    # Special character requirement
    if require_special and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        errors.append("Password must contain at least one special character")
    
    return len(errors) == 0, errors

def check_common_passwords(password):
    """Check if password is in common passwords list"""
    common_passwords = [
        'password', '123456', '12345678', 'qwerty', 'abc123',
        'password123', 'admin', 'letmein', 'welcome', 'monkey',
        '1234567890', 'password1', 'qwerty123', '000000'
    ]
    
    if password.lower() in common_passwords:
        return False, "This is a commonly used password - please choose something more unique"
    return True, "Not a common password"

def generate_password_suggestions():
    """Generate password suggestions"""
    suggestions = [
        "Use a mix of uppercase and lowercase letters",
        "Include numbers and special characters",
        "Make it at least 12 characters long",
        "Avoid dictionary words and common patterns",
        "Don't use personal information (birthdays, names)",
        "Consider using a passphrase (e.g., 'Coffee@Morning2026!')",
        "Use a password manager to generate and store strong passwords"
    ]
    return suggestions

# Test password strength checker
print("=== Password Strength Checker ===\n")

test_passwords = [
    "weak",                          # Very weak
    "password",                      # Weak - common
    "Password1",                     # Medium
    "P@ssw0rd",                      # Medium-Strong
    "MyP@ssw0rd2026",               # Strong
    "V3ry$tr0ng!P@ssw0rd#2026",    # Very Strong
    "aaaaaaa",                       # Weak - repeating
]

for pwd in test_passwords:
    result = check_password_strength(pwd)
    print(f"Password: {pwd}")
    print(f"Strength: {result['color']} {result['strength']} (Score: {result['score']}/{result['max_score']})")
    
    for item in result['feedback']:
        print(f"  {item}")
    
    # Check if common password
    is_safe, msg = check_common_passwords(pwd)
    if not is_safe:
        print(f"  ⚠️  {msg}")
    
    print()

# Requirement validation
print("="*60)
print("=== Password Requirement Validation ===\n")

test_pwd = "MySecure123"
is_valid, errors = validate_password_requirements(test_pwd)

print(f"Password: {test_pwd}")
if is_valid:
    print("✓ Meets all requirements!")
else:
    print("✗ Does not meet requirements:")
    for error in errors:
        print(f"  • {error}")

# Interactive checker
print("\n" + "="*60)
print("=== Interactive Password Checker ===\n")

def interactive_checker():
    print("Password Strength Checker")
    print("Enter passwords to check their strength (or 'quit' to exit)\n")
    
    while True:
        password = input("Enter password: ").strip()
        
        if password.lower() == 'quit':
            print("\nGoodbye! 👋")
            break
        
        if not password:
            print("❌ Please enter a password\n")
            continue
        
        print()
        
        # Strength check
        result = check_password_strength(password)
        print(f"{result['color']} Strength: {result['strength']} ({result['score']}/{result['max_score']} points)")
        print()
        
        # Feedback
        print("Criteria:")
        for item in result['feedback']:
            print(f"  {item}")
        
        # Common password check
        is_safe, msg = check_common_passwords(password)
        if not is_safe:
            print(f"\n⚠️  WARNING: {msg}")
        
        # Suggestions if weak
        if result['score'] < 5:
            print("\n💡 Suggestions:")
            suggestions = generate_password_suggestions()
            for i, suggestion in enumerate(suggestions[:3], 1):
                print(f"  {i}. {suggestion}")
        
        print("\n" + "-"*60 + "\n")

# Password generator hints
print("="*60)
print("=== Password Best Practices ===\n")

suggestions = generate_password_suggestions()
for i, suggestion in enumerate(suggestions, 1):
    print(f"{i}. {suggestion}")

print("\n" + "="*60)
print("Examples of strong passwords:")
print("  • Tr0pic@l$unset!2026")
print("  • C0ffee&D0nuts#Morning")
print("  • Bl.ue$ky!W@lking99")

# Uncomment to run interactive mode
# interactive_checker()
