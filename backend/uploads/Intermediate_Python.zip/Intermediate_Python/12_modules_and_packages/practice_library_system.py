# Practice: Create and use a library management module

class Book:
    """Book class for library management"""
    
    def __init__(self, title, author, isbn, available=True):
        self.title = title
        self.author = author
        self.isbn = isbn
        self.available = available
    
    def __str__(self):
        status = "Available" if self.available else "Checked out"
        return f"{self.title} by {self.author} (ISBN: {self.isbn}) - {status}"

class Library:
    """Library management system"""
    
    def __init__(self, name):
        self.name = name
        self.books = []
    
    def add_book(self, book):
        """Add a book to library"""
        self.books.append(book)
        print(f"Added: {book.title}")
    
    def find_book(self, isbn):
        """Find book by ISBN"""
        for book in self.books:
            if book.isbn == isbn:
                return book
        return None
    
    def checkout_book(self, isbn):
        """Checkout a book"""
        book = self.find_book(isbn)
        if book:
            if book.available:
                book.available = False
                print(f"Checked out: {book.title}")
                return True
            else:
                print(f"{book.title} is already checked out")
                return False
        else:
            print("Book not found")
            return False
    
    def return_book(self, isbn):
        """Return a book"""
        book = self.find_book(isbn)
        if book:
            if not book.available:
                book.available = True
                print(f"Returned: {book.title}")
                return True
            else:
                print(f"{book.title} is already available")
                return False
        else:
            print("Book not found")
            return False
    
    def list_available_books(self):
        """List all available books"""
        available = [book for book in self.books if book.available]
        if available:
            print(f"\nAvailable books in {self.name}:")
            for book in available:
                print(f"  - {book}")
        else:
            print("No books available")
    
    def list_all_books(self):
        """List all books"""
        print(f"\nAll books in {self.name}:")
        for book in self.books:
            print(f"  - {book}")

# Test the library system
if __name__ == "__main__":
    # Create library
    lib = Library("City Central Library")
    
    # Add books
    lib.add_book(Book("Python Programming", "John Doe", "001"))
    lib.add_book(Book("Data Science Basics", "Jane Smith", "002"))
    lib.add_book(Book("Web Development", "Bob Johnson", "003"))
    
    # List all books
    lib.list_all_books()
    
    # Checkout a book
    print("\n--- Checkout Operations ---")
    lib.checkout_book("001")
    lib.checkout_book("001")  # Try checking out again
    
    # List available books
    lib.list_available_books()
    
    # Return book
    print("\n--- Return Operations ---")
    lib.return_book("001")
    
    # List available books again
    lib.list_available_books()
