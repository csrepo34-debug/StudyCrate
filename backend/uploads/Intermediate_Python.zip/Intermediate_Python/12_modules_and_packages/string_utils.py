# String Utilities Module
"""
Utility functions for string manipulation
"""

def reverse_string(text):
    """Reverse a string"""
    return text[::-1]

def count_words(text):
    """Count words in text"""
    return len(text.split())

def count_vowels(text):
    """Count vowels in text"""
    vowels = 'aeiouAEIOU'
    return sum(1 for char in text if char in vowels)

def capitalize_words(text):
    """Capitalize first letter of each word"""
    return ' '.join(word.capitalize() for word in text.split())

def remove_spaces(text):
    """Remove all spaces from text"""
    return text.replace(' ', '')

def is_palindrome(text):
    """Check if text is palindrome"""
    cleaned = ''.join(char.lower() for char in text if char.isalnum())
    return cleaned == cleaned[::-1]

# Test when run directly
if __name__ == "__main__":
    test_text = "Hello World"
    print(f"Original: {test_text}")
    print(f"Reversed: {reverse_string(test_text)}")
    print(f"Word count: {count_words(test_text)}")
    print(f"Vowel count: {count_vowels(test_text)}")
    print(f"Capitalized: {capitalize_words(test_text)}")
    print(f"No spaces: {remove_spaces(test_text)}")
    print(f"Is 'racecar' palindrome: {is_palindrome('racecar')}")
