# Practice: Create a contact management module and use it

# Contact Management Module
class Contact:
    """Contact class to store contact information"""
    
    def __init__(self, name, phone, email):
        self.name = name
        self.phone = phone
        self.email = email
    
    def __str__(self):
        return f"{self.name} | Phone: {self.phone} | Email: {self.email}"

class ContactManager:
    """Manage a list of contacts"""
    
    def __init__(self):
        self.contacts = []
    
    def add_contact(self, contact):
        """Add a new contact"""
        self.contacts.append(contact)
        print(f"Contact added: {contact.name}")
    
    def remove_contact(self, name):
        """Remove contact by name"""
        for contact in self.contacts:
            if contact.name.lower() == name.lower():
                self.contacts.remove(contact)
                print(f"Contact removed: {name}")
                return True
        print(f"Contact not found: {name}")
        return False
    
    def search_contact(self, name):
        """Search for contact by name"""
        results = [c for c in self.contacts if name.lower() in c.name.lower()]
        return results
    
    def list_all_contacts(self):
        """List all contacts"""
        if self.contacts:
            print("\nAll Contacts:")
            for i, contact in enumerate(self.contacts, 1):
                print(f"{i}. {contact}")
        else:
            print("No contacts found")
    
    def update_contact(self, name, phone=None, email=None):
        """Update contact information"""
        for contact in self.contacts:
            if contact.name.lower() == name.lower():
                if phone:
                    contact.phone = phone
                if email:
                    contact.email = email
                print(f"Contact updated: {name}")
                return True
        print(f"Contact not found: {name}")
        return False
    
    def count_contacts(self):
        """Return total number of contacts"""
        return len(self.contacts)

# Using the Contact Management System
if __name__ == "__main__":
    print("=== Contact Management System ===\n")
    
    # Create manager
    manager = ContactManager()
    
    # Add contacts
    print("--- Adding Contacts ---")
    manager.add_contact(Contact("Alice Johnson", "555-0101", "alice@email.com"))
    manager.add_contact(Contact("Bob Smith", "555-0102", "bob@email.com"))
    manager.add_contact(Contact("Charlie Brown", "555-0103", "charlie@email.com"))
    manager.add_contact(Contact("David Wilson", "555-0104", "david@email.com"))
    
    # List all contacts
    manager.list_all_contacts()
    
    # Search for contact
    print("\n--- Searching Contacts ---")
    results = manager.search_contact("Smith")
    if results:
        print("Search results for 'Smith':")
        for contact in results:
            print(f"  {contact}")
    
    # Update contact
    print("\n--- Updating Contact ---")
    manager.update_contact("Alice Johnson", phone="555-9999")
    
    # List all contacts again
    manager.list_all_contacts()
    
    # Remove contact
    print("\n--- Removing Contact ---")
    manager.remove_contact("Charlie Brown")
    
    # Final list
    manager.list_all_contacts()
    
    # Contact count
    print(f"\nTotal contacts: {manager.count_contacts()}")
