# Inheritance Examples

print("=== Inheritance ===\n")

# Example 1: Basic Inheritance
class Animal:
    """Base class for all animals"""
    
    def __init__(self, name, species):
        self.name = name
        self.species = species
    
    def make_sound(self):
        return "Some generic sound"
    
    def info(self):
        return f"{self.name} is a {self.species}"

class Dog(Animal):
    """Dog class inherits from Animal"""
    
    def __init__(self, name, breed):
        super().__init__(name, "Dog")
        self.breed = breed
    
    def make_sound(self):
        return f"{self.name} barks: Woof!"
    
    def fetch(self):
        return f"{self.name} is fetching the ball"

class Cat(Animal):
    """Cat class inherits from Animal"""
    
    def __init__(self, name, color):
        super().__init__(name, "Cat")
        self.color = color
    
    def make_sound(self):
        return f"{self.name} meows: Meow!"
    
    def scratch(self):
        return f"{self.name} is scratching"

# Create objects
dog = Dog("Buddy", "Golden Retriever")
cat = Cat("Whiskers", "Orange")

print(dog.info())
print(dog.make_sound())
print(dog.fetch())

print("\n" + cat.info())
print(cat.make_sound())
print(cat.scratch())

# Example 2: Employee Inheritance
class Employee:
    """Base employee class"""
    
    def __init__(self, name, employee_id, salary):
        self.name = name
        self.employee_id = employee_id
        self.salary = salary
    
    def get_details(self):
        return f"Employee: {self.name} (ID: {self.employee_id}), Salary: ${self.salary}"
    
    def give_raise(self, amount):
        self.salary += amount
        print(f"{self.name} received a raise of ${amount}")

class Manager(Employee):
    """Manager class with additional attributes"""
    
    def __init__(self, name, employee_id, salary, department):
        super().__init__(name, employee_id, salary)
        self.department = department
        self.team = []
    
    def add_team_member(self, employee):
        self.team.append(employee)
        print(f"{employee.name} added to {self.name}'s team")
    
    def get_details(self):
        base_details = super().get_details()
        return f"{base_details}, Department: {self.department}, Team Size: {len(self.team)}"

class Developer(Employee):
    """Developer class with programming languages"""
    
    def __init__(self, name, employee_id, salary, languages):
        super().__init__(name, employee_id, salary)
        self.languages = languages
    
    def get_details(self):
        base_details = super().get_details()
        langs = ', '.join(self.languages)
        return f"{base_details}, Languages: {langs}"

# Create employee objects
manager = Manager("Alice Johnson", "M001", 90000, "Engineering")
dev1 = Developer("Bob Smith", "D001", 75000, ["Python", "JavaScript"])
dev2 = Developer("Charlie Brown", "D002", 70000, ["Java", "C++"])

print("\n--- Company Structure ---")
print(manager.get_details())
print(dev1.get_details())
print(dev2.get_details())

print("\n--- Team Building ---")
manager.add_team_member(dev1)
manager.add_team_member(dev2)
print("\n" + manager.get_details())
