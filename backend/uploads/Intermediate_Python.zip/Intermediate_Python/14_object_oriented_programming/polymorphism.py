# Polymorphism Examples

print("=== Polymorphism ===\n")

# Example 1: Method Overriding
class Shape:
    """Base shape class"""
    
    def __init__(self, name):
        self.name = name
    
    def area(self):
        return 0
    
    def perimeter(self):
        return 0
    
    def display(self):
        print(f"{self.name}: Area = {self.area()}, Perimeter = {self.perimeter()}")

class Rectangle(Shape):
    """Rectangle class"""
    
    def __init__(self, width, height):
        super().__init__("Rectangle")
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height
    
    def perimeter(self):
        return 2 * (self.width + self.height)

class Circle(Shape):
    """Circle class"""
    
    def __init__(self, radius):
        super().__init__("Circle")
        self.radius = radius
        self.pi = 3.14159
    
    def area(self):
        return self.pi * self.radius ** 2
    
    def perimeter(self):
        return 2 * self.pi * self.radius

class Triangle(Shape):
    """Triangle class"""
    
    def __init__(self, a, b, c):
        super().__init__("Triangle")
        self.a = a
        self.b = b
        self.c = c
    
    def area(self):
        # Using Heron's formula
        s = (self.a + self.b + self.c) / 2
        return (s * (s - self.a) * (s - self.b) * (s - self.c)) ** 0.5
    
    def perimeter(self):
        return self.a + self.b + self.c

# Polymorphism in action
shapes = [
    Rectangle(5, 10),
    Circle(7),
    Triangle(3, 4, 5)
]

print("--- All Shapes ---")
for shape in shapes:
    shape.display()

# Example 2: Duck Typing (Polymorphism)
class Dog:
    def speak(self):
        return "Woof!"

class Cat:
    def speak(self):
        return "Meow!"

class Duck:
    def speak(self):
        return "Quack!"

class Cow:
    def speak(self):
        return "Moo!"

def animal_sound(animal):
    """This works with any object that has a speak() method"""
    print(animal.speak())

print("\n--- Duck Typing ---")
animals = [Dog(), Cat(), Duck(), Cow()]

for animal in animals:
    animal_sound(animal)

# Example 3: Operator Overloading (Magic Methods)
class Vector:
    """2D Vector class with operator overloading"""
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __str__(self):
        """String representation"""
        return f"Vector({self.x}, {self.y})"
    
    def __add__(self, other):
        """Addition operator"""
        return Vector(self.x + other.x, self.y + other.y)
    
    def __sub__(self, other):
        """Subtraction operator"""
        return Vector(self.x - other.x, self.y - other.y)
    
    def __mul__(self, scalar):
        """Multiplication by scalar"""
        return Vector(self.x * scalar, self.y * scalar)
    
    def __eq__(self, other):
        """Equality operator"""
        return self.x == other.x and self.y == other.y
    
    def __len__(self):
        """Length (magnitude) of vector"""
        return int((self.x**2 + self.y**2)**0.5)

# Test vector operations
print("\n--- Operator Overloading ---")
v1 = Vector(3, 4)
v2 = Vector(1, 2)

print(f"v1 = {v1}")
print(f"v2 = {v2}")
print(f"v1 + v2 = {v1 + v2}")
print(f"v1 - v2 = {v1 - v2}")
print(f"v1 * 3 = {v1 * 3}")
print(f"v1 == v2: {v1 == v2}")
print(f"len(v1) = {len(v1)}")

# Example 4: Polymorphic Behavior with Payment Methods
class PaymentMethod:
    """Base class for payment methods"""
    
    def process_payment(self, amount):
        pass

class CreditCard(PaymentMethod):
    def __init__(self, card_number):
        self.card_number = card_number
    
    def process_payment(self, amount):
        return f"Processing ${amount} via Credit Card ending in {self.card_number[-4:]}"

class PayPal(PaymentMethod):
    def __init__(self, email):
        self.email = email
    
    def process_payment(self, amount):
        return f"Processing ${amount} via PayPal ({self.email})"

class Bitcoin(PaymentMethod):
    def __init__(self, wallet_address):
        self.wallet_address = wallet_address
    
    def process_payment(self, amount):
        return f"Processing ${amount} via Bitcoin to {self.wallet_address[:8]}..."

def checkout(payment_method, amount):
    """Process payment regardless of payment type"""
    print(payment_method.process_payment(amount))

print("\n--- Payment Processing ---")
payment_methods = [
    CreditCard("1234567890123456"),
    PayPal("user@email.com"),
    Bitcoin("1A2B3C4D5E6F7G8H9I")
]

for method in payment_methods:
    checkout(method, 99.99)
