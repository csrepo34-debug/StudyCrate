# Practice: E-commerce System using OOP

class Product:
    """Product class"""
    
    def __init__(self, product_id, name, price, stock):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.stock = stock
    
    def update_stock(self, quantity):
        """Update stock quantity"""
        self.stock += quantity
    
    def is_available(self, quantity=1):
        """Check if product is available"""
        return self.stock >= quantity
    
    def __str__(self):
        return f"{self.name} (ID: {self.product_id}) - ${self.price} [{self.stock} in stock]"

class ElectronicsProduct(Product):
    """Electronics with warranty"""
    
    def __init__(self, product_id, name, price, stock, warranty_months):
        super().__init__(product_id, name, price, stock)
        self.warranty_months = warranty_months
    
    def __str__(self):
        base_str = super().__str__()
        return f"{base_str} [Warranty: {self.warranty_months} months]"

class ClothingProduct(Product):
    """Clothing with size"""
    
    def __init__(self, product_id, name, price, stock, size):
        super().__init__(product_id, name, price, stock)
        self.size = size
    
    def __str__(self):
        base_str = super().__str__()
        return f"{base_str} [Size: {self.size}]"

class ShoppingCart:
    """Shopping cart to hold products"""
    
    def __init__(self):
        self.items = {}  # {product_id: (product, quantity)}
    
    def add_item(self, product, quantity=1):
        """Add product to cart"""
        if product.is_available(quantity):
            if product.product_id in self.items:
                current_qty = self.items[product.product_id][1]
                self.items[product.product_id] = (product, current_qty + quantity)
            else:
                self.items[product.product_id] = (product, quantity)
            print(f"Added {quantity} x {product.name} to cart")
            return True
        else:
            print(f"Sorry, only {product.stock} of {product.name} available")
            return False
    
    def remove_item(self, product_id):
        """Remove product from cart"""
        if product_id in self.items:
            product = self.items[product_id][0]
            del self.items[product_id]
            print(f"Removed {product.name} from cart")
            return True
        else:
            print("Product not in cart")
            return False
    
    def update_quantity(self, product_id, quantity):
        """Update quantity of product in cart"""
        if product_id in self.items:
            product = self.items[product_id][0]
            if product.is_available(quantity):
                self.items[product_id] = (product, quantity)
                print(f"Updated {product.name} quantity to {quantity}")
                return True
            else:
                print(f"Only {product.stock} available")
                return False
        else:
            print("Product not in cart")
            return False
    
    def get_total(self):
        """Calculate total price"""
        total = sum(product.price * qty for product, qty in self.items.values())
        return total
    
    def display(self):
        """Display cart contents"""
        if self.items:
            print("\n=== Shopping Cart ===")
            for product, qty in self.items.values():
                subtotal = product.price * qty
                print(f"{product.name} x {qty} = ${subtotal:.2f}")
            print(f"\nTotal: ${self.get_total():.2f}")
        else:
            print("Cart is empty")

class Customer:
    """Customer class"""
    
    def __init__(self, customer_id, name, email):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.cart = ShoppingCart()
        self.orders = []
    
    def place_order(self):
        """Place an order"""
        if not self.cart.items:
            print("Cart is empty")
            return None
        
        # Create order
        order = Order(len(self.orders) + 1, self)
        
        # Process each item
        for product, qty in self.cart.items.values():
            if product.is_available(qty):
                product.update_stock(-qty)
                order.add_item(product, qty)
            else:
                print(f"Insufficient stock for {product.name}")
                return None
        
        # Clear cart and save order
        self.cart = ShoppingCart()
        self.orders.append(order)
        
        print(f"\nOrder placed successfully! Order ID: {order.order_id}")
        return order

class Order:
    """Order class"""
    
    def __init__(self, order_id, customer):
        self.order_id = order_id
        self.customer = customer
        self.items = []
        self.status = "Processing"
    
    def add_item(self, product, quantity):
        """Add item to order"""
        self.items.append((product, quantity))
    
    def get_total(self):
        """Calculate order total"""
        return sum(product.price * qty for product, qty in self.items)
    
    def display(self):
        """Display order details"""
        print(f"\n=== Order #{self.order_id} ===")
        print(f"Customer: {self.customer.name}")
        print(f"Status: {self.status}")
        print("\nItems:")
        for product, qty in self.items:
            print(f"  {product.name} x {qty} = ${product.price * qty:.2f}")
        print(f"\nTotal: ${self.get_total():.2f}")

# Demo the e-commerce system
print("=== E-Commerce System Demo ===\n")

# Create products
laptop = ElectronicsProduct("E001", "Laptop", 1200.00, 10, 24)
mouse = ElectronicsProduct("E002", "Wireless Mouse", 25.00, 50, 12)
tshirt = ClothingProduct("C001", "Cotton T-Shirt", 20.00, 100, "M")
jeans = ClothingProduct("C002", "Blue Jeans", 50.00, 30, "L")

print("--- Available Products ---")
print(laptop)
print(mouse)
print(tshirt)
print(jeans)

# Create customer
customer = Customer("CUST001", "John Doe", "john@email.com")

# Add items to cart
print("\n--- Adding to Cart ---")
customer.cart.add_item(laptop, 1)
customer.cart.add_item(mouse, 2)
customer.cart.add_item(tshirt, 3)

# Display cart
customer.cart.display()

# Update quantity
print("\n--- Updating Cart ---")
customer.cart.update_quantity("E002", 1)
customer.cart.display()

# Place order
print("\n--- Placing Order ---")
order = customer.place_order()

if order:
    order.display()
    
    # Check updated stock
    print("\n--- Updated Stock ---")
    print(laptop)
    print(mouse)
    print(tshirt)
