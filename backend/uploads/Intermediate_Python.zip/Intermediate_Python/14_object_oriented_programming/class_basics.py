# Basic Classes and Objects

print("=== Classes and Objects ===\n")

# Example 1: Simple class
class Dog:
    """A simple Dog class"""
    
    def __init__(self, name, breed, age):
        self.name = name
        self.breed = breed
        self.age = age
    
    def bark(self):
        return f"{self.name} says Woof!"
    
    def get_info(self):
        return f"{self.name} is a {self.age}-year-old {self.breed}"

# Create objects
dog1 = Dog("Buddy", "Golden Retriever", 3)
dog2 = Dog("Max", "German Shepherd", 5)

print(dog1.get_info())
print(dog1.bark())
print()
print(dog2.get_info())
print(dog2.bark())

# Example 2: Person class
class Person:
    """Person class with attributes and methods"""
    
    def __init__(self, name, age, city):
        self.name = name
        self.age = age
        self.city = city
    
    def introduce(self):
        return f"Hi, I'm {self.name}, {self.age} years old, from {self.city}"
    
    def have_birthday(self):
        self.age += 1
        return f"Happy Birthday {self.name}! You are now {self.age}"

# Create and use Person objects
person1 = Person("Alice", 25, "New York")
person2 = Person("Bob", 30, "London")

print("\n" + person1.introduce())
print(person2.introduce())
print("\n" + person1.have_birthday())
print(person1.introduce())

# Example 3: Book class
class Book:
    """Book class with multiple attributes"""
    
    def __init__(self, title, author, pages, price):
        self.title = title
        self.author = author
        self.pages = pages
        self.price = price
        self.is_read = False
    
    def mark_as_read(self):
        self.is_read = True
        print(f"'{self.title}' marked as read")
    
    def get_details(self):
        status = "Read" if self.is_read else "Unread"
        return f"'{self.title}' by {self.author} - {self.pages} pages, ${self.price} [{status}]"

# Create books
book1 = Book("Python Programming", "John Doe", 450, 39.99)
book2 = Book("Data Science", "Jane Smith", 520, 49.99)

print("\n" + book1.get_details())
book1.mark_as_read()
print(book1.get_details())
print("\n" + book2.get_details())
