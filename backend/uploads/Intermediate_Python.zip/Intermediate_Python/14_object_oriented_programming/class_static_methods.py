# Class Methods, Static Methods, and Magic Methods

print("=== Class Methods and Static Methods ===\n")

# Example 1: Class methods and class variables
class Employee:
    """Employee class with class methods"""
    
    company_name = "TechCorp"
    employee_count = 0
    raise_percentage = 1.04  # 4% raise
    
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        Employee.employee_count += 1
    
    def apply_raise(self):
        """Instance method"""
        self.salary = int(self.salary * self.raise_percentage)
    
    @classmethod
    def set_raise_percentage(cls, percentage):
        """Class method to modify class variable"""
        cls.raise_percentage = percentage
    
    @classmethod
    def from_string(cls, emp_string):
        """Alternative constructor"""
        name, salary = emp_string.split('-')
        return cls(name, int(salary))
    
    @staticmethod
    def is_workday(day):
        """Static method - doesn't use instance or class"""
        weekends = ['Saturday', 'Sunday']
        return day not in weekends
    
    def __str__(self):
        return f"{self.name}: ${self.salary}"

# Create employees
emp1 = Employee("Alice", 50000)
emp2 = Employee("Bob", 60000)

print(f"Company: {Employee.company_name}")
print(f"Total employees: {Employee.employee_count}")
print(emp1)
print(emp2)

# Apply raise
print("\n--- After Raise ---")
emp1.apply_raise()
emp2.apply_raise()
print(emp1)
print(emp2)

# Use class method
print("\n--- Change Raise Percentage ---")
Employee.set_raise_percentage(1.05)  # 5% raise
emp1.apply_raise()
print(f"{emp1.name} after second raise: ${emp1.salary}")

# Alternative constructor
print("\n--- Alternative Constructor ---")
emp3 = Employee.from_string("Charlie-55000")
print(emp3)

# Static method
print("\n--- Static Method ---")
print(f"Is Monday a workday? {Employee.is_workday('Monday')}")
print(f"Is Saturday a workday? {Employee.is_workday('Saturday')}")

# Example 2: Magic Methods
class Book:
    """Book class with magic methods"""
    
    def __init__(self, title, pages):
        self.title = title
        self.pages = pages
    
    def __str__(self):
        """String representation for users"""
        return f"'{self.title}' ({self.pages} pages)"
    
    def __repr__(self):
        """String representation for developers"""
        return f"Book('{self.title}', {self.pages})"
    
    def __len__(self):
        """Length of book (number of pages)"""
        return self.pages
    
    def __eq__(self, other):
        """Check if two books are equal"""
        return self.title == other.title and self.pages == other.pages
    
    def __lt__(self, other):
        """Less than comparison (by pages)"""
        return self.pages < other.pages
    
    def __add__(self, other):
        """Combine two books"""
        combined_title = f"{self.title} & {other.title}"
        combined_pages = self.pages + other.pages
        return Book(combined_title, combined_pages)

# Test magic methods
print("\n--- Magic Methods ---")
book1 = Book("Python Basics", 300)
book2 = Book("Advanced Python", 450)
book3 = Book("Python Basics", 300)

print(f"book1: {book1}")
print(f"repr(book1): {repr(book1)}")
print(f"len(book1): {len(book1)}")
print(f"book1 == book2: {book1 == book2}")
print(f"book1 == book3: {book1 == book3}")
print(f"book1 < book2: {book1 < book2}")

combined = book1 + book2
print(f"Combined book: {combined}")

# Example 3: Context Manager
class FileManager:
    """Custom context manager for file handling"""
    
    def __init__(self, filename, mode):
        self.filename = filename
        self.mode = mode
        self.file = None
    
    def __enter__(self):
        """Called when entering 'with' block"""
        print(f"Opening file: {self.filename}")
        self.file = open(self.filename, self.mode)
        return self.file
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Called when exiting 'with' block"""
        print(f"Closing file: {self.filename}")
        if self.file:
            self.file.close()
        return False

# Use context manager
print("\n--- Context Manager ---")
with FileManager("test.txt", "w") as f:
    f.write("Hello from context manager!\n")
    f.write("This file will be automatically closed.")

print("File operations completed")
