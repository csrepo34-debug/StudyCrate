# Practice: Library Management System using OOP

from datetime import datetime, timedelta

class Book:
    """Book class"""
    
    def __init__(self, isbn, title, author, total_copies):
        self.isbn = isbn
        self.title = title
        self.author = author
        self.total_copies = total_copies
        self.available_copies = total_copies
    
    def is_available(self):
        return self.available_copies > 0
    
    def borrow(self):
        if self.is_available():
            self.available_copies -= 1
            return True
        return False
    
    def return_book(self):
        if self.available_copies < self.total_copies:
            self.available_copies += 1
            return True
        return False
    
    def __str__(self):
        return f"'{self.title}' by {self.author} (ISBN: {self.isbn}) [{self.available_copies}/{self.total_copies} available]"

class Member:
    """Library member class"""
    
    MAX_BOOKS = 3
    
    def __init__(self, member_id, name, email):
        self.member_id = member_id
        self.name = name
        self.email = email
        self.borrowed_books = []
        self.borrowing_history = []
    
    def can_borrow(self):
        return len(self.borrowed_books) < self.MAX_BOOKS
    
    def borrow_book(self, book):
        if self.can_borrow():
            self.borrowed_books.append(book)
            return True
        return False
    
    def return_book(self, book):
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
            return True
        return False
    
    def __str__(self):
        return f"Member: {self.name} (ID: {self.member_id}) - Books borrowed: {len(self.borrowed_books)}"

class BorrowRecord:
    """Record of book borrowing"""
    
    def __init__(self, member, book, due_days=14):
        self.member = member
        self.book = book
        self.borrow_date = datetime.now()
        self.due_date = self.borrow_date + timedelta(days=due_days)
        self.return_date = None
        self.is_returned = False
    
    def return_record(self):
        self.return_date = datetime.now()
        self.is_returned = True
    
    def is_overdue(self):
        if not self.is_returned and datetime.now() > self.due_date:
            return True
        return False
    
    def days_overdue(self):
        if self.is_overdue():
            return (datetime.now() - self.due_date).days
        return 0
    
    def __str__(self):
        status = "Returned" if self.is_returned else "Active"
        if self.is_overdue():
            status = f"OVERDUE ({self.days_overdue()} days)"
        return f"{self.member.name} - '{self.book.title}' [{status}]"

class Library:
    """Library management system"""
    
    def __init__(self, name):
        self.name = name
        self.books = {}  # {isbn: Book}
        self.members = {}  # {member_id: Member}
        self.borrow_records = []
    
    def add_book(self, book):
        """Add book to library"""
        if book.isbn in self.books:
            # Update copies if book exists
            self.books[book.isbn].total_copies += book.total_copies
            self.books[book.isbn].available_copies += book.available_copies
            print(f"Updated copies for '{book.title}'")
        else:
            self.books[book.isbn] = book
            print(f"Added '{book.title}' to library")
    
    def add_member(self, member):
        """Add member to library"""
        self.members[member.member_id] = member
        print(f"Registered member: {member.name}")
    
    def borrow_book(self, member_id, isbn):
        """Process book borrowing"""
        if member_id not in self.members:
            print("Member not found")
            return False
        
        if isbn not in self.books:
            print("Book not found")
            return False
        
        member = self.members[member_id]
        book = self.books[isbn]
        
        if not member.can_borrow():
            print(f"{member.name} has reached borrowing limit")
            return False
        
        if not book.is_available():
            print(f"'{book.title}' is not available")
            return False
        
        # Process borrowing
        book.borrow()
        member.borrow_book(book)
        record = BorrowRecord(member, book)
        self.borrow_records.append(record)
        
        print(f"{member.name} borrowed '{book.title}'")
        print(f"Due date: {record.due_date.strftime('%Y-%m-%d')}")
        return True
    
    def return_book(self, member_id, isbn):
        """Process book return"""
        if member_id not in self.members:
            print("Member not found")
            return False
        
        if isbn not in self.books:
            print("Book not found")
            return False
        
        member = self.members[member_id]
        book = self.books[isbn]
        
        if book not in member.borrowed_books:
            print(f"{member.name} hasn't borrowed '{book.title}'")
            return False
        
        # Find active record
        for record in self.borrow_records:
            if record.member == member and record.book == book and not record.is_returned:
                record.return_record()
                
                if record.is_overdue():
                    print(f"Book returned late by {record.days_overdue()} days")
                
                break
        
        # Process return
        book.return_book()
        member.return_book(book)
        
        print(f"{member.name} returned '{book.title}'")
        return True
    
    def list_available_books(self):
        """List all available books"""
        print(f"\n=== Available Books in {self.name} ===")
        available = [book for book in self.books.values() if book.is_available()]
        if available:
            for book in available:
                print(f"  {book}")
        else:
            print("  No books available")
    
    def list_overdue_books(self):
        """List all overdue books"""
        print(f"\n=== Overdue Books ===")
        overdue = [record for record in self.borrow_records if record.is_overdue()]
        if overdue:
            for record in overdue:
                print(f"  {record}")
        else:
            print("  No overdue books")

# Demo the library system
print("=== Library Management System ===\n")

# Create library
library = Library("City Central Library")

# Add books
library.add_book(Book("001", "Python Programming", "John Doe", 3))
library.add_book(Book("002", "Data Science Basics", "Jane Smith", 2))
library.add_book(Book("003", "Web Development", "Bob Johnson", 4))

# Add members
library.add_member(Member("M001", "Alice", "alice@email.com"))
library.add_member(Member("M002", "Bob", "bob@email.com"))

# List available books
library.list_available_books()

# Borrow books
print("\n--- Borrowing Books ---")
library.borrow_book("M001", "001")
library.borrow_book("M001", "002")
library.borrow_book("M002", "003")

# List available books again
library.list_available_books()

# Try borrowing unavailable book
print("\n--- Attempting to Borrow More ---")
library.borrow_book("M002", "002")

# Return a book
print("\n--- Returning Books ---")
library.return_book("M001", "001")

# List available books
library.list_available_books()

# Check overdue books
library.list_overdue_books()
