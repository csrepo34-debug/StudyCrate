# Set Comprehension Examples

# Basic set comprehension
numbers = [1, 2, 3, 4, 5]
squares_set = {x**2 for x in numbers}
print("Squares set:", squares_set)

# Remove duplicates with comprehension
numbers_with_duplicates = [1, 2, 2, 3, 3, 3, 4, 5, 5]
unique = {x for x in numbers_with_duplicates}
print("Unique numbers:", unique)

# With condition
even_numbers = {x for x in range(1, 21) if x % 2 == 0}
print("Even numbers:", even_numbers)

# String operations
words = ['hello', 'world', 'hello', 'python', 'world']
unique_uppercase = {word.upper() for word in words}
print("Unique uppercase words:", unique_uppercase)

# First letters
words = ['apple', 'banana', 'cherry', 'avocado', 'blueberry']
first_letters = {word[0] for word in words}
print("First letters:", first_letters)

# Vowels in text
text = "Hello World"
vowels = {char.lower() for char in text if char.lower() in 'aeiou'}
print("Vowels found:", vowels)
