# Practice: Process sales data using comprehensions and generators

sales_data = [
    {'product': 'Laptop', 'price': 1200, 'quantity': 5, 'category': 'Electronics'},
    {'product': 'Mouse', 'price': 25, 'quantity': 50, 'category': 'Electronics'},
    {'product': 'Desk', 'price': 300, 'quantity': 10, 'category': 'Furniture'},
    {'product': 'Chair', 'price': 150, 'quantity': 20, 'category': 'Furniture'},
    {'product': 'Monitor', 'price': 400, 'quantity': 8, 'category': 'Electronics'},
]

# Calculate total value for each product
product_values = {item['product']: item['price'] * item['quantity'] 
                  for item in sales_data}
print("Product Values:")
for product, value in product_values.items():
    print(f"{product}: ${value}")

# Find products with value > $5000
high_value_products = {item['product']: item['price'] * item['quantity']
                       for item in sales_data
                       if item['price'] * item['quantity'] > 5000}
print("\nHigh Value Products (>$5000):")
for product, value in high_value_products.items():
    print(f"{product}: ${value}")

# Group products by category
categories = {item['category'] for item in sales_data}
products_by_category = {category: [item['product'] for item in sales_data 
                                   if item['category'] == category]
                        for category in categories}
print("\nProducts by Category:")
for category, products in products_by_category.items():
    print(f"{category}: {products}")

# Calculate total value per category
category_values = {category: sum(item['price'] * item['quantity'] 
                                 for item in sales_data 
                                 if item['category'] == category)
                   for category in categories}
print("\nTotal Value by Category:")
for category, value in category_values.items():
    print(f"{category}: ${value}")

# Generator for processing large inventory
def inventory_generator(data):
    """Generate formatted inventory reports"""
    for item in data:
        total_value = item['price'] * item['quantity']
        yield f"{item['product']}: ${item['price']} x {item['quantity']} = ${total_value}"

print("\nInventory Report:")
for report in inventory_generator(sales_data):
    print(report)

# Calculate overall statistics
total_revenue = sum(item['price'] * item['quantity'] for item in sales_data)
total_items = sum(item['quantity'] for item in sales_data)
average_price = sum(item['price'] for item in sales_data) / len(sales_data)

print(f"\nTotal Revenue: ${total_revenue}")
print(f"Total Items: {total_items}")
print(f"Average Price: ${average_price:.2f}")
