# Dictionary Comprehension Examples

# Basic dictionary comprehension
numbers = [1, 2, 3, 4, 5]
squares_dict = {x: x**2 for x in numbers}
print("Squares dictionary:", squares_dict)

# From two lists
keys = ['a', 'b', 'c']
values = [1, 2, 3]
combined = {k: v for k, v in zip(keys, values)}
print("Combined:", combined)

# With condition
even_squares = {x: x**2 for x in range(1, 11) if x % 2 == 0}
print("Even squares:", even_squares)

# Swap keys and values
original = {'a': 1, 'b': 2, 'c': 3}
swapped = {v: k for k, v in original.items()}
print("Swapped:", swapped)

# Convert to uppercase keys
data = {'name': 'Alice', 'age': 25, 'city': 'NYC'}
uppercase_keys = {k.upper(): v for k, v in data.items()}
print("Uppercase keys:", uppercase_keys)

# Filter dictionary
scores = {'Alice': 85, 'Bob': 60, 'Charlie': 75, 'David': 90}
passed = {k: v for k, v in scores.items() if v >= 70}
print("Passed students:", passed)
