# Practice: Read from File
# Reading and processing data from files

import os


def read_entire_file(filename):
    """Read entire file content"""
    try:
        with open(filename, "r") as file:
            content = file.read()
            return content
    except FileNotFoundError:
        return f"Error: File '{filename}' not found"
    except Exception as e:
        return f"Error: {e}"


def read_file_lines(filename):
    """Read file line by line"""
    try:
        with open(filename, "r") as file:
            lines = file.readlines()
            return lines
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"Error: {e}")
        return []


def count_file_lines(filename):
    """Count total lines in file"""
    try:
        with open(filename, "r") as file:
            lines = file.readlines()
            return len(lines)
    except FileNotFoundError:
        return 0
    except Exception as e:
        print(f"Error: {e}")
        return 0


def count_words_in_file(filename):
    """Count total words in file"""
    try:
        with open(filename, "r") as file:
            content = file.read()
            words = content.split()
            return len(words)
    except FileNotFoundError:
        return 0
    except Exception as e:
        print(f"Error: {e}")
        return 0


def search_in_file(filename, search_term):
    """Search for a term in file"""
    try:
        found_lines = []
        with open(filename, "r") as file:
            for line_num, line in enumerate(file, 1):
                if search_term.lower() in line.lower():
                    found_lines.append((line_num, line.strip()))
        return found_lines
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"Error: {e}")
        return []


def read_csv_file(filename):
    """Read and parse CSV file"""
    try:
        data = []
        with open(filename, "r") as file:
            lines = file.readlines()
            if lines:
                headers = lines[0].strip().split(',')
                for line in lines[1:]:
                    values = line.strip().split(',')
                    row_dict = dict(zip(headers, values))
                    data.append(row_dict)
        return data
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"Error: {e}")
        return []


# Create sample files for demonstration
def create_sample_files():
    """Create sample files for practice"""
    # Create text file
    with open("story.txt", "w") as file:
        file.write("Once upon a time in a land far away,\n")
        file.write("There lived a Python programmer named Ray.\n")
        file.write("He loved to code day and night,\n")
        file.write("Making programs that worked just right.\n")
        file.write("Python was his favorite tool,\n")
        file.write("Learning it made him feel so cool.\n")
    
    # Create CSV file
    with open("students.csv", "w") as file:
        file.write("Name,Age,Grade,City\n")
        file.write("Alice,20,A,New York\n")
        file.write("Bob,21,B,Los Angeles\n")
        file.write("Charlie,19,A,Chicago\n")
        file.write("Diana,22,B,Houston\n")
    
    # Create numbers file
    with open("numbers.txt", "w") as file:
        for i in range(1, 11):
            file.write(f"{i}\n")


# Main program
print("FILE READING PRACTICE")
print("=" * 50)

# Create sample files
create_sample_files()
print("Sample files created: story.txt, students.csv, numbers.txt")

print("\n" + "=" * 50)

# Example 1: Read entire file
print("\n1. Reading entire file:")
print("-" * 50)
content = read_entire_file("story.txt")
print(content)

print("=" * 50)

# Example 2: Read line by line
print("\n2. Reading line by line:")
print("-" * 50)
lines = read_file_lines("story.txt")
for i, line in enumerate(lines, 1):
    print(f"Line {i}: {line.strip()}")

print("\n" + "=" * 50)

# Example 3: Count lines and words
print("\n3. File statistics:")
print("-" * 50)
total_lines = count_file_lines("story.txt")
total_words = count_words_in_file("story.txt")
print(f"Total lines: {total_lines}")
print(f"Total words: {total_words}")

print("\n" + "=" * 50)

# Example 4: Search in file
print("\n4. Search in file:")
print("-" * 50)
search_term = "Python"
results = search_in_file("story.txt", search_term)
print(f"Searching for '{search_term}':")
if results:
    for line_num, line in results:
        print(f"Line {line_num}: {line}")
else:
    print("No matches found")

print("\n" + "=" * 50)

# Example 5: Read CSV file
print("\n5. Reading CSV file:")
print("-" * 50)
students = read_csv_file("students.csv")
print(f"{'Name':<15} {'Age':<5} {'Grade':<8} {'City':<15}")
print("-" * 45)
for student in students:
    print(f"{student['Name']:<15} {student['Age']:<5} {student['Grade']:<8} {student['City']:<15}")

print("\n" + "=" * 50)

# Example 6: Read and process numbers
print("\n6. Reading and processing numbers:")
print("-" * 50)
try:
    numbers = []
    with open("numbers.txt", "r") as file:
        for line in file:
            numbers.append(int(line.strip()))
    
    print(f"Numbers: {numbers}")
    print(f"Sum: {sum(numbers)}")
    print(f"Average: {sum(numbers) / len(numbers):.2f}")
    print(f"Max: {max(numbers)}")
    print(f"Min: {min(numbers)}")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "=" * 50)

# Example 7: Filter data
print("\n7. Filter students by grade:")
print("-" * 50)
grade_filter = "A"
print(f"Students with grade {grade_filter}:")
for student in students:
    if student['Grade'] == grade_filter:
        print(f"  {student['Name']} from {student['City']}")

print("\n" + "=" * 50)

# Interactive file reader
print("\n8. Interactive file reader:")
print("-" * 50)
filename = input("Enter filename to read (or press Enter to skip): ")

if filename:
    if os.path.exists(filename):
        content = read_entire_file(filename)
        print(f"\nContents of '{filename}':")
        print(content)
        
        # Statistics
        lines = count_file_lines(filename)
        words = count_words_in_file(filename)
        print(f"\nStatistics:")
        print(f"Lines: {lines}")
        print(f"Words: {words}")
    else:
        print(f"File '{filename}' not found")

print("\n" + "=" * 50)
print("Practice complete!")
