# File Reading Basics
# Different ways to read files

# First, let's create a sample file to read
with open("sample.txt", "w") as f:
    f.write("Line 1: Hello, World!\n")
    f.write("Line 2: Python file handling\n")
    f.write("Line 3: Reading files is easy\n")
    f.write("Line 4: End of file\n")

print("FILE READING BASICS")
print("=" * 50)

# Method 1: read() - Read entire file
print("\nMethod 1: read() - Read entire file")
print("-" * 50)

with open("sample.txt", "r") as file:
    content = file.read()
    print(content)

print("=" * 50)

# Method 2: readline() - Read one line at a time
print("\nMethod 2: readline() - Read one line")
print("-" * 50)

with open("sample.txt", "r") as file:
    line1 = file.readline()
    line2 = file.readline()
    print("First line:", line1.strip())
    print("Second line:", line2.strip())

print("\n" + "=" * 50)

# Method 3: readlines() - Read all lines into a list
print("\nMethod 3: readlines() - Read all lines into list")
print("-" * 50)

with open("sample.txt", "r") as file:
    lines = file.readlines()
    print(f"Total lines: {len(lines)}")
    for i, line in enumerate(lines, 1):
        print(f"Line {i}: {line.strip()}")

print("\n" + "=" * 50)

# Method 4: Iterate through file
print("\nMethod 4: Iterate through file")
print("-" * 50)

with open("sample.txt", "r") as file:
    for line_num, line in enumerate(file, 1):
        print(f"{line_num}: {line.strip()}")

print("\n" + "=" * 50)

# Reading with error handling
print("\nReading with error handling:")
print("-" * 50)

try:
    with open("nonexistent.txt", "r") as file:
        content = file.read()
except FileNotFoundError:
    print("Error: File not found!")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "=" * 50)

# Read specific number of characters
print("\nRead specific number of characters:")
print("-" * 50)

with open("sample.txt", "r") as file:
    first_20 = file.read(20)
    print(f"First 20 characters: '{first_20}'")

print("\n" + "=" * 50)

# Check file status
print("\nFile object properties:")
print("-" * 50)

with open("sample.txt", "r") as file:
    print(f"File name: {file.name}")
    print(f"File mode: {file.mode}")
    print(f"Is closed: {file.closed}")
print(f"After with block, is closed: {file.closed}")

print("\n" + "=" * 50)
print("Sample file 'sample.txt' created for practice")
