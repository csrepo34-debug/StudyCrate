# File Writing Basics
# Different ways to write to files

print("FILE WRITING BASICS")
print("=" * 50)

# Method 1: write() - Write string to file
print("\nMethod 1: write() - Write single string")
print("-" * 50)

with open("output1.txt", "w") as file:
    file.write("Hello, World!\n")
    file.write("This is a test file.\n")
    file.write("Python file handling is easy!\n")

print("File 'output1.txt' created")

# Read and display
with open("output1.txt", "r") as file:
    print("\nContents of output1.txt:")
    print(file.read())

print("=" * 50)

# Method 2: writelines() - Write list of strings
print("\nMethod 2: writelines() - Write list of strings")
print("-" * 50)

lines = [
    "Line 1\n",
    "Line 2\n",
    "Line 3\n"
]

with open("output2.txt", "w") as file:
    file.writelines(lines)

print("File 'output2.txt' created")

with open("output2.txt", "r") as file:
    print("\nContents of output2.txt:")
    print(file.read())

print("=" * 50)

# Method 3: Append mode
print("\nMethod 3: Append mode ('a')")
print("-" * 50)

# Create initial file
with open("log.txt", "w") as file:
    file.write("Log started\n")

# Append to file
with open("log.txt", "a") as file:
    file.write("Entry 1: User logged in\n")
    file.write("Entry 2: File uploaded\n")
    file.write("Entry 3: User logged out\n")

print("File 'log.txt' created and appended")

with open("log.txt", "r") as file:
    print("\nContents of log.txt:")
    print(file.read())

print("=" * 50)

# Method 4: Write mode overwrites
print("\nMethod 4: Write mode overwrites existing file")
print("-" * 50)

with open("temp.txt", "w") as file:
    file.write("Original content\n")

print("Created temp.txt with original content")

# This will overwrite
with open("temp.txt", "w") as file:
    file.write("New content\n")

print("Overwrote temp.txt")

with open("temp.txt", "r") as file:
    print("\nContents of temp.txt after overwrite:")
    print(file.read())

print("=" * 50)

# Method 5: Write multiple data types
print("\nMethod 5: Write different data types")
print("-" * 50)

name = "Alice"
age = 25
marks = [85, 90, 92]

with open("student.txt", "w") as file:
    file.write(f"Name: {name}\n")
    file.write(f"Age: {age}\n")
    file.write(f"Marks: {marks}\n")

print("File 'student.txt' created")

with open("student.txt", "r") as file:
    print("\nContents of student.txt:")
    print(file.read())

print("=" * 50)

# Method 6: Creating formatted output
print("\nMethod 6: Creating formatted output")
print("-" * 50)

products = [
    ("Laptop", 999.99),
    ("Mouse", 29.99),
    ("Keyboard", 79.99)
]

with open("products.txt", "w") as file:
    file.write(f"{'Product':<15} {'Price':>10}\n")
    file.write("-" * 27 + "\n")
    
    for product, price in products:
        file.write(f"{product:<15} ${price:>9.2f}\n")

print("File 'products.txt' created with formatted data")

with open("products.txt", "r") as file:
    print("\nContents of products.txt:")
    print(file.read())

print("=" * 50)
print("\nMultiple files created successfully!")
