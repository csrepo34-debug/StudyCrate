# File Error Handling
# Handling common file operation errors

import os

print("FILE ERROR HANDLING")
print("=" * 50)

# Error 1: FileNotFoundError
print("\n1. FileNotFoundError - File doesn't exist")
print("-" * 50)

try:
    with open("nonexistent_file.txt", "r") as file:
        content = file.read()
except FileNotFoundError:
    print("Error: The file does not exist!")
    print("Solution: Check the file path and name")

print("\n" + "=" * 50)

# Error 2: PermissionError
print("\n2. PermissionError - No permission to access")
print("-" * 50)

try:
    # Try to write to a protected location (may vary by system)
    with open("/root/protected.txt", "w") as file:
        file.write("test")
except PermissionError:
    print("Error: No permission to access this file/directory!")
    print("Solution: Check file permissions or run with appropriate rights")
except Exception as e:
    print(f"Note: Different error occurred: {type(e).__name__}")

print("\n" + "=" * 50)

# Error 3: IsADirectoryError
print("\n3. IsADirectoryError - Trying to open a directory as file")
print("-" * 50)

# Create a directory
os.makedirs("test_directory", exist_ok=True)

try:
    with open("test_directory", "r") as file:
        content = file.read()
except IsADirectoryError:
    print("Error: Trying to open a directory, not a file!")
    print("Solution: Provide a file path, not a directory path")

print("\n" + "=" * 50)

# Error 4: UnicodeDecodeError
print("\n4. UnicodeDecodeError - Encoding issues")
print("-" * 50)

# This example shows how to handle it
try:
    # Try reading with wrong encoding
    with open("example.txt", "r", encoding="ascii") as file:
        content = file.read()
except UnicodeDecodeError:
    print("Error: Cannot decode file with specified encoding!")
    print("Solution: Use correct encoding (e.g., 'utf-8')")

print("\n" + "=" * 50)

# Comprehensive error handling
print("\nComprehensive Error Handling Example:")
print("-" * 50)

def read_file_safely(filename):
    """Safely read a file with complete error handling"""
    try:
        with open(filename, "r") as file:
            content = file.read()
            return content
    except FileNotFoundError:
        return f"Error: File '{filename}' not found"
    except PermissionError:
        return f"Error: No permission to read '{filename}'"
    except IsADirectoryError:
        return f"Error: '{filename}' is a directory, not a file"
    except Exception as e:
        return f"Error: {type(e).__name__} - {e}"

# Test the function
print(read_file_safely("nonexistent.txt"))
print(read_file_safely("test_directory"))

print("\n" + "=" * 50)

# Check if file exists before opening
print("\nCheck file existence before opening:")
print("-" * 50)

def safe_file_operation(filename):
    """Check if file exists before attempting to read"""
    if os.path.exists(filename):
        if os.path.isfile(filename):
            with open(filename, "r") as file:
                print(f"Successfully opened '{filename}'")
                return file.read()
        else:
            return f"'{filename}' exists but is not a file"
    else:
        return f"File '{filename}' does not exist"

# Create test file
with open("test_file.txt", "w") as f:
    f.write("Test content\n")

print(safe_file_operation("test_file.txt"))
print(safe_file_operation("missing.txt"))
print(safe_file_operation("test_directory"))

print("\n" + "=" * 50)

# Writing with error handling
print("\nWriting with error handling:")
print("-" * 50)

def write_file_safely(filename, content):
    """Safely write to a file"""
    try:
        with open(filename, "w") as file:
            file.write(content)
            return f"Successfully wrote to '{filename}'"
    except PermissionError:
        return f"Error: No permission to write to '{filename}'"
    except IsADirectoryError:
        return f"Error: '{filename}' is a directory"
    except Exception as e:
        return f"Error: {type(e).__name__} - {e}"

print(write_file_safely("output.txt", "Hello, World!"))
print(write_file_safely("test_directory", "Test"))  # Will fail

print("\n" + "=" * 50)

# Best practices
print("\nBest Practices for File Error Handling:")
print("-" * 50)
print("1. Always use 'with' statement")
print("2. Handle specific exceptions separately")
print("3. Check if file exists before operations")
print("4. Provide meaningful error messages")
print("5. Log errors for debugging")
print("6. Use try-except-finally for cleanup")
print("7. Validate file paths and names")

print("\n" + "=" * 50)

# Complete example
print("\nComplete Example with all best practices:")
print("-" * 50)

def process_file(filename):
    """Complete file processing with error handling"""
    # Check existence
    if not os.path.exists(filename):
        print(f"Creating new file: {filename}")
        with open(filename, "w") as f:
            f.write("Default content\n")
    
    try:
        # Read file
        with open(filename, "r") as file:
            lines = file.readlines()
            print(f"File has {len(lines)} lines")
            
        # Process and write
        with open(filename, "a") as file:
            file.write("Processed successfully\n")
            
        return True
        
    except Exception as e:
        print(f"Error processing file: {e}")
        return False
    finally:
        print("File processing completed")

process_file("complete_example.txt")

print("\n" + "=" * 50)
