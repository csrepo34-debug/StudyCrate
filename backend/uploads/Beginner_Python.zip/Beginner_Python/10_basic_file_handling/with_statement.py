# Using 'with' Statement
# Best practice for file handling

print("USING 'WITH' STATEMENT")
print("=" * 50)

# Why use 'with' statement
print("\nBenefits of 'with' statement:")
print("1. Automatically closes file")
print("2. Handles exceptions properly")
print("3. Cleaner and more readable code")
print("4. Prevents resource leaks")

print("\n" + "=" * 50)

# Example 1: Basic with statement
print("\nExample 1: Basic with statement")
print("-" * 50)

# Create a file
with open("example.txt", "w") as file:
    file.write("Using with statement\n")
    file.write("File will auto-close\n")
    print("Writing to file...")
    print(f"File closed? {file.closed}")

print(f"After with block, file closed? {file.closed}")

print("\n" + "=" * 50)

# Example 2: Without 'with' (not recommended)
print("\nExample 2: Without 'with' (old way - not recommended)")
print("-" * 50)

file = open("without_with.txt", "w")
try:
    file.write("This is the old way\n")
    print("Writing to file...")
finally:
    file.close()
    print("File manually closed")

print("\n" + "=" * 50)

# Example 3: Reading with 'with'
print("\nExample 3: Reading with 'with'")
print("-" * 50)

with open("example.txt", "r") as file:
    content = file.read()
    print("File contents:")
    print(content)

print("\n" + "=" * 50)

# Example 4: Multiple file operations
print("\nExample 4: Multiple file operations in one block")
print("-" * 50)

with open("multi_ops.txt", "w") as file:
    file.write("Line 1\n")
    file.write("Line 2\n")
    file.write("Line 3\n")
    
    # Can perform other operations
    lines_written = 3
    print(f"Wrote {lines_written} lines")

print("\n" + "=" * 50)

# Example 5: Working with multiple files
print("\nExample 5: Working with multiple files")
print("-" * 50)

# Create source file
with open("source.txt", "w") as file:
    file.write("This is the source file\n")
    file.write("It will be copied\n")

# Copy file
with open("source.txt", "r") as source, open("destination.txt", "w") as dest:
    content = source.read()
    dest.write(content)
    print("File copied successfully")

# Verify copy
with open("destination.txt", "r") as file:
    print("\nContents of destination.txt:")
    print(file.read())

print("=" * 50)

# Example 6: Exception handling with 'with'
print("\nExample 6: Exception handling with 'with'")
print("-" * 50)

try:
    with open("nonexistent.txt", "r") as file:
        content = file.read()
except FileNotFoundError:
    print("Error: File not found!")
    print("But 'with' still ensures proper cleanup")

print("\n" + "=" * 50)

# Example 7: Appending with 'with'
print("\nExample 7: Appending with 'with'")
print("-" * 50)

# Create initial file
with open("append_test.txt", "w") as file:
    file.write("Initial line\n")

# Append multiple times
with open("append_test.txt", "a") as file:
    file.write("Appended line 1\n")
    file.write("Appended line 2\n")

# Read result
with open("append_test.txt", "r") as file:
    print("Final contents:")
    print(file.read())

print("=" * 50)

# Example 8: Processing file line by line
print("\nExample 8: Processing file line by line")
print("-" * 50)

# Create a data file
with open("numbers.txt", "w") as file:
    for i in range(1, 6):
        file.write(f"{i}\n")

# Read and process
total = 0
with open("numbers.txt", "r") as file:
    for line in file:
        number = int(line.strip())
        total += number
        print(f"Read: {number}")

print(f"Total: {total}")

print("\n" + "=" * 50)
print("All files created successfully!")
print("Always use 'with' statement for file handling!")
