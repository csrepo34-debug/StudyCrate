# Nested If Statements
# If statements inside other if statements

print("NESTED IF STATEMENT EXAMPLES")
print("=" * 50)

# Example 1: Driving eligibility
age = 20
has_license = True

print(f"Age: {age}")
print(f"Has license: {has_license}")
print()

if age >= 18:
    print("Age requirement: Met")
    if has_license:
        print("License: Valid")
        print("Result: You can drive!")
    else:
        print("License: Not found")
        print("Result: Get a license first")
else:
    print("Age requirement: Not met")
    print("Result: You're too young to drive")

print("\n" + "=" * 50)

# Example 2: Login system
username = "admin"
password = "pass123"

print(f"\nLogin Attempt:")

if username == "admin":
    print("Username verified")
    if password == "pass123":
        print("Password verified")
        print("Access granted!")
    else:
        print("Incorrect password")
else:
    print("Unknown username")

print("\n" + "=" * 50)

# Example 3: Scholarship eligibility
marks = 85
attendance = 92
extracurricular = True

print(f"\nMarks: {marks}")
print(f"Attendance: {attendance}%")
print(f"Extracurricular activities: {extracurricular}")
print()

if marks >= 80:
    print("Academic requirement: Met")
    if attendance >= 90:
        print("Attendance requirement: Met")
        if extracurricular:
            print("Extracurricular: Participated")
            print("\nResult: SCHOLARSHIP GRANTED!")
        else:
            print("Extracurricular: Not participated")
            print("\nResult: Join activities for scholarship")
    else:
        print("Attendance requirement: Not met")
else:
    print("Academic requirement: Not met")

print("\n" + "=" * 50)

# Example 4: Number classification
number = 15

print(f"\nNumber: {number}")

if number > 0:
    print("Number is positive")
    if number % 2 == 0:
        print("Number is even")
    else:
        print("Number is odd")
elif number < 0:
    print("Number is negative")
else:
    print("Number is zero")
