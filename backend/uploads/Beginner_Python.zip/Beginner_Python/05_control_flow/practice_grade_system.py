# Practice: Grade System
# Complete grading system with multiple criteria

print("STUDENT GRADING SYSTEM")
print("=" * 50)
print()

# Get student information
student_name = input("Enter student name: ")
marks = float(input("Enter marks (0-100): "))

print("\n" + "=" * 50)
print("GRADE REPORT")
print("=" * 50)

print(f"\nStudent Name: {student_name}")
print(f"Marks Obtained: {marks}")
print()

# Validate marks
if marks < 0 or marks > 100:
    print("Error: Invalid marks! Marks should be between 0 and 100.")
else:
    # Determine grade and remarks
    if marks >= 90:
        grade = "A+"
        remarks = "Outstanding performance!"
        status = "PASS"
    elif marks >= 80:
        grade = "A"
        remarks = "Excellent work!"
        status = "PASS"
    elif marks >= 70:
        grade = "B"
        remarks = "Very good!"
        status = "PASS"
    elif marks >= 60:
        grade = "C"
        remarks = "Good effort!"
        status = "PASS"
    elif marks >= 50:
        grade = "D"
        remarks = "Satisfactory, but needs improvement."
        status = "PASS"
    elif marks >= 40:
        grade = "E"
        remarks = "Poor performance, needs significant improvement."
        status = "PASS"
    else:
        grade = "F"
        remarks = "Failed. Please work harder."
        status = "FAIL"
    
    # Display results
    print(f"Grade: {grade}")
    print(f"Status: {status}")
    print(f"Remarks: {remarks}")
    
    # Additional feedback
    print()
    if status == "PASS":
        print("Congratulations on passing!")
        if marks >= 75:
            print("You are eligible for honors!")
    else:
        print("Better luck next time!")
        print(f"You need {50 - marks:.1f} more marks to pass.")

print("\n" + "=" * 50)
print("End of Report")
