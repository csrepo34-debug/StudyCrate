# Practice: Ticket Price Calculator
# Calculate ticket price based on age and other factors

print("MOVIE TICKET PRICE CALCULATOR")
print("=" * 50)
print()

# Base prices
base_price = 15.00

# Get customer information
age = int(input("Enter your age: "))
is_student = input("Are you a student? (yes/no): ").lower() == "yes"
is_weekend = input("Is it weekend? (yes/no): ").lower() == "yes"
movie_type = input("Movie type (regular/3d/imax): ").lower()

print("\n" + "=" * 50)
print("TICKET CALCULATION")
print("=" * 50)

# Calculate price based on age
if age < 0:
    print("\nError: Invalid age!")
elif age < 3:
    print("\nAge Category: Infant")
    ticket_price = 0.00
    print("Ticket is FREE for children under 3!")
elif age < 13:
    print("\nAge Category: Child")
    ticket_price = base_price * 0.5  # 50% discount
    print(f"Base price: ${base_price}")
    print(f"Child discount (50%): -${base_price * 0.5:.2f}")
elif age < 18:
    print("\nAge Category: Teen")
    ticket_price = base_price * 0.75  # 25% discount
    print(f"Base price: ${base_price}")
    print(f"Teen discount (25%): -${base_price * 0.25:.2f}")
elif age < 60:
    print("\nAge Category: Adult")
    ticket_price = base_price
    print(f"Base price: ${base_price}")
else:
    print("\nAge Category: Senior Citizen")
    ticket_price = base_price * 0.6  # 40% discount
    print(f"Base price: ${base_price}")
    print(f"Senior discount (40%): -${base_price * 0.4:.2f}")

# Apply student discount (additional 10%)
if is_student and age >= 13:
    student_discount = ticket_price * 0.1
    ticket_price -= student_discount
    print(f"Student discount (10%): -${student_discount:.2f}")

# Apply weekend surcharge (20%)
if is_weekend:
    weekend_charge = ticket_price * 0.2
    ticket_price += weekend_charge
    print(f"Weekend surcharge (20%): +${weekend_charge:.2f}")

# Apply movie type pricing
if movie_type == "3d":
    extra_charge = 5.00
    ticket_price += extra_charge
    print(f"3D surcharge: +${extra_charge:.2f}")
elif movie_type == "imax":
    extra_charge = 8.00
    ticket_price += extra_charge
    print(f"IMAX surcharge: +${extra_charge:.2f}")

print("\n" + "=" * 50)
print("FINAL TICKET PRICE")
print("=" * 50)

print(f"\nTotal: ${ticket_price:.2f}")

# Additional information
print("\nTicket Details:")
print(f"Age: {age}")
print(f"Student: {'Yes' if is_student else 'No'}")
print(f"Weekend: {'Yes' if is_weekend else 'No'}")
print(f"Movie Type: {movie_type.upper()}")

print("\n" + "=" * 50)
print("Thank you for your purchase!")
