# Practice: Get Comfortable Running Python Code
# Try running this file and observe the output

print("Welcome to Python Programming!")
print()  # Empty line

print("Let's explore the print() function:")
print("=" * 50)

# Printing different types of data
print("Text:", "Learning Python is fun!")
print("Numbers:", 42)
print("Decimal:", 3.14159)
print("Boolean:", True)

print()
print("Multiple values:")
print("Python", "is", "awesome!")

print()
print("Using special characters:")
print("Line 1\nLine 2\nLine 3")  # \n creates new line
print("Tab\tseparated\tvalues")  # \t creates tab

print()
print("Practice Exercise Complete!")
