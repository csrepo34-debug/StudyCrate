# Your First Python Program
# The traditional "Hello, World!" program

print("Hello, World!")
