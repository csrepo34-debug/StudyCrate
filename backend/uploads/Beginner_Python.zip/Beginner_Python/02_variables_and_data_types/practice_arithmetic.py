# Practice: Simple Arithmetic Program
# Performing calculations with different data types

print("SIMPLE ARITHMETIC CALCULATOR")
print("=" * 50)

# Define numbers
num1 = 25
num2 = 7
decimal1 = 15.5
decimal2 = 3.2

# Integer arithmetic
print("\nINTEGER ARITHMETIC:")
print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} * {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2:.2f}")
print(f"{num1} // {num2} = {num1 // num2} (Floor Division)")
print(f"{num1} % {num2} = {num1 % num2} (Remainder)")
print(f"{num1} ** 2 = {num1 ** 2} (Square)")

print("\n" + "=" * 50)

# Float arithmetic
print("\nFLOAT ARITHMETIC:")
print(f"{decimal1} + {decimal2} = {decimal1 + decimal2}")
print(f"{decimal1} - {decimal2} = {decimal1 - decimal2}")
print(f"{decimal1} * {decimal2} = {decimal1 * decimal2:.2f}")
print(f"{decimal1} / {decimal2} = {decimal1 / decimal2:.2f}")

print("\n" + "=" * 50)

# Mixed operations
print("\nMIXED OPERATIONS:")
result1 = num1 + decimal1
result2 = num2 * decimal2
print(f"{num1} (int) + {decimal1} (float) = {result1} (type: {type(result1).__name__})")
print(f"{num2} (int) * {decimal2} (float) = {result2:.2f} (type: {type(result2).__name__})")

print("\n" + "=" * 50)

# Complex calculation
area_rectangle = 15 * 20
area_circle = 3.14159 * (7 ** 2)
total_area = area_rectangle + area_circle

print("\nPRACTICAL EXAMPLE:")
print(f"Rectangle Area (15 x 20): {area_rectangle}")
print(f"Circle Area (radius 7): {area_circle:.2f}")
print(f"Total Area: {total_area:.2f}")
