# Practice: Simple Calculator
# Performing basic arithmetic operations on user input

print("SIMPLE CALCULATOR")
print("=" * 50)
print()

# Get two numbers from user
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

print("\n" + "=" * 50)
print("RESULTS")
print("=" * 50)

# Perform all basic operations
addition = num1 + num2
subtraction = num1 - num2
multiplication = num1 * num2
division = num1 / num2 if num2 != 0 else "Cannot divide by zero"
floor_division = num1 // num2 if num2 != 0 else "Cannot divide by zero"
modulus = num1 % num2 if num2 != 0 else "Cannot divide by zero"
power = num1 ** num2

# Display results
print(f"\nNumbers: {num1} and {num2}")
print()
print(f"Addition:        {num1} + {num2} = {addition}")
print(f"Subtraction:     {num1} - {num2} = {subtraction}")
print(f"Multiplication:  {num1} × {num2} = {multiplication}")
print(f"Division:        {num1} ÷ {num2} = {division}")

if isinstance(floor_division, str):
    print(f"Floor Division:  {floor_division}")
    print(f"Modulus:         {modulus}")
else:
    print(f"Floor Division:  {num1} // {num2} = {floor_division}")
    print(f"Modulus:         {num1} % {num2} = {modulus}")

print(f"Power:           {num1} ^ {num2} = {power}")

print("\n" + "=" * 50)
print("Calculator session complete!")
