# Input Function Basics
# Understanding how to get user input

# Basic input
print("BASIC INPUT EXAMPLES")
print("=" * 50)

name = input("Enter your name: ")
print(f"Hello, {name}!")

print("\n" + "=" * 50)

# Input always returns string
age_str = input("Enter your age: ")
print(f"Your age (as string): '{age_str}'")
print(f"Type: {type(age_str)}")

print("\n" + "=" * 50)

# Converting input to numbers
age = int(input("Enter your age (will convert to int): "))
print(f"Your age (as integer): {age}")
print(f"Type: {type(age)}")
print(f"Next year you'll be: {age + 1}")

print("\n" + "=" * 50)

# Float input
height = float(input("Enter your height in feet: "))
print(f"Your height: {height} feet")
print(f"Type: {type(height)}")

print("\n" + "=" * 50)

# Multiple inputs
print("\nEnter two numbers:")
num1 = int(input("First number: "))
num2 = int(input("Second number: "))
print(f"Sum: {num1 + num2}")
