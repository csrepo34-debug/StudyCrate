# Practice: User Details Program
# Collecting and displaying user information

print("USER REGISTRATION SYSTEM")
print("=" * 50)
print()

# Collecting user information
first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")
age = int(input("Enter your age: "))
email = input("Enter your email: ")
city = input("Enter your city: ")
phone = input("Enter your phone number: ")

print("\n" + "=" * 50)
print("USER PROFILE")
print("=" * 50)

# Displaying formatted user details
print(f"Full Name: {first_name} {last_name}")
print(f"Age: {age} years old")
print(f"Email: {email}")
print(f"City: {city}")
print(f"Phone: {phone}")

print("=" * 50)

# Additional calculated information
birth_year = 2026 - age
print(f"\nAdditional Information:")
print(f"Approximate Birth Year: {birth_year}")
print(f"Username: {first_name.lower()}{age}")
print(f"Full Name Length: {len(first_name + last_name)} characters")

print("\n" + "=" * 50)
print("Registration Complete!")
