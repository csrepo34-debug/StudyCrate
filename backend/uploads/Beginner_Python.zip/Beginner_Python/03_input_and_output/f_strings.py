# F-Strings (Formatted String Literals)
# Modern and recommended way to format strings in Python

print("F-STRING EXAMPLES")
print("=" * 50)

# Basic f-string
name = "Alice"
age = 25
print(f"My name is {name} and I am {age} years old")

print("\n" + "=" * 50)

# Expressions inside f-strings
x = 10
y = 5
print(f"{x} + {y} = {x + y}")
print(f"{x} * {y} = {x * y}")
print(f"Square of {x} = {x ** 2}")

print("\n" + "=" * 50)

# Formatting numbers
price = 99.99999
print(f"Price: ${price:.2f}")  # 2 decimal places

pi = 3.14159265359
print(f"Pi: {pi:.2f}")  # 2 decimals
print(f"Pi: {pi:.4f}")  # 4 decimals

print("\n" + "=" * 50)

# Width and alignment
product = "Laptop"
cost = 999.99

print(f"{'Product':<15} {'Price':>10}")
print(f"{product:<15} ${cost:>9.2f}")
# < left align, > right align, ^ center align

print("\n" + "=" * 50)

# Multi-line f-strings
name = "Bob"
city = "New York"
country = "USA"

message = f"""
Name: {name}
City: {city}
Country: {country}
"""
print(message)

print("=" * 50)

# Calling functions in f-strings
text = "python"
print(f"Original: {text}")
print(f"Uppercase: {text.upper()}")
print(f"Capitalized: {text.capitalize()}")
print(f"Length: {len(text)}")
