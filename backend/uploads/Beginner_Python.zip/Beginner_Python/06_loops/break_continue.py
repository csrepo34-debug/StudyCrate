# Break and Continue
# Loop control statements

print("BREAK AND CONTINUE EXAMPLES")
print("=" * 50)

# Example 1: break - Exit loop
print("\nUsing BREAK - Find first multiple of 7:")
for i in range(1, 101):
    if i % 7 == 0:
        print(f"First multiple of 7: {i}")
        break

print("\n" + "=" * 50)

# Example 2: continue - Skip iteration
print("\nUsing CONTINUE - Print odd numbers only:")
for i in range(1, 11):
    if i % 2 == 0:
        continue  # Skip even numbers
    print(i, end=" ")
print()

print("\n" + "=" * 50)

# Example 3: break in while loop
print("\nSearch for a number (searching for 5):")
numbers = [2, 7, 3, 5, 9, 1]
found = False

for num in numbers:
    if num == 5:
        print(f"Found 5 at position {numbers.index(num)}")
        found = True
        break

if not found:
    print("Number not found")

print("\n" + "=" * 50)

# Example 4: continue with condition
print("\nPrint numbers except multiples of 3:")
for i in range(1, 16):
    if i % 3 == 0:
        continue
    print(i, end=" ")
print()

print("\n" + "=" * 50)

# Example 5: break and continue together
print("\nPrint first 5 odd numbers:")
count = 0
num = 0

while True:
    num += 1
    
    if num % 2 == 0:
        continue  # Skip even numbers
    
    print(num, end=" ")
    count += 1
    
    if count == 5:
        break  # Exit after finding 5 odd numbers
print()

print("\n" + "=" * 50)

# Example 6: else with loops
print("\nLoop completed normally (else clause):")
for i in range(5):
    print(i, end=" ")
else:
    print("\nLoop finished without break")

print("\nLoop with break (else won't execute):")
for i in range(5):
    if i == 3:
        break
    print(i, end=" ")
else:
    print("\nThis won't print")
print("\nLoop was interrupted by break")
