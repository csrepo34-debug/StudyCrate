# Practice: Fibonacci Series
# Generate Fibonacci sequence

print("FIBONACCI SERIES GENERATOR")
print("=" * 50)
print()

# Get number of terms from user
n = int(input("How many terms of Fibonacci series? "))

print("\n" + "=" * 50)
print("FIBONACCI SERIES")
print("=" * 50)

# Handle special cases
if n <= 0:
    print("Please enter a positive number")
elif n == 1:
    print("Fibonacci series:")
    print(0)
else:
    # Initialize first two terms
    first = 0
    second = 1
    
    print(f"\nFirst {n} terms of Fibonacci series:")
    print(first, end=" ")
    
    if n > 1:
        print(second, end=" ")
    
    # Generate remaining terms
    for i in range(2, n):
        next_term = first + second
        print(next_term, end=" ")
        
        # Update values
        first = second
        second = next_term
    
    print()

print("\n" + "=" * 50)

# Alternative method using list
print("\nUsing list method:")
n2 = 10
fib_list = [0, 1]

for i in range(2, n2):
    next_term = fib_list[i-1] + fib_list[i-2]
    fib_list.append(next_term)

print(f"First {n2} Fibonacci numbers:")
print(fib_list)

print("\n" + "=" * 50)

# Show the pattern
print("\nFibonacci pattern explanation:")
a, b = 0, 1
print(f"F(0) = {a}")
print(f"F(1) = {b}")

for i in range(2, 8):
    c = a + b
    print(f"F({i}) = F({i-2}) + F({i-1}) = {a} + {b} = {c}")
    a, b = b, c
