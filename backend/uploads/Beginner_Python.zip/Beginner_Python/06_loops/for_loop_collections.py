# For Loop with Collections
# Iterating through lists, strings, and other sequences

print("FOR LOOP WITH COLLECTIONS")
print("=" * 50)

# Example 1: Iterating through a list
print("\nIterating through fruits:")
fruits = ["apple", "banana", "cherry", "mango"]
for fruit in fruits:
    print(f"- {fruit}")

print("\n" + "=" * 50)

# Example 2: Iterating through a string
print("\nIterating through characters:")
word = "Python"
for char in word:
    print(char, end=" ")
print()

print("\n" + "=" * 50)

# Example 3: Using enumerate for index and value
print("\nWith index numbers:")
colors = ["red", "green", "blue"]
for index, color in enumerate(colors):
    print(f"{index}: {color}")

print("\n" + "=" * 50)

# Example 4: Iterating through a dictionary
print("\nIterating through dictionary:")
student = {
    "name": "Alice",
    "age": 20,
    "grade": "A"
}

for key, value in student.items():
    print(f"{key}: {value}")

print("\n" + "=" * 50)

# Example 5: Nested loop
print("\nNested loop - Multiplication table:")
for i in range(1, 4):
    for j in range(1, 4):
        print(f"{i} × {j} = {i*j}", end="  ")
    print()  # New line after each row
