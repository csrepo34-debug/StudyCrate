# While Loop Basics
# Understanding while loops

print("WHILE LOOP EXAMPLES")
print("=" * 50)

# Example 1: Basic counting
print("\nCounting 1 to 5:")
count = 1
while count <= 5:
    print(count, end=" ")
    count += 1
print()

print("\n" + "=" * 50)

# Example 2: Countdown
print("\nCountdown from 5:")
num = 5
while num > 0:
    print(num, end=" ")
    num -= 1
print("Done!")

print("\n" + "=" * 50)

# Example 3: Sum of numbers
print("\nSum of numbers 1 to 10:")
total = 0
number = 1
while number <= 10:
    total += number
    number += 1
print(f"Total: {total}")

print("\n" + "=" * 50)

# Example 4: User input validation
print("\nPassword check (password is 'secret'):")
attempts = 0
max_attempts = 3

while attempts < max_attempts:
    password = input(f"Attempt {attempts + 1}/{max_attempts} - Enter password: ")
    if password == "secret":
        print("Access granted!")
        break
    else:
        attempts += 1
        if attempts < max_attempts:
            print("Wrong password. Try again.")
else:
    print("Too many failed attempts!")

print("\n" + "=" * 50)

# Example 5: Menu system
print("\nSimple menu (enter 0 to exit):")
choice = -1
while choice != 0:
    print("\n1. Option 1")
    print("2. Option 2")
    print("0. Exit")
    choice = int(input("Enter choice: "))
    
    if choice == 1:
        print("You selected Option 1")
    elif choice == 2:
        print("You selected Option 2")
    elif choice == 0:
        print("Goodbye!")
    else:
        print("Invalid choice")
