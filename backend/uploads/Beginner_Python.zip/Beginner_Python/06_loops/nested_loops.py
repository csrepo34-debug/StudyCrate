# Nested Loops
# Loops inside loops

print("NESTED LOOPS EXAMPLES")
print("=" * 50)

# Example 1: Simple pattern
print("\nPattern 1:")
for i in range(5):
    for j in range(i + 1):
        print("*", end=" ")
    print()

print("\n" + "=" * 50)

# Example 2: Number pattern
print("\nNumber pattern:")
for i in range(1, 6):
    for j in range(1, i + 1):
        print(j, end=" ")
    print()

print("\n" + "=" * 50)

# Example 3: Multiplication table
print("\nMultiplication table (1-5):")
print("   ", end="")
for i in range(1, 6):
    print(f"{i:4}", end="")
print("\n" + "-" * 25)

for i in range(1, 6):
    print(f"{i} |", end="")
    for j in range(1, 6):
        print(f"{i*j:4}", end="")
    print()

print("\n" + "=" * 50)

# Example 4: Matrix
print("\nPrinting a matrix:")
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

for row in matrix:
    for element in row:
        print(f"{element:3}", end=" ")
    print()

print("\n" + "=" * 50)

# Example 5: All combinations
print("\nAll combinations:")
suits = ["Hearts", "Diamonds", "Clubs", "Spades"]
ranks = ["Ace", "King", "Queen"]

for suit in suits:
    for rank in ranks:
        print(f"{rank} of {suit}")
