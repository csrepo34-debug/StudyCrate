# Practice: Number Patterns
# Creating various patterns using loops

print("NUMBER PATTERNS")
print("=" * 50)

# Pattern 1: Right triangle
print("\nPattern 1: Right Triangle")
rows = 5
for i in range(1, rows + 1):
    for j in range(1, i + 1):
        print(j, end=" ")
    print()

print("\n" + "=" * 50)

# Pattern 2: Square
print("\nPattern 2: Square")
size = 4
for i in range(size):
    for j in range(size):
        print("*", end=" ")
    print()

print("\n" + "=" * 50)

# Pattern 3: Reverse triangle
print("\nPattern 3: Reverse Triangle")
for i in range(rows, 0, -1):
    for j in range(1, i + 1):
        print(j, end=" ")
    print()

print("\n" + "=" * 50)

# Pattern 4: Pyramid
print("\nPattern 4: Pyramid")
for i in range(1, rows + 1):
    # Print spaces
    for j in range(rows - i):
        print(" ", end=" ")
    # Print stars
    for k in range(1, i + 1):
        print(k, end=" ")
    print()

print("\n" + "=" * 50)

# Pattern 5: Diamond
print("\nPattern 5: Number Diamond")
n = 5
# Upper half
for i in range(1, n + 1):
    for j in range(n - i):
        print(" ", end="")
    for k in range(1, i + 1):
        print(k, end="")
    print()

# Lower half
for i in range(n - 1, 0, -1):
    for j in range(n - i):
        print(" ", end="")
    for k in range(1, i + 1):
        print(k, end="")
    print()

print("\n" + "=" * 50)

# Pattern 6: Floyd's Triangle
print("\nPattern 6: Floyd's Triangle")
num = 1
for i in range(1, 6):
    for j in range(i):
        print(num, end=" ")
        num += 1
    print()
