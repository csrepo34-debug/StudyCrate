# For Loop Basics
# Understanding for loops with range()

print("FOR LOOP EXAMPLES")
print("=" * 50)

# Example 1: Basic counting
print("\nCounting 0 to 4:")
for i in range(5):
    print(i, end=" ")
print()

print("\n" + "=" * 50)

# Example 2: Counting 1 to 10
print("\nCounting 1 to 10:")
for i in range(1, 11):
    print(i, end=" ")
print()

print("\n" + "=" * 50)

# Example 3: Even numbers
print("\nEven numbers from 0 to 10:")
for i in range(0, 11, 2):
    print(i, end=" ")
print()

print("\n" + "=" * 50)

# Example 4: Reverse counting
print("\nCountdown from 10 to 1:")
for i in range(10, 0, -1):
    print(i, end=" ")
print("\nBlast off!")

print("\n" + "=" * 50)

# Example 5: Multiplication table
number = 5
print(f"\nMultiplication table of {number}:")
for i in range(1, 11):
    result = number * i
    print(f"{number} × {i} = {result}")
