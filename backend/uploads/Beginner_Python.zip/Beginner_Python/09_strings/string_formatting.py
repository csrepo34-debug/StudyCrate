# String Formatting
# Different ways to format strings

print("STRING FORMATTING")
print("=" * 50)

# Method 1: f-strings (Python 3.6+) - RECOMMENDED
print("\n1. F-STRINGS (Recommended):")
name = "Alice"
age = 25
height = 5.8

print(f"My name is {name}")
print(f"I am {age} years old")
print(f"My height is {height} feet")
print(f"{name} is {age} years old and {height} feet tall")

print("\n" + "=" * 50)

# F-strings with expressions
print("\nF-strings with expressions:")
x = 10
y = 5
print(f"{x} + {y} = {x + y}")
print(f"{x} * {y} = {x * y}")
print(f"Square of {x} = {x ** 2}")

print("\n" + "=" * 50)

# F-strings with formatting
print("\nF-strings with number formatting:")
pi = 3.14159265359
price = 99.5

print(f"Pi (2 decimals): {pi:.2f}")
print(f"Pi (4 decimals): {pi:.4f}")
print(f"Price: ${price:.2f}")

large_num = 1234567
print(f"With commas: {large_num:,}")

print("\n" + "=" * 50)

# F-strings with alignment
print("\nF-strings with alignment:")
items = ["Apple", "Banana", "Cherry"]
prices = [1.50, 0.75, 2.25]

print(f"{'Item':<10} {'Price':>8}")
print("-" * 18)
for item, price in zip(items, prices):
    print(f"{item:<10} ${price:>7.2f}")

print("\n" + "=" * 50)

# Method 2: format() method
print("\n2. format() METHOD:")
text1 = "My name is {}".format("Bob")
text2 = "I am {} years old".format(30)
text3 = "{} is {} years old".format("Bob", 30)

print(text1)
print(text2)
print(text3)

# With index
text4 = "{0} {1} {0}".format("Hello", "World")
print(text4)

# With names
text5 = "{name} is {age} years old".format(name="Charlie", age=35)
print(text5)

print("\n" + "=" * 50)

# Method 3: % operator (old style)
print("\n3. % OPERATOR (Old style):")
name = "David"
age = 40

text1 = "My name is %s" % name
text2 = "I am %d years old" % age
text3 = "%s is %d years old" % (name, age)

print(text1)
print(text2)
print(text3)

# Number formatting
print("Pi: %.2f" % pi)
print("Number: %d" % 42)

print("\n" + "=" * 50)

# Multi-line f-strings
print("\nMulti-line f-strings:")
person = {
    "name": "Eve",
    "age": 28,
    "city": "NYC"
}

info = f"""
Name: {person['name']}
Age: {person['age']}
City: {person['city']}
"""
print(info)

print("=" * 50)

# Practical example - Receipt
print("\nPractical Example - Receipt:")
items_purchased = [
    ("Laptop", 999.99, 1),
    ("Mouse", 29.99, 2),
    ("Keyboard", 79.99, 1)
]

print("\n" + "=" * 50)
print(f"{'RECEIPT':^50}")
print("=" * 50)
print(f"{'Item':<20} {'Price':>10} {'Qty':>5} {'Total':>12}")
print("-" * 50)

subtotal = 0
for item, price, qty in items_purchased:
    total = price * qty
    subtotal += total
    print(f"{item:<20} ${price:>9.2f} {qty:>5} ${total:>11.2f}")

tax = subtotal * 0.08
grand_total = subtotal + tax

print("-" * 50)
print(f"{'Subtotal:':<38} ${subtotal:>11.2f}")
print(f"{'Tax (8%):':<38} ${tax:>11.2f}")
print("=" * 50)
print(f"{'TOTAL:':<38} ${grand_total:>11.2f}")
print("=" * 50)
