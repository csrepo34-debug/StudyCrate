# Practice: Count Vowels
# Count vowels in a string

def count_vowels(text):
    """Count number of vowels in a string"""
    vowels = "aeiouAEIOU"
    count = 0
    
    for char in text:
        if char in vowels:
            count += 1
    
    return count


def count_vowels_detailed(text):
    """Count each vowel separately"""
    vowels = {'a': 0, 'e': 0, 'i': 0, 'o': 0, 'u': 0}
    
    for char in text.lower():
        if char in vowels:
            vowels[char] += 1
    
    return vowels


def count_consonants(text):
    """Count consonants in a string"""
    count = 0
    vowels = "aeiouAEIOU"
    
    for char in text:
        if char.isalpha() and char not in vowels:
            count += 1
    
    return count


def analyze_text(text):
    """Complete text analysis"""
    vowels = count_vowels(text)
    consonants = count_consonants(text)
    letters = sum(1 for char in text if char.isalpha())
    digits = sum(1 for char in text if char.isdigit())
    spaces = sum(1 for char in text if char.isspace())
    
    return {
        'vowels': vowels,
        'consonants': consonants,
        'letters': letters,
        'digits': digits,
        'spaces': spaces,
        'total': len(text)
    }


# Main program
print("VOWEL COUNTER")
print("=" * 50)

# Example 1: Simple counting
text1 = "Hello World"
vowel_count = count_vowels(text1)
print(f"\nText: '{text1}'")
print(f"Vowels: {vowel_count}")

print("\n" + "=" * 50)

# Example 2: Detailed vowel count
text2 = "Programming with Python is awesome"
detailed = count_vowels_detailed(text2)

print(f"\nText: '{text2}'")
print("\nVowel breakdown:")
for vowel, count in sorted(detailed.items()):
    print(f"  {vowel}: {count}")

total_vowels = sum(detailed.values())
print(f"\nTotal vowels: {total_vowels}")

print("\n" + "=" * 50)

# Example 3: Vowels vs Consonants
text3 = "Python Programming"
vowels = count_vowels(text3)
consonants = count_consonants(text3)

print(f"\nText: '{text3}'")
print(f"Vowels: {vowels}")
print(f"Consonants: {consonants}")
print(f"Ratio (V:C): {vowels}:{consonants}")

print("\n" + "=" * 50)

# Example 4: Complete analysis
text4 = "Python 3.12 is great!"
analysis = analyze_text(text4)

print(f"\nComplete Analysis: '{text4}'")
print("-" * 50)
for key, value in analysis.items():
    print(f"{key.capitalize():<15}: {value}")

print("\n" + "=" * 50)

# Example 5: Compare multiple texts
texts = [
    "Hello",
    "Python",
    "Programming",
    "Artificial Intelligence"
]

print("\nCompare vowel counts:")
print(f"{'Text':<25} {'Vowels':>8} {'Consonants':>12}")
print("-" * 45)

for text in texts:
    v = count_vowels(text)
    c = count_consonants(text)
    print(f"{text:<25} {v:>8} {c:>12}")

print("\n" + "=" * 50)

# Interactive mode
print("\nInteractive Vowel Counter:")
user_text = input("Enter a text: ")

if user_text:
    vowels = count_vowels(user_text)
    detailed = count_vowels_detailed(user_text)
    consonants = count_consonants(user_text)
    
    print(f"\nAnalysis of: '{user_text}'")
    print(f"Total vowels: {vowels}")
    print(f"Total consonants: {consonants}")
    
    print("\nVowel breakdown:")
    for vowel, count in sorted(detailed.items()):
        if count > 0:
            print(f"  {vowel}: {count}")
    
    # Find most common vowel
    if vowels > 0:
        most_common = max(detailed, key=detailed.get)
        if detailed[most_common] > 0:
            print(f"\nMost common vowel: '{most_common}' ({detailed[most_common]} times)")

print("\n" + "=" * 50)
