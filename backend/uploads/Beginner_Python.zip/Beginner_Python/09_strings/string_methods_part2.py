# String Methods - Part 2
# Modification and formatting methods

print("STRING METHODS - PART 2")
print("=" * 50)

# replace() method
print("\nreplace() method:")
text = "I like Java. Java is great."
print(f"Original: '{text}'")
new_text = text.replace("Java", "Python")
print(f"After replace: '{new_text}'")

# Replace with count
text2 = "one one one one"
print(f"\nOriginal: '{text2}'")
print(f"Replace first 2: '{text2.replace('one', 'two', 2)}'")

print("\n" + "=" * 50)

# strip() methods
print("\nstrip() methods:")
text = "   Hello World   "
print(f"Original: '{text}'")
print(f"strip(): '{text.strip()}'")
print(f"lstrip(): '{text.lstrip()}'")
print(f"rstrip(): '{text.rstrip()}'")

# Strip specific characters
text2 = "***Hello***"
print(f"\nOriginal: '{text2}'")
print(f"strip('*'): '{text2.strip('*')}'")

print("\n" + "=" * 50)

# split() method
print("\nsplit() method:")
sentence = "Python is easy to learn"
words = sentence.split()
print(f"Sentence: '{sentence}'")
print(f"Split: {words}")

# Split by delimiter
csv_data = "apple,banana,cherry,mango"
fruits = csv_data.split(",")
print(f"\nCSV: '{csv_data}'")
print(f"Split by comma: {fruits}")

# Split with maxsplit
text3 = "one two three four five"
parts = text3.split(" ", 2)
print(f"\nText: '{text3}'")
print(f"Split (max 2): {parts}")

print("\n" + "=" * 50)

# join() method
print("\njoin() method:")
words = ["Python", "is", "awesome"]
sentence = " ".join(words)
print(f"List: {words}")
print(f"Joined: '{sentence}'")

# Join with different separator
csv = ",".join(words)
print(f"CSV format: '{csv}'")

# Join numbers (convert to strings first)
numbers = [1, 2, 3, 4, 5]
number_str = "-".join(str(n) for n in numbers)
print(f"Numbers: {numbers}")
print(f"Joined: '{number_str}'")

print("\n" + "=" * 50)

# Alignment methods
print("\nAlignment methods:")
text = "Python"
print(f"Original: '{text}'")
print(f"center(20): '{text.center(20)}'")
print(f"ljust(20): '{text.ljust(20)}'")
print(f"rjust(20): '{text.rjust(20)}'")
print(f"center(20, '*'): '{text.center(20, '*')}'")

print("\n" + "=" * 50)

# zfill() method
print("\nzfill() method (zero padding):")
numbers = ["1", "23", "456"]
for num in numbers:
    print(f"{num} -> {num.zfill(5)}")

print("\n" + "=" * 50)

# Practical examples
print("\nPractical Examples:")

# Clean user input
user_input = "  hello@example.com  "
cleaned = user_input.strip().lower()
print(f"Raw input: '{user_input}'")
print(f"Cleaned: '{cleaned}'")

# Format table
print("\nFormatted table:")
items = [("Apple", 50), ("Banana", 30), ("Cherry", 75)]
print(f"{'Item':<10} {'Price':>10}")
print("-" * 20)
for item, price in items:
    print(f"{item:<10} ${price:>9.2f}")

# Create username from name
full_name = "John Doe"
username = full_name.lower().replace(" ", "_")
print(f"\nFull name: {full_name}")
print(f"Username: {username}")
