# Practice: Palindrome Checker
# Check if a string is a palindrome

def is_palindrome(text):
    """Check if a string is a palindrome"""
    # Remove spaces and convert to lowercase
    cleaned = text.replace(" ", "").lower()
    
    # Remove punctuation
    cleaned = ''.join(char for char in cleaned if char.isalnum())
    
    # Check if string equals its reverse
    return cleaned == cleaned[::-1]


def is_palindrome_manual(text):
    """Check palindrome using manual comparison"""
    cleaned = ''.join(char.lower() for char in text if char.isalnum())
    
    left = 0
    right = len(cleaned) - 1
    
    while left < right:
        if cleaned[left] != cleaned[right]:
            return False
        left += 1
        right -= 1
    
    return True


# Main program
print("PALINDROME CHECKER")
print("=" * 50)

# Test cases
test_words = [
    "radar",
    "level",
    "hello",
    "racecar",
    "python",
    "madam",
    "A man a plan a canal Panama",
    "Was it a car or a cat I saw",
    "hello world"
]

print("\nChecking words:")
for word in test_words:
    result = "Palindrome" if is_palindrome(word) else "Not a palindrome"
    print(f"'{word}': {result}")

print("\n" + "=" * 50)

# Show the comparison
print("\nDetailed check for 'racecar':")
word = "racecar"
reversed_word = word[::-1]
print(f"Original: {word}")
print(f"Reversed: {reversed_word}")
print(f"Are they same? {word == reversed_word}")

print("\n" + "=" * 50)

# Interactive mode
print("\nInteractive Palindrome Checker:")
user_input = input("Enter a word or phrase: ")

if is_palindrome(user_input):
    print(f"'{user_input}' is a PALINDROME!")
    
    # Show cleaned version
    cleaned = ''.join(char.lower() for char in user_input if char.isalnum())
    print(f"Cleaned version: '{cleaned}'")
    print(f"Reversed: '{cleaned[::-1]}'")
else:
    print(f"'{user_input}' is NOT a palindrome.")

print("\n" + "=" * 50)

# Find all palindromes in a list
print("\nFind palindromes in word list:")
words = ["level", "hello", "radar", "world", "noon", "python", "civic", "test"]
palindromes = [word for word in words if is_palindrome(word)]

print(f"Words: {words}")
print(f"Palindromes found: {palindromes}")

print("\n" + "=" * 50)

# Longest palindrome
print("\nFind longest palindrome:")
longest = max(palindromes, key=len) if palindromes else None
if longest:
    print(f"Longest palindrome: '{longest}' (length: {len(longest)})")

# Count palindromes
print(f"\nTotal palindromes: {len(palindromes)} out of {len(words)} words")
