# String Basics
# Understanding strings and basic operations

print("STRING BASICS")
print("=" * 50)

# Creating strings
print("\nCreating strings:")
single = 'Hello'
double = "World"
triple = '''Multi-line
string
example'''

print(f"Single quotes: {single}")
print(f"Double quotes: {double}")
print(f"Triple quotes:\n{triple}")

print("\n" + "=" * 50)

# String indexing
print("\nString indexing:")
text = "Python"
print(f"String: {text}")
print(f"First character: {text[0]}")
print(f"Last character: {text[-1]}")
print(f"Second character: {text[1]}")
print(f"Second from end: {text[-2]}")

print("\n" + "=" * 50)

# String slicing
print("\nString slicing:")
message = "Hello, World!"
print(f"String: {message}")
print(f"First 5: {message[:5]}")
print(f"Last 6: {message[-6:]}")
print(f"Middle: {message[7:12]}")
print(f"Every 2nd: {message[::2]}")
print(f"Reverse: {message[::-1]}")

print("\n" + "=" * 50)

# String concatenation
print("\nString concatenation:")
first = "Hello"
second = "World"
combined = first + " " + second
print(f"'{first}' + ' ' + '{second}' = '{combined}'")

# String repetition
repeated = "Ha" * 3
print(f"'Ha' * 3 = '{repeated}'")

print("\n" + "=" * 50)

# String length
print("\nString length:")
text = "Programming"
print(f"String: '{text}'")
print(f"Length: {len(text)}")

print("\n" + "=" * 50)

# String membership
print("\nString membership:")
sentence = "Python is awesome"
print(f"String: '{sentence}'")
print(f"'Python' in string: {'Python' in sentence}")
print(f"'Java' in string: {'Java' in sentence}")
print(f"'is' not in string: {'is' not in sentence}")

print("\n" + "=" * 50)

# Iterating through string
print("\nIterating through string:")
word = "HELLO"
print(f"String: {word}")
print("Characters:")
for char in word:
    print(char, end=" ")
print()
