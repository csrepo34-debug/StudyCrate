# Comparison Operators
# Comparing values and getting True/False results

print("COMPARISON OPERATORS")
print("=" * 50)

x = 10
y = 20
z = 10

print(f"x = {x}")
print(f"y = {y}")
print(f"z = {z}")
print()

# Comparison operations
print("Comparisons:")
print(f"x == y  (Equal to):                {x == y}")
print(f"x == z  (Equal to):                {x == z}")
print(f"x != y  (Not equal to):            {x != y}")
print(f"x > y   (Greater than):            {x > y}")
print(f"x < y   (Less than):               {x < y}")
print(f"x >= z  (Greater than or equal):   {x >= z}")
print(f"y <= z  (Less than or equal):      {y <= z}")

print("\n" + "=" * 50)

# String comparisons
print("\nSTRING COMPARISONS:")
name1 = "Alice"
name2 = "Bob"
name3 = "Alice"

print(f"'{name1}' == '{name2}': {name1 == name2}")
print(f"'{name1}' == '{name3}': {name1 == name3}")
print(f"'{name1}' < '{name2}':  {name1 < name2} (Alphabetical)")

print("\n" + "=" * 50)

# Practical example
print("\nPRACTICAL EXAMPLE:")
age = 18
passing_marks = 40
scored_marks = 45

is_adult = age >= 18
has_passed = scored_marks >= passing_marks

print(f"Age: {age}")
print(f"Is adult (age >= 18): {is_adult}")
print(f"Scored: {scored_marks}, Required: {passing_marks}")
print(f"Has passed: {has_passed}")
