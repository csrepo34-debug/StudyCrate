# Logical Operators
# Combining multiple conditions with and, or, not

print("LOGICAL OPERATORS")
print("=" * 50)

# Sample values
a = True
b = False
x = 10
y = 20

print(f"a = {a}")
print(f"b = {b}")
print()

# AND operator - Both must be True
print("AND OPERATOR (both must be True):")
print(f"a and a = {a and a}")
print(f"a and b = {a and b}")
print(f"b and b = {b and b}")
print()

print("Practical AND:")
print(f"(x > 5) and (y > 15) = {(x > 5) and (y > 15)}")
print(f"(x > 5) and (y > 25) = {(x > 5) and (y > 25)}")

print("\n" + "=" * 50)

# OR operator - At least one must be True
print("\nOR OPERATOR (at least one must be True):")
print(f"a or a = {a or a}")
print(f"a or b = {a or b}")
print(f"b or b = {b or b}")
print()

print("Practical OR:")
print(f"(x > 15) or (y > 15) = {(x > 15) or (y > 15)}")
print(f"(x > 15) or (y > 25) = {(x > 15) or (y > 25)}")

print("\n" + "=" * 50)

# NOT operator - Reverses the result
print("\nNOT OPERATOR (reverses the result):")
print(f"not a = {not a}")
print(f"not b = {not b}")
print(f"not (x > 5) = {not (x > 5)}")

print("\n" + "=" * 50)

# Complex combinations
print("\nCOMPLEX COMBINATIONS:")
age = 25
has_license = True
has_car = False

can_drive = (age >= 18) and has_license
print(f"Age: {age}, Has License: {has_license}")
print(f"Can drive legally: {can_drive}")

can_drive_own = can_drive and has_car
print(f"Can drive own car: {can_drive_own}")

needs_rental = can_drive and (not has_car)
print(f"Needs rental car: {needs_rental}")
