# Operator Precedence
# Understanding the order of operations

print("OPERATOR PRECEDENCE")
print("=" * 50)

# Without parentheses
result1 = 10 + 5 * 2
print(f"10 + 5 * 2 = {result1}")
print("(Multiplication happens first)")

print("\n" + "=" * 50)

# With parentheses
result2 = (10 + 5) * 2
print(f"(10 + 5) * 2 = {result2}")
print("(Parentheses force addition first)")

print("\n" + "=" * 50)

# Complex expression
result3 = 2 + 3 * 4 ** 2 / 2 - 1
print(f"2 + 3 * 4 ** 2 / 2 - 1 = {result3}")
print("Order: 4**2=16, 3*16=48, 48/2=24, 2+24=26, 26-1=25")

print("\n" + "=" * 50)

# Comparison and logical
x = 10
result4 = x > 5 and x < 15
print(f"x = {x}")
print(f"x > 5 and x < 15 = {result4}")
print("Order: comparisons first, then 'and'")

print("\n" + "=" * 50)

# Precedence order demonstration
print("\nPRECEDENCE ORDER (Highest to Lowest):")
print("1. Parentheses ()")
print("2. Exponentiation **")
print("3. Multiplication *, Division /, Floor //, Modulus %")
print("4. Addition +, Subtraction -")
print("5. Comparison ==, !=, >, <, >=, <=")
print("6. Logical NOT")
print("7. Logical AND")
print("8. Logical OR")

print("\n" + "=" * 50)

# Best practice examples
print("\nBEST PRACTICE - Use Parentheses for Clarity:")
calculation1 = (2 + 3) * (4 + 5)
calculation2 = ((10 - 5) ** 2) / 5
print(f"(2 + 3) * (4 + 5) = {calculation1}")
print(f"((10 - 5) ** 2) / 5 = {calculation2}")
