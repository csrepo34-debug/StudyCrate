# Practice: Student Marks List
# Managing student marks using lists and dictionaries

print("STUDENT MARKS MANAGEMENT SYSTEM")
print("=" * 50)

# Method 1: Using lists
print("\nMethod 1: Using Lists")
print("-" * 50)

students = ["Alice", "Bob", "Charlie", "Diana"]
marks = [85, 92, 78, 95]

print("Student Marks:")
for i in range(len(students)):
    print(f"{students[i]}: {marks[i]}")

# Calculate statistics
total = sum(marks)
average = total / len(marks)
highest = max(marks)
lowest = min(marks)

print(f"\nTotal marks: {total}")
print(f"Average: {average:.2f}")
print(f"Highest: {highest}")
print(f"Lowest: {lowest}")

print("\n" + "=" * 50)

# Method 2: Using dictionary
print("\nMethod 2: Using Dictionary")
print("-" * 50)

student_marks = {
    "Alice": 85,
    "Bob": 92,
    "Charlie": 78,
    "Diana": 95,
    "Eve": 88
}

print("Student Marks:")
for student, mark in student_marks.items():
    print(f"{student}: {mark}")

# Find top scorer
top_student = max(student_marks, key=student_marks.get)
print(f"\nTop Scorer: {top_student} with {student_marks[top_student]} marks")

# Find students who passed (>= 80)
passed_students = {name: mark for name, mark in student_marks.items() if mark >= 80}
print(f"\nStudents who scored >= 80:")
for student, mark in passed_students.items():
    print(f"  {student}: {mark}")

print("\n" + "=" * 50)

# Method 3: List of dictionaries (most flexible)
print("\nMethod 3: List of Dictionaries")
print("-" * 50)

students_data = [
    {"name": "Alice", "math": 85, "science": 90, "english": 88},
    {"name": "Bob", "math": 92, "science": 87, "english": 95},
    {"name": "Charlie", "math": 78, "science": 82, "english": 75},
    {"name": "Diana", "math": 95, "science": 92, "english": 90}
]

print("Detailed Student Records:")
for student in students_data:
    name = student["name"]
    math = student["math"]
    science = student["science"]
    english = student["english"]
    total = math + science + english
    average = total / 3
    
    print(f"\n{name}:")
    print(f"  Math: {math}")
    print(f"  Science: {science}")
    print(f"  English: {english}")
    print(f"  Total: {total}")
    print(f"  Average: {average:.2f}")

print("\n" + "=" * 50)

# Subject-wise analysis
print("\nSubject-wise Analysis:")

math_marks = [s["math"] for s in students_data]
science_marks = [s["science"] for s in students_data]
english_marks = [s["english"] for s in students_data]

print(f"Math - Average: {sum(math_marks)/len(math_marks):.2f}")
print(f"Science - Average: {sum(science_marks)/len(science_marks):.2f}")
print(f"English - Average: {sum(english_marks)/len(english_marks):.2f}")

print("\n" + "=" * 50)

# Interactive addition
print("\nAdd a new student:")
new_name = input("Enter student name: ")
new_math = int(input("Enter Math marks: "))
new_science = int(input("Enter Science marks: "))
new_english = int(input("Enter English marks: "))

new_student = {
    "name": new_name,
    "math": new_math,
    "science": new_science,
    "english": new_english
}

students_data.append(new_student)

print(f"\n{new_name} added successfully!")
print(f"Total students: {len(students_data)}")
