# Dictionaries
# Understanding key-value pairs

print("PYTHON DICTIONARIES")
print("=" * 50)

# Creating dictionaries
print("\nCreating dictionaries:")
student = {
    "name": "Alice",
    "age": 20,
    "grade": "A"
}

empty = {}

person = dict(name="Bob", age=25, city="NYC")

print(f"Student: {student}")
print(f"Empty: {empty}")
print(f"Person: {person}")

print("\n" + "=" * 50)

# Accessing values
print("\nAccessing values:")
print(f"Name: {student['name']}")
print(f"Age: {student['age']}")
print(f"Grade: {student['grade']}")

print("\nUsing get() method:")
print(f"Name: {student.get('name')}")
print(f"City: {student.get('city', 'Not found')}")  # With default

print("\n" + "=" * 50)

# Adding/Updating values
print("\nAdding/Updating values:")
car = {"brand": "Toyota", "year": 2020}
print(f"Original: {car}")

car["color"] = "red"  # Add new key
print(f"After adding color: {car}")

car["year"] = 2021  # Update existing
print(f"After updating year: {car}")

car.update({"model": "Camry", "price": 25000})
print(f"After update(): {car}")

print("\n" + "=" * 50)

# Removing items
print("\nRemoving items:")
product = {
    "name": "Laptop",
    "price": 1000,
    "brand": "Dell",
    "quantity": 5
}
print(f"Original: {product}")

del product["quantity"]
print(f"After del: {product}")

removed_price = product.pop("price")
print(f"After pop('price'): {product}")
print(f"Removed value: {removed_price}")

print("\n" + "=" * 50)

# Dictionary methods
print("\nDictionary methods:")
info = {"a": 1, "b": 2, "c": 3}

print(f"Keys: {info.keys()}")
print(f"Values: {info.values()}")
print(f"Items: {info.items()}")

print("\n" + "=" * 50)

# Iterating through dictionary
print("\nIterating through dictionary:")
scores = {"Math": 95, "Science": 87, "English": 92}

print("Keys only:")
for subject in scores:
    print(f"- {subject}")

print("\nKeys and values:")
for subject, score in scores.items():
    print(f"{subject}: {score}")

print("\nValues only:")
for score in scores.values():
    print(f"- {score}")

print("\n" + "=" * 50)

# Nested dictionaries
print("\nNested dictionaries:")
students = {
    "student1": {
        "name": "Alice",
        "age": 20,
        "grade": "A"
    },
    "student2": {
        "name": "Bob",
        "age": 21,
        "grade": "B"
    }
}

print("Students data:")
for student_id, student_info in students.items():
    print(f"\n{student_id}:")
    for key, value in student_info.items():
        print(f"  {key}: {value}")

print("\n" + "=" * 50)

# Dictionary comprehension
print("\nDictionary comprehension:")
squares = {x: x**2 for x in range(1, 6)}
print(f"Squares: {squares}")

# Check membership
print(f"\n3 in squares: {3 in squares}")
print(f"Length: {len(squares)}")
