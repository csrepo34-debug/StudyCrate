# Function Basics
# Defining and calling simple functions

print("FUNCTION BASICS")
print("=" * 50)

# Example 1: Function with no parameters
def greet():
    """Simple greeting function"""
    print("Hello, World!")

print("\nCalling greet():")
greet()

print("\n" + "=" * 50)

# Example 2: Function with parameters
def greet_person(name):
    """Greet a specific person"""
    print(f"Hello, {name}!")

print("\nCalling greet_person():")
greet_person("Alice")
greet_person("Bob")

print("\n" + "=" * 50)

# Example 3: Function with multiple parameters
def add_numbers(a, b):
    """Add two numbers"""
    result = a + b
    print(f"{a} + {b} = {result}")

print("\nCalling add_numbers():")
add_numbers(5, 3)
add_numbers(10, 20)

print("\n" + "=" * 50)

# Example 4: Function with return value
def multiply(x, y):
    """Multiply two numbers and return result"""
    return x * y

print("\nCalling multiply() with return:")
result1 = multiply(4, 5)
print(f"Result: {result1}")

result2 = multiply(7, 8)
print(f"Result: {result2}")

print("\n" + "=" * 50)

# Example 5: Function with default parameters
def power(base, exponent=2):
    """Calculate power with default exponent of 2"""
    return base ** exponent

print("\nCalling power() with default parameter:")
print(f"power(5) = {power(5)}")  # Uses default exponent=2
print(f"power(5, 3) = {power(5, 3)}")  # Overrides default
print(f"power(2, 4) = {power(2, 4)}")
