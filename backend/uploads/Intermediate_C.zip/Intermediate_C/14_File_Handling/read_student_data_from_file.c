/*
 * READ STUDENT DATA FROM FILE
 * Demonstrates reading structured text data line-by-line
 * 
 * CONCEPT:
 * - Open file in read mode ("r")
 * - Read data using fscanf() or fgets()
 * - Close the file
 */

#include <stdio.h>

int main() {
    FILE *fp;
    char line[100];
    
    // Open file in read mode
    fp = fopen("student.txt", "r");
    
    // Check if file exists
    if (fp == NULL) {
        printf("Error: File not found!\n");
        printf("Please run write_to_file.c first to create the file.\n");
        return 1;
    }
    
    printf("Reading from student.txt:\n");
    printf("-------------------------\n");
    
    // Read and display file line by line
    while (fgets(line, sizeof(line), fp) != NULL) {
        printf("%s", line);  // line already contains \n
    }
    
    // Close the file
    fclose(fp);
    
    return 0;
}

/*
 * REQUIREMENTS:
 * Run save_student_data_to_file.c first to create student.txt
 * 
 * OUTPUT:
 * Reading from student.txt:
 * -------------------------
 * Student Information
 * ===================
 * Name: John
 * Age: 20
 * Marks: 85.50
 * 
 * NOTE:
 * - fgets() reads one line at a time
 * - Returns NULL when end of file reached
 * - File must exist for read mode
 * - Use "r" mode for reading
 */
