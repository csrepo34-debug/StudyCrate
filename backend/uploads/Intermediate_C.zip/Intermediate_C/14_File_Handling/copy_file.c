/*
 * COPY FILE
 * Copies content from one file to another
 * 
 * CONCEPT:
 * - Open source file in read mode
 * - Open destination file in write mode
 * - Read from source, write to destination
 * - Close both files
 */

#include <stdio.h>

int main() {
    FILE *source, *dest;
    char ch;
    char sourceFile[50], destFile[50];
    
    // Get file names from user
    printf("Enter source file name: ");
    scanf("%s", sourceFile);
    printf("Enter destination file name: ");
    scanf("%s", destFile);
    
    // Open source file
    source = fopen(sourceFile, "r");
    if (source == NULL) {
        printf("Error: Cannot open source file %s\n", sourceFile);
        return 1;
    }
    
    // Open destination file
    dest = fopen(destFile, "w");
    if (dest == NULL) {
        printf("Error: Cannot create destination file %s\n", destFile);
        fclose(source);
        return 1;
    }
    
    // Copy character by character
    printf("Copying file...\n");
    while ((ch = fgetc(source)) != EOF) {
        fputc(ch, dest);
    }
    
    // Close both files
    fclose(source);
    fclose(dest);
    
    printf("File copied successfully from %s to %s\n", sourceFile, destFile);
    
    return 0;
}

/*
 * SAMPLE RUN:
 * Enter source file name: student.txt
 * Enter destination file name: backup.txt
 * Copying file...
 * File copied successfully from student.txt to backup.txt
 * 
 * EXPLANATION:
 * - fgetc() reads one character at a time
 * - EOF (End Of File) signals end of file
 * - fputc() writes one character at a time
 * - Both files must be closed
 * 
 * TRY IT:
 * 1. Run write_to_file.c to create student.txt
 * 2. Run this program to copy student.txt to backup.txt
 * 3. Check both files have same content
 */
