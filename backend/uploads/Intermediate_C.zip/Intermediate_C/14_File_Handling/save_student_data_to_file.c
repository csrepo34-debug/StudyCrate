/*
 * SAVE STUDENT DATA TO FILE
 * Demonstrates creating and writing structured data to a text file
 * 
 * CONCEPT:
 * - Open file in write mode ("w")
 * - Write data using fprintf()
 * - Close the file
 */

#include <stdio.h>

int main() {
    FILE *fp;
    char name[50];
    int age;
    float marks;
    
    // Get user input
    printf("Enter name: ");
    scanf("%s", name);
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Enter marks: ");
    scanf("%f", &marks);
    
    // Open file in write mode (overwrite existing content)
    fp = fopen("student.txt", "w");
    
    // Check if file opened successfully
    if (fp == NULL) {
        printf("Error: Could not create file!\n");
        return 1;
    }
    
    // Write data to file
    fprintf(fp, "Student Information\n");
    fprintf(fp, "===================\n");
    fprintf(fp, "Name: %s\n", name);
    fprintf(fp, "Age: %d\n", age);
    fprintf(fp, "Marks: %.2f\n", marks);
    
    // Close the file
    fclose(fp);
    
    printf("\nData successfully written to student.txt\n");
    
    return 0;
}

/*
 * OUTPUT:
 * Enter name: John
 * Enter age: 20
 * Enter marks: 85.5
 * 
 * Data successfully written to student.txt
 * 
 * FILE CONTENTS (student.txt):
 * Student Information
 * ===================
 * Name: John
 * Age: 20
 * Marks: 85.50
 * 
 * NOTE:
 * - "w" mode creates new file or overwrites existing
 * - Always check if fp != NULL
 * - Always close file after use
 * - Combine with read_student_data_from_file.c to verify contents
 */
