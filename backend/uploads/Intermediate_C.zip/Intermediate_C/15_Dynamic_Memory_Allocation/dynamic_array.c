/*
 * DYNAMIC ARRAY
 * Demonstrates malloc() for creating array at runtime
 * 
 * CONCEPT:
 * - Array size decided at runtime (not compile time)
 * - Use malloc() to allocate memory
 * - Use the array normally
 * - Free the memory when done
 */

#include <stdio.h>
#include <stdlib.h>  // For malloc() and free()

int main() {
    int n;
    int *arr;  // Pointer to store array address
    
    // Get array size from user
    printf("Enter number of elements: ");
    scanf("%d", &n);
    
    // Allocate memory for n integers
    arr = (int*)malloc(n * sizeof(int));
    
    // Check if allocation succeeded
    if (arr == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }
    
    printf("Memory allocated successfully for %d integers\n", n);
    
    // Input array elements
    printf("\nEnter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);  // Use array normally
    }
    
    // Display array
    printf("\nArray elements: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    // Calculate sum
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    printf("\nSum of elements: %d\n", sum);
    printf("Average: %.2f\n", (float)sum / n);
    
    // Free the allocated memory
    free(arr);
    arr = NULL;  // Good practice
    
    printf("\nMemory freed successfully\n");
    
    return 0;
}

/*
 * SAMPLE RUN:
 * Enter number of elements: 5
 * Memory allocated successfully for 5 integers
 * 
 * Enter 5 elements:
 * Element 1: 10
 * Element 2: 20
 * Element 3: 30
 * Element 4: 40
 * Element 5: 50
 * 
 * Array elements: 10 20 30 40 50
 * 
 * Sum of elements: 150
 * Average: 30.00
 * 
 * Memory freed successfully
 * 
 * WHY DYNAMIC MEMORY?
 * - Size can be determined at runtime
 * - More flexible than fixed-size arrays
 * - Can handle variable input sizes
 * - Essential for data structures
 */
