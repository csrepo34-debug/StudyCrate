/*
 * LINKED LIST BASICS
 * Demonstrates dynamic memory allocation with a singly linked list
 */

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node* createNode(int value) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

void appendNode(struct Node **head, int value) {
    struct Node *newNode = createNode(value);
    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

void displayList(const struct Node *head) {
    const struct Node *temp = head;
    printf("Linked List: ");
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

void freeList(struct Node **head) {
    struct Node *current = *head;
    while (current != NULL) {
        struct Node *nextNode = current->next;
        free(current);
        current = nextNode;
    }
    *head = NULL;
}

int main() {
    struct Node *head = NULL;
    int choice, value;

    do {
        printf("\n=== LINKED LIST MENU ===\n");
        printf("1. Append node\n");
        printf("2. Display list\n");
        printf("0. Exit\n");
        printf("Choose an option: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &value);
                appendNode(&head, value);
                break;
            case 2:
                displayList(head);
                break;
            case 0:
                printf("Exiting linked list demo.\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 0);

    freeList(&head);
    return 0;
}

/*
 * PRACTICE:
 * - Implement insert at beginning
 * - Implement delete operation
 * - Count nodes in the list
 */
