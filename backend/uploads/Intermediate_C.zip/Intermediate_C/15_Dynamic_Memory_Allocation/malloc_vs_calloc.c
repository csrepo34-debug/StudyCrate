/*
 * MALLOC VS CALLOC COMPARISON
 * Shows difference between malloc() and calloc()
 * 
 * KEY DIFFERENCE:
 * malloc: Allocates uninitialized memory (garbage values)
 * calloc: Allocates zero-initialized memory (all zeros)
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
    int n = 5;
    int *arr1, *arr2;
    
    printf("Comparing malloc vs calloc\n");
    printf("==========================\n\n");
    
    // Using malloc
    printf("1. Using malloc(%d * sizeof(int)):\n", n);
    arr1 = (int*)malloc(n * sizeof(int));
    
    if (arr1 == NULL) {
        printf("malloc failed\n");
        return 1;
    }
    
    printf("Values (uninitialized - may contain garbage):\n");
    for (int i = 0; i < n; i++) {
        printf("arr1[%d] = %d\n", i, arr1[i]);
    }
    
    // Using calloc
    printf("\n2. Using calloc(%d, sizeof(int)):\n", n);
    arr2 = (int*)calloc(n, sizeof(int));
    
    if (arr2 == NULL) {
        printf("calloc failed\n");
        free(arr1);
        return 1;
    }
    
    printf("Values (initialized to zero):\n");
    for (int i = 0; i < n; i++) {
        printf("arr2[%d] = %d\n", i, arr2[i]);
    }
    
    // Assign values to both arrays
    printf("\n3. After assigning values:\n");
    for (int i = 0; i < n; i++) {
        arr1[i] = i * 10;
        arr2[i] = i * 10;
    }
    
    printf("arr1: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr1[i]);
    }
    
    printf("\narr2: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    
    // Free both arrays
    free(arr1);
    free(arr2);
    arr1 = NULL;
    arr2 = NULL;
    
    printf("\nBoth arrays freed\n");
    
    // Summary
    printf("\n--- SUMMARY ---\n");
    printf("malloc: Faster, but contains garbage values\n");
    printf("calloc: Slightly slower, but initialized to zero\n");
    printf("Both need to be freed with free()\n");
    
    return 0;
}

/*
 * TYPICAL OUTPUT:
 * Comparing malloc vs calloc
 * ==========================
 * 
 * 1. Using malloc(5 * sizeof(int)):
 * Values (uninitialized - may contain garbage):
 * arr1[0] = 4234523
 * arr1[1] = 0
 * arr1[2] = -234234
 * arr1[3] = 8734523
 * arr1[4] = 0
 * 
 * 2. Using calloc(5, sizeof(int)):
 * Values (initialized to zero):
 * arr2[0] = 0
 * arr2[1] = 0
 * arr2[2] = 0
 * arr2[3] = 0
 * arr2[4] = 0
 * 
 * 3. After assigning values:
 * arr1: 0 10 20 30 40
 * arr2: 0 10 20 30 40
 * 
 * Both arrays freed
 * 
 * --- SUMMARY ---
 * malloc: Faster, but contains garbage values
 * calloc: Slightly slower, but initialized to zero
 * Both need to be freed with free()
 * 
 * WHEN TO USE:
 * malloc: When you'll immediately assign values
 * calloc: When you need zero-initialized memory
 */
