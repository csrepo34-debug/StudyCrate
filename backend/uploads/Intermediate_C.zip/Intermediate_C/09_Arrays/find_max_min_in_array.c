/*
 * FIND MAXIMUM AND MINIMUM IN ARRAY
 * Demonstrates array traversal and comparison
 * 
 * ALGORITHM:
 * 1. Assume first element is both max and min
 * 2. Compare each element with current max and min
 * 3. Update max if element is greater
 * 4. Update min if element is smaller
 */

#include <stdio.h>

int main() {
    int n;
    
    printf("Enter number of elements: ");
    scanf("%d", &n);
    
    // Declare array of size n (Variable Length Array in C99)
    int arr[n];
    
    // Input array elements
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    
    // Initialize max and min with first element
    int max = arr[0];
    int min = arr[0];
    int maxIndex = 0;  // Track position of max element
    int minIndex = 0;  // Track position of min element
    
    // Find max and min by comparing with each element
    for (int i = 1; i < n; i++) {  // Start from index 1
        if (arr[i] > max) {
            max = arr[i];
            maxIndex = i;
        }
        if (arr[i] < min) {
            min = arr[i];
            minIndex = i;
        }
    }
    
    // Display results
    printf("\n--- Results ---\n");
    printf("Maximum element: %d (at position %d)\n", max, maxIndex + 1);
    printf("Minimum element: %d (at position %d)\n", min, minIndex + 1);
    printf("Difference: %d\n", max - min);
    
    // Display all elements
    printf("\nArray elements: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    return 0;
}

/*
 * SAMPLE RUN:
 * Enter number of elements: 5
 * Enter 5 elements:
 * Element 1: 45
 * Element 2: 12
 * Element 3: 78
 * Element 4: 23
 * Element 5: 56
 * 
 * --- Results ---
 * Maximum element: 78 (at position 3)
 * Minimum element: 12 (at position 2)
 * Difference: 66
 * 
 * Array elements: 45 12 78 23 56
 * 
 * NOTE:
 * - Array indices start at 0
 * - Position shown to user starts at 1 (more intuitive)
 * - This algorithm works for any size array
 */
