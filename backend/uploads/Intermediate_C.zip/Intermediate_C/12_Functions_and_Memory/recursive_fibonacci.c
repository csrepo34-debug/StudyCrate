/*
 * RECURSIVE FIBONACCI
 * Generates Fibonacci number using recursion
 */

#include <stdio.h>

long long fibonacci(int n) {
    // Base cases
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }
    // Recursive case
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int terms;
    
    printf("Enter number of terms: ");
    scanf("%d", &terms);
    
    printf("Fibonacci Series:\n");
    for (int i = 0; i < terms; i++) {
        printf("%lld ", fibonacci(i));
    }
    printf("\n");
    
    return 0;
}
