/*
 * STUDENT RECORD SYSTEM
 * Manages student records using structures
 */

#include <stdio.h>
#include <string.h>

struct Student {
    int rollNo;
    char name[50];
    float marks[3];
    float average;
};

void inputStudent(struct Student *s) {
    printf("Enter Roll Number: ");
    scanf("%d", &s->rollNo);
    getchar();  // Clear newline
    
    printf("Enter Name: ");
    fgets(s->name, sizeof(s->name), stdin);
    s->name[strcspn(s->name, "\n")] = 0;
    
    printf("Enter marks for 3 subjects:\n");
    float sum = 0;
    for (int i = 0; i < 3; i++) {
        printf("Subject %d: ", i + 1);
        scanf("%f", &s->marks[i]);
        sum += s->marks[i];
    }
    s->average = sum / 3;
}

void displayStudent(struct Student s) {
    printf("\n--- Student Details ---\n");
    printf("Roll No: %d\n", s.rollNo);
    printf("Name: %s\n", s.name);
    printf("Marks: %.2f, %.2f, %.2f\n", 
           s.marks[0], s.marks[1], s.marks[2]);
    printf("Average: %.2f\n", s.average);
}

int main() {
    int n;
    
    printf("Enter number of students: ");
    scanf("%d", &n);
    
    struct Student students[n];
    
    // Input student records
    for (int i = 0; i < n; i++) {
        printf("\n--- Student %d ---\n", i + 1);
        inputStudent(&students[i]);
    }
    
    // Display all records
    printf("\n\n=== ALL STUDENT RECORDS ===\n");
    for (int i = 0; i < n; i++) {
        displayStudent(students[i]);
    }
    
    return 0;
}
