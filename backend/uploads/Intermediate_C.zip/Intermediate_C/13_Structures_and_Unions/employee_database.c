/*
 * EMPLOYEE DATABASE
 * Demonstrates array of structures, nested structures, and basic CRUD operations
 */

#include <stdio.h>
#include <string.h>

#define MAX_EMPLOYEES 50
#define NAME_LEN 40
#define DEPT_LEN 20

struct Date {
    int day;
    int month;
    int year;
};

struct Employee {
    int id;
    char name[NAME_LEN];
    char department[DEPT_LEN];
    float salary;
    struct Date joinDate;
};

void inputEmployee(struct Employee *emp) {
    printf("Enter ID: ");
    scanf("%d", &emp->id);
    getchar();

    printf("Enter Name: ");
    fgets(emp->name, sizeof(emp->name), stdin);
    emp->name[strcspn(emp->name, "\n")] = '\0';

    printf("Enter Department: ");
    fgets(emp->department, sizeof(emp->department), stdin);
    emp->department[strcspn(emp->department, "\n")] = '\0';

    printf("Enter Salary: ");
    scanf("%f", &emp->salary);

    printf("Enter Joining Date (DD MM YYYY): ");
    scanf("%d %d %d", &emp->joinDate.day, &emp->joinDate.month, &emp->joinDate.year);
}

void displayEmployee(const struct Employee *emp) {
    printf("\nID: %d\n", emp->id);
    printf("Name: %s\n", emp->name);
    printf("Department: %s\n", emp->department);
    printf("Salary: $%.2f\n", emp->salary);
    printf("Joining Date: %02d-%02d-%04d\n", emp->joinDate.day, emp->joinDate.month, emp->joinDate.year);
}

int main() {
    struct Employee employees[MAX_EMPLOYEES];
    int count = 0;
    int choice;

    do {
        printf("\n=== EMPLOYEE DATABASE MENU ===\n");
        printf("1. Add Employee\n");
        printf("2. Display All Employees\n");
        printf("3. Search by Department\n");
        printf("0. Exit\n");
        printf("Choose an option: ");
        scanf("%d", &choice);
        getchar();

        if (choice == 1) {
            if (count >= MAX_EMPLOYEES) {
                printf("Database full!\n");
            } else {
                printf("\n--- Add Employee %d ---\n", count + 1);
                inputEmployee(&employees[count]);
                count++;
            }
        } else if (choice == 2) {
            if (count == 0) {
                printf("No employees to display.\n");
            } else {
                printf("\n=== ALL EMPLOYEES ===\n");
                for (int i = 0; i < count; i++) {
                    displayEmployee(&employees[i]);
                }
            }
        } else if (choice == 3) {
            if (count == 0) {
                printf("No employees available.\n");
            } else {
                char searchDept[DEPT_LEN];
                printf("Enter department to search: ");
                fgets(searchDept, sizeof(searchDept), stdin);
                searchDept[strcspn(searchDept, "\n")] = '\0';

                printf("\nEmployees in %s department:\n", searchDept);
                int found = 0;
                for (int i = 0; i < count; i++) {
                    if (strcmp(employees[i].department, searchDept) == 0) {
                        displayEmployee(&employees[i]);
                        found = 1;
                    }
                }
                if (!found) {
                    printf("No employees found in this department.\n");
                }
            }
        }
    } while (choice != 0);

    printf("\nExiting Employee Database.\n");
    return 0;
}

/*
 * PRACTICE IDEAS:
 * - Add delete/update operations
 * - Save records to a file (combine with Topic 14)
 * - Sort employees by salary or name
 */
