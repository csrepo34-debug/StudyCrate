/*
 * SWAP USING POINTERS
 * Demonstrates pass by reference
 * 
 * CONCEPT:
 * Without pointers: Changes in function don't affect original variables
 * With pointers: Function can modify original variables
 * 
 * HOW IT WORKS:
 * - We pass addresses of variables (&x, &y)
 * - Function receives pointers (*a, *b)
 * - Using *a and *b, we modify values at those addresses
 * - Changes reflect in original variables
 */

#include <stdio.h>

// Function to swap two numbers using pointers
// Takes addresses of two integers as parameters
void swap(int *a, int *b) {
    printf("\nInside swap function:\n");
    printf("Before swap: *a = %d, *b = %d\n", *a, *b);
    
    int temp = *a;   // Store value at address a in temp
    *a = *b;         // Copy value at address b to address a
    *b = temp;       // Copy temp to address b
    
    printf("After swap:  *a = %d, *b = %d\n", *a, *b);
}

int main() {
    int x, y;
    
    printf("Enter first number: ");
    scanf("%d", &x);
    printf("Enter second number: ");
    scanf("%d", &y);
    
    printf("\nBefore swap: x = %d, y = %d\n", x, y);
    printf("Memory addresses: x is at %p, y is at %p\n", (void*)&x, (void*)&y);
    
    // Pass addresses of x and y to swap function
    swap(&x, &y);  // &x gives address of x, &y gives address of y
    
    printf("\nAfter swap:  x = %d, y = %d\n", x, y);
    
    return 0;
}

/*
 * SAMPLE RUN:
 * Enter first number: 10
 * Enter second number: 20
 * 
 * Before swap: x = 10, y = 20
 * Memory addresses: x is at 0x7ffd5c, y is at 0x7ffd58
 * 
 * Inside swap function:
 * Before swap: *a = 10, *b = 20
 * After swap:  *a = 20, *b = 10
 * 
 * After swap:  x = 20, y = 10
 * 
 * EXPLANATION:
 * - Without pointers, swap wouldn't work
 * - Pointers allow function to access original variables
 * - This is called "pass by reference"
 * - & means "address of"
 * - * means "value at address"
 */
