/*
 * ARRAY TRAVERSAL USING POINTERS
 * Access array elements using pointer arithmetic
 */

#include <stdio.h>

int main() {
    int arr[5] = {10, 20, 30, 40, 50};
    int *ptr = arr;
    int size = 5;
    
    printf("Array elements using pointer:\n");
    for (int i = 0; i < size; i++) {
        printf("Element %d: %d (Address: %p)\n", 
               i, *(ptr + i), (void*)(ptr + i));
    }
    
    printf("\nArray elements using pointer increment:\n");
    ptr = arr;  // Reset pointer
    for (int i = 0; i < size; i++) {
        printf("%d ", *ptr);
        ptr++;
    }
    printf("\n");
    
    return 0;
}
