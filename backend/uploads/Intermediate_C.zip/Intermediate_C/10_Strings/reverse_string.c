/*
 * REVERSE A STRING
 * Reverses string without using library functions
 */

#include <stdio.h>
#include <string.h>

int main() {
    char str[100], reversed[100];
    int len, i, j;
    
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    
    // Remove newline if present
    str[strcspn(str, "\n")] = 0;
    
    len = strlen(str);
    
    // Reverse the string
    j = 0;
    for (i = len - 1; i >= 0; i--) {
        reversed[j] = str[i];
        j++;
    }
    reversed[j] = '\0';
    
    printf("Original string: %s\n", str);
    printf("Reversed string: %s\n", reversed);
    
    return 0;
}
