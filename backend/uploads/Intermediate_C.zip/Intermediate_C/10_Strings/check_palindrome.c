/*
 * CHECK PALINDROME
 * Checks if string reads same forwards and backwards
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str[100];
    int left = 0, right, isPalindrome = 1;
    
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    
    // Remove newline
    str[strcspn(str, "\n")] = 0;
    
    right = strlen(str) - 1;
    
    // Check palindrome
    while (left < right) {
        // Skip non-alphanumeric characters
        while (left < right && !isalnum(str[left])) {
            left++;
        }
        while (left < right && !isalnum(str[right])) {
            right--;
        }
        
        // Compare characters (case-insensitive)
        if (tolower(str[left]) != tolower(str[right])) {
            isPalindrome = 0;
            break;
        }
        
        left++;
        right--;
    }
    
    if (isPalindrome) {
        printf(""%s" is a PALINDROME\n", str);
    } else {
        printf(""%s" is NOT a palindrome\n", str);
    }
    
    return 0;
}
