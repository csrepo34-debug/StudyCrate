/*
 * STRING FUNCTIONS DEMO
 * Demonstrates strlen, strcpy, strcat, strcmp with practical examples
 */

#include <stdio.h>
#include <string.h>

void printHeader(const char *title) {
    printf("\n=== %s ===\n", title);
}

int main() {
    char source[50] = "Hello";
    char destination[50];
    char firstName[20] = "John";
    char lastName[20] = "Doe";
    char fullName[50];

    /* strlen */
    printHeader("strlen");
    size_t len = strlen(source);
    printf("String: %s\n", source);
    printf("Length: %zu characters (excluding null terminator)\n", len);

    /* strcpy */
    printHeader("strcpy");
    strcpy(destination, source);
    printf("Copied '%s' into destination => %s\n", source, destination);

    /* strcat */
    printHeader("strcat");
    strcpy(fullName, firstName);       // Start with first name
    strcat(fullName, " ");            // Add a space
    strcat(fullName, lastName);        // Add last name
    printf("Full name after strcat: %s\n", fullName);

    /* strcmp */
    printHeader("strcmp");
    char password[20] = "Secret123";
    char userInput[20];
    printf("Enter password attempt: ");
    scanf("%19s", userInput);

    if (strcmp(password, userInput) == 0) {
        printf("Passwords MATCH (strcmp returned 0).\n");
    } else {
        printf("Passwords DO NOT match (strcmp returned %d).\n", strcmp(password, userInput));
    }

    printf("\nTip: strcmp returns 0 when strings are equal.\n");
    printf("Negative value if first < second, positive if first > second (lexicographically).\n");

    return 0;
}

/*
 * SAMPLE RUN:
 * === strlen ===
 * String: Hello
 * Length: 5 characters (excluding null terminator)
 *
 * === strcpy ===
 * Copied 'Hello' into destination => Hello
 *
 * === strcat ===
 * Full name after strcat: John Doe
 *
 * === strcmp ===
 * Enter password attempt: Secret123
 * Passwords MATCH (strcmp returned 0).
 */
